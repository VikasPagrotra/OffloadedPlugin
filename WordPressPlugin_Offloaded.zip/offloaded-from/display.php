

<?php
$content = file_get_contents("http://202.164.62.212:8080/api/getDeviceinfo");
$result  = json_decode($content, true);
?>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<style>
.container{
    width: 100% !important;
}
td{
	border: 1px solid #ccc;
}
#myTable {
    overflow: auto;
    display: inline-block;
}	
</style>
<h1 class="center">ALL RECORDES</h1>
<div class="container">
<table id='myTable' class="table table-striped"> 
	  <thead>
	<tr>
		<th>Model No</th>
		<th>Tester</th>
		<th>OEM</th>
		<th>CPU</th>
		<th>RAM (gb)</th>	
		<th>Os Version</th>
		<th>display200nits</th>
		<th>color_temp</th>
		<th>max_brightness</th>
		<th>max_brightness_auto</th>
		<th>low_brightness</th>
		<th>low_brightness_auto</th>
		<th>standard_display200nits</th>
		<th>standard_color_temp</th>
		<th>standard_max_brightness</th>
		<th>standard_max_brightness_auto</th>
		<th>standard_low_brightness</th>
		<th>standard_low_brightness_auto</th>
		<th>calman_uploaded</th>
		<th>loudspeaker_loudness</th>
		<th>headphone_output</th>
		<th>noise_level</th>
		<th>total_harmonic</th>
		<th>frequency_response</th>
		<th>rightmark_uploaded</th>
		<th>battery_size</th>
		<th>gen_battery_size</th>
		<th>browsing_test</th>
		<th>gaming_battery_test</th>
		<th>video_playback_test</th>
		<th>battery_full_charge</th>
		<th>battery_15_min</th>
		<th>battery_30_min</th>
		<th>battery_60_min</th>
		<th>color_daylight</th>
		<th>noise_daylight</th>
		<th>camera_Sharpness</th>
		<th>sharpness_daylight_Center_MTF50</th>
		<th>sharpness_daylight_Corner_averageMTF50</th>
		<th>color_lowlight</th>
		<th>noise_lowlight</th>
		<th>camera_sample_uploaded_drive</th>
		<th>antutu</th>
		<th>hd_onscreen</th>
		<th>manhattan_onscreen</th>
		<th>vellamo_metal</th>
		<th>vellamo_browser</th>
		<th>basemark_os_platform</th>
		<th>jetstream</th>
		<th>sunspider</th>
		<th>geekbench_single_core</th>
		<th>geekbench_multi_core</th>
		<th>3d_mark_test</th>
		<th>3d_mark_overall_test</th>
	</tr>
	</thead> 
	<tbody>
	<?php
			foreach ($result as $values) {		
				echo "</td><td class='name'>".$values['model_id']; 			 
				echo "</td><td class='tester'>". $values['tester']; 	
				echo "</td><td class='oem'>". $values['oem']; 	
				echo "</td><td class='cpu'>". $values['cpu']; 		
				echo "</td><td class='ram_gb'>". $values['ram_gb']; 				
				echo "</td><td class='date_tested'>". $values['os_version']; 
				echo "</td><td class='date_tested'>". $values['display200nits']; 
				echo "</td><td class='date_tested'>". $values['color_temp']; 
				echo "</td><td class='date_tested'>". $values['max_brightness']; 
				echo "</td><td class='date_tested'>". $values['max_brightness_auto']; 
				echo "</td><td class='date_tested'>". $values['low_brightness']; 
				echo "</td><td class='date_tested'>". $values['low_brightness_auto']; 
				echo "</td><td class='date_tested'>". $values['standard_display200nits']; 
				echo "</td><td class='date_tested'>". $values['standard_color_temp']; 
				echo "</td><td class='date_tested'>". $values['standard_max_brightness']; 
				echo "</td><td class='date_tested'>". $values['standard_max_brightness_auto']; 
				echo "</td><td class='date_tested'>". $values['standard_low_brightness']; 
				echo "</td><td class='date_tested'>". $values['standard_low_brightness_auto']; 
				echo "</td><td class='date_tested'>". $values['calman_uploaded']; 
				echo "</td><td class='date_tested'>". $values['loudspeaker_loudness']; 
				echo "</td><td class='date_tested'>". $values['headphone_output']; 
				echo "</td><td class='date_tested'>". $values['noise_level']; 
				echo "</td><td class='date_tested'>". $values['total_harmonic']; 
				echo "</td><td class='date_tested'>". $values['frequency_response']; 
				echo "</td><td class='date_tested'>". $values['rightmark_uploaded']; 
				echo "</td><td class='date_tested'>". $values['battery_size']; 
				echo "</td><td class='date_tested'>". $values['gen_battery_size']; 
				echo "</td><td class='date_tested'>". $values['gaming_battery_test']; 
				echo "</td><td class='date_tested'>". $values['video_playback_test'];
				echo "</td><td class='date_tested'>". $values['battery_full_charge'];
				echo "</td><td class='date_tested'>". $values['battery_15_min'];
				echo "</td><td class='date_tested'>". $values['battery_30_min'];
				echo "</td><td class='date_tested'>". $values['battery_60_min'];
				echo "</td><td class='date_tested'>". $values['browsing_test'];
				echo "</td><td class='date_tested'>". $values['color_daylight'];
				echo "</td><td class='date_tested'>". $values['noise_daylight'];
				echo "</td><td class='date_tested'>". $values['camera_sharpness'];
				echo "</td><td class='date_tested'>". $values['sharpness_daylight_Center_MTF50'];
				echo "</td><td class='date_tested'>". $values['sharpness_daylight_Corner_averageMTF50'];
				echo "</td><td class='date_tested'>". $values['color_lowlight'];
				echo "</td><td class='date_tested'>". $values['noise_lowlight'];
				echo "</td><td class='date_tested'>". $values['camera_sample_uploaded_drive'];
				echo "</td><td class='date_tested'>". $values['antutu'];
				echo "</td><td class='date_tested'>". $values['hd_onscreen'];
				echo "</td><td class='date_tested'>". $values['manhattan_onscreen'];
				echo "</td><td class='date_tested'>". $values['vellamo_metal'];
				echo "</td><td class='date_tested'>". $values['vellamo_browser'];
				echo "</td><td class='date_tested'>". $values['basemark_os_platform'];
				echo "</td><td class='date_tested'>". $values['jetstream'];
				echo "</td><td class='date_tested'>". $values['sunspider'];
				echo "</td><td class='date_tested'>". $values['geekbench_single_core'];
				echo "</td><td class='date_tested'>". $values['geekbench_multi_core'];
				echo "</td><td class='date_tested'>". $values['3d_mark_test'];
				echo "</td><td class='date_tested'>". $values['3d_mark_overall_test'];
									 
			  echo"</td></tr>";
			}
	?>
	</tbody>
</table>	
</div>

<script>
$(document).ready(function(){
    $('#myTable').dataTable();
});
</script>
