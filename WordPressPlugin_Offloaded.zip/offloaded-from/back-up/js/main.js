
function validate() {
    var output = true;
    $(".signup-error").html('');
    if($("#display-field").css('display') != 'none') {
        if(!($("#name").val())) {
            output = true;
            $("#name-error").html("Name required!");
        }
        if(!($("#email").val())) {
            output = true;
            $("#email-error").html("Email required!");
        }
        /** Remove below Comment for email validation **/	
        /*if(!$("#email").val().match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/)) {
            $("#email-error").html("Invalid Email!");
            output = false;
        }*/
    }
 
    if($("#audio-field").css('display') != 'none') {
        if(!($("#user-password").val())) {
            output = true;
            $("#password-error").html("Password required!");
        }	
        if(!($("#confirm-password").val())) {
            output = true;
            $("#confirm-password-error").html("Confirm password required!");
        }	
        if($("#user-password").val() != $("#confirm-password").val()) {
            output = true;
            $("#confirm-password-error").html("Password not matched!");
        }	
    }
    return output;
}
 
$(document).ready(function() {
    $("#next").click(function(){
        var output = validate();
        if(output) {
            var current = $(".active");
            var next = $(".active").next("li");
                if(next.length>0) {
                    $("#"+current.attr("id")+"-field").hide();
                    $("#"+next.attr("id")+"-field").show();
                    $("#back").show();
                    $("#finish").hide();
                    $(".active").removeClass("active");
                    next.addClass("active");
                    if($( "#general" ).hasClass( "active" )) {
                        $("#next").hide();
                        $("#finish").show();				
                    }
                }
            }
        });
    $("#back").click(function(){ 
        var current = $(".active");
        var prev = $(".active").prev("li");
        if(prev.length>0) {
            $("#"+current.attr("id")+"-field").hide();
            $("#"+prev.attr("id")+"-field").show();
            $("#next").show();
            $("#finish").hide();
            $(".active").removeClass("active");
            prev.addClass("active");
            if($(".active").attr("id") == $("li").first().attr("id")) {
                $("#back").hide();			
            }
        }
    });
    
    jQuery('.numeric');
	
});

$(document).ready(function() {
    $(".numeric").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
    $(".numeric").attr("maxlength","5")
});

