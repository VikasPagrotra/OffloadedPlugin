
function submitform(formdata) {
    console.log(formdata)
    var values = {};
    $.each(formdata, function (i, field) {
        values[field.name] = field.value;
    });
    console.log(values)
    $.ajax({
        url: 'http://localhost:8080/api/insertDeviceInfo',
        data: values,
        type: 'POST',
        success: function (data) {
            if (data == "saved") {
                $('#form')[0].reset();
                $("a#form-t-0").click();
                swal("Success", "Info saved successfully.", "success");
            }
            else {
                var message = "Exception: " + data.message;
                //var inner_message ="Inner Exception: "+ data.precedingErrors[0].message;
                swal("Error", message, "error");
            }
        },
        error: function (xhr, status, error) {
            swal("Error", error.message, "success");
        },
    });
}