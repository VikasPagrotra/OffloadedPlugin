 <?php 
   /*
   Plugin Name: offloaded form
   Plugin URI: http://offloaded-form.com
   Description: For Show form on page use this shortcode [input-from]
   Version: 1.2
   Author: Admin1
   License: GPL22
   */
 ?>


<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<?php

echo '<link href="' . esc_url( plugins_url( 'css/main.css', __FILE__ ) ) . '" rel="stylesheet">';
echo '<script src="' . esc_url( plugins_url( 'js/main.js', __FILE__ ) ) . '"></script>';


// Add plugin Name In dashbord side-bar like a menu

add_action('admin_menu', 'test_plugin_setup_menu');
 
function test_plugin_setup_menu(){
        add_menu_page( 'Test Plugin Page', 'Offloaded Form', 'manage_options', 'test-plugin', 'test_init' );
}


function test_init(){
	
	function my_plugin_remove_database() {
     global $wpdb;
     $table_name = $wpdb->prefix . "offloaded";
     $sql = "DROP TABLE IF EXISTS $table_name;";
     $wpdb->query($sql);
     delete_option("my_plugin_db_version");
	}

	register_deactivation_hook( __FILE__, 'my_plugin_remove_database' );

echo do_shortcode( '[input-from]');


}
function input_form_function() {
?>
<div class="col-md-12">
<ul id="signup-step">
	<li id="display" class="active">Display</li>
	<li id="audio">Audio</li>
	<li id="battery">Battery</li>
	<li id="camera">Camera</li>
	<li id="general">Performance</li>
</ul>

<form name="frmRegistration" id="signup-form" method="post">
	<div id="display-field">
	    <div class="col-md-6">
			
			<label>Display % at 200 nits</label><span id="name-error1" class="signup-error"></span>
			<div><input type="text" name="display" id="name" class="demoInputBox" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" /></div>
		
			<h3>Adaptive/Default Mode</h3>
		
			<label>Color Temperature (as Kelvin)</label><span id="name-error2" class="signup-error"></span>
			<div><input type="text" name="color-temp" id="name" class="demoInputBox numeric"/></div>
		
			<label>Max brightness</label><span id="name-error3" class="signup-error"></span>
			<div><input type="text" name="max-bt" id="name" class="demoInputBox"/></div>
		
			<label>Max brightness (auto)</label><span id="name-error4" class="signup-error"></span>
			<div><input type="text" name="max-auto" id="name" class="demoInputBox"/></div>
		
			<label>Low brightness</label><span id="name-error5" class="signup-error"></span>
			<div><input type="text" name="low-bt" id="name" class="demoInputBox"/></div>		
		
			<label>Low brightness (auto)</label><span id="error6" class="signup-error"></span>
			<div><input type="text" name="low-auto" id="email" class="demoInputBox" /></div>
			
		</div>
		<div class="col-md-6">
			<h3>Standard Mode</h3>
		
			<label>Color Temperature (as Kelvin)</label><span id="name-error2" class="signup-error"></span>
			<div><input type="text" name="color-temp" id="name" class="demoInputBox"/></div>
		
			<label>Max brightness</label><span id="name-error3" class="signup-error"></span>
			<div><input type="text" name="max-bt" id="name" class="demoInputBox"/></div>
		
			<label>Max brightness (auto)</label><span id="name-error4" class="signup-error"></span>
			<div><input type="text" name="max-auto" id="name" class="demoInputBox"/></div>
		
			<label>Low brightness</label><span id="name-error5" class="signup-error"></span>
			<div><input type="text" name="low-bt" id="name" class="demoInputBox"/></div>		
		
			<label>Low brightness (auto)</label><span id="error6" class="signup-error"></span>
			<div><input type="text" name="low-auto" id="email" class="demoInputBox" /></div>
		
			<label>Upload Claman Files</label><span id="error6" class="signup-error"></span>
			<div><input type="file" name="file" /></div>
		</div>
	</div>
	
	<div id="audio-field" style="display:none;">
		
		<label>Loudspeaker loudness (as dB)</label><span id="name-error5" class="signup-error"></span>
		<div><input type="text" name="low-bt" id="name" class="demoInputBox"/></div>	
		
		<label>Headphone Output (as Volts)</label><span id="name-error5" class="signup-error"></span>
		<div><input type="text" name="low-bt" id="name" class="demoInputBox"/></div>	
		
		<h3>Focusrite Readings</h3>
		
		<label>Noise Level (as dBA)</label><span id="password-error" class="signup-error"></span>
		<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
		<label>Total Harmonic Distortion</label><span id="confirm-password-error1" class="signup-error"></span>
		<div><input type="text" name="confirm-password" id="confirm-password" class="demoInputBox"/></div>
		
		<label>Frequency Response</label><span id="confirm-password-error1" class="signup-error"></span>
		<div><input type="text" name="response" id="confirm-password" class="demoInputBox"/></div>
		<div><input type="text" name="response2" id="confirm-password" class="demoInputBox"/></div>
	
	</div>
	<div id="battery-field" style="display:none;">
		
		<label>Battery Size (as mAh)</label><span id="password-error" class="signup-error"></span>
		<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
		<label>General Battery Test (as Minutes)</label><span id="password-error" class="signup-error"></span>
		<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
		<label>Wi_Fi Browseing Test (as Minutes)</label><span id="password-error" class="signup-error"></span>
		<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
		<label>Gaming Battery Life Test (as Minutes)</label><span id="password-error" class="signup-error"></span>
		<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
		<label>Video Playback battery test (as Minutes)</label><span id="password-error" class="signup-error"></span>
		<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
		<label>Battery Recharge Time (as Minutes)</label><span id="password-error" class="signup-error"></span>
		<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
	</div>
	
	<div id="camera-field" style="display:none;">
		
		<label>LW/PH (camera sharpness)</label><span id="password-error" class="signup-error"></span>
		<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
		<label>LP/PH (Video sharpness)</label><span id="password-error" class="signup-error"></span>
		<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
		<label>delta-C 00 (saturation corrected)(color error)</label><span id="password-error" class="signup-error"></span>
		<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
		<label>Noise percent (as percents)</label><span id="password-error" class="signup-error"></span>
		<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
		<label>White balance error (as Kelvin)</label><span id="password-error" class="signup-error"></span>
		<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
	</div>
	
	<div id="general-field" style="display:none;">
		<div class="col-md-6">
			
			<label>AnTuTu</label></label><span id="password-error" class="signup-error"></span>
			<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
			<label>GFXBench T_Rex HD Onscreen</label><span id="password-error" class="signup-error"></span>
			<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
			
			<label>GFXBench Manhattan onscreen</label><span id="password-error" class="signup-error"></span>
			<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		
			<label>Vellamo metal</label><span id="password-error" class="signup-error"></span>
			<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
			
			<label>Vellamo Browser (default browser)</label><span id="password-error" class="signup-error"></span>
			<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
			
			<label>Basemark OS Platform (overall score)</label><span id="password-error" class="signup-error"></span>
			<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		</div>
		<div class="col-md-6">	
			
			<label>Jetstream (default browser)</label><span id="password-error" class="signup-error"></span>
			<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
			
			<label>Sunspider</label><span id="password-error" class="signup-error"></span>
			<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
			
			<label>GeekBench 4 Single-core</label><span id="password-error" class="signup-error"></span>
			<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
			
			<label>GeekBench 4 multi-core</label><span id="password-error" class="signup-error"></span>
			<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
			
			<label>3DMark test name</label><span id="password-error" class="signup-error"></span>
			<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
			
			<label>3DMark overall test score</label><span id="password-error" class="signup-error"></span>
			<div><input type="text" name="password" id="user-password" class="demoInputBox" /></div>
		</div>
	</div>
		
	<div>
		<input class="btnAction" type="button" name="back" id="back" value="Back" style="display:none;">
		<input class="btnAction" type="button" name="next" id="next" value="Next" >
		<input class="btnAction" type="submit" name="finish" id="finish" value="Finish" style="display:none;">
	</div>
</form>

</div>
<?php
}

add_shortcode('input-from', 'input_form_function');




?>
