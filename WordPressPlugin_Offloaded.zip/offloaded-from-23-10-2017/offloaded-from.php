<?php
/*
* Plugin Name: offloaded form
* Plugin URI: http://offloaded-form.com
* Description: For Show form on page use this shortcode [input-from] , for Display all the Submitted Records use this shortcode [show-from-records]
*/



function addHeaderCode() {
	echo '<link href="' . esc_url( plugins_url( 'css/bootstrap.min.css', __FILE__ ) ) . '" rel="stylesheet">';
	echo '<link href="' . esc_url( plugins_url( 'css/plugins/steps/jquery.steps.css', __FILE__ ) ) . '" rel="stylesheet">';
	echo '<link href="' . esc_url( plugins_url( 'css/plugins/sweetalert/sweetalert.css', __FILE__ ) ) . '" rel="stylesheet">';
	echo '<link href="' . esc_url( plugins_url( 'css/style.css', __FILE__ ) ) . '" rel="stylesheet">';
	echo '<link href="' . esc_url( plugins_url( 'css/custom-style.css', __FILE__ ) ) . '" rel="stylesheet">';
	echo '<link href="' . esc_url( plugins_url( 'css/main.css', __FILE__ ) ) . '" rel="stylesheet">';


	echo '<script src="' . esc_url( plugins_url( 'js/jquery-2.1.1.js', __FILE__ ) ) . '"></script>';
	echo '<script src="' . esc_url( plugins_url( 'js/bootstrap.min.js', __FILE__ ) ) . '"></script>';
	echo '<script src="' . esc_url( plugins_url( 'js/plugins/staps/jquery.steps.min.js', __FILE__ ) ) . '"></script>';
	echo '<script src="' . esc_url( plugins_url( 'js/plugins/validate/jquery.validate.min.js', __FILE__ ) ) . '"></script>';
	echo '<script src="' . esc_url( plugins_url( 'js/plugins/sweetalert/sweetalert.min.js', __FILE__ ) ) . '"></script>';
	echo '<script src="' . esc_url( plugins_url( 'js/main.js', __FILE__ ) ) . '"></script>';
	
}
add_action('wp_head', 'addHeaderCode');

// Add plugin Name In dashbord side-bar like a menu
function test_plugin_setup_menu(){
        add_menu_page( 'Test Plugin Page', 'Offloaded Form', 'manage_options', 'test-plugin', 'input_form_function' );
        add_submenu_page( 'test-plugin', 'display','Show Records', 'manage_options', 'test-plugin2', 'display_form_function' );
}

add_action('admin_menu', 'test_plugin_setup_menu');





// create shortcode of input Form
function input_form_function() {
	
	include(plugin_dir_path( __FILE__ ) .'/form.php');

}
add_shortcode('input-from', 'input_form_function');


// create shortcode of display record page
function display_form_function() {
	
	include(plugin_dir_path( __FILE__ ) .'/display.php');
	
}
add_shortcode('show-from-records', 'display_form_function');	


function ranking_form_function() {
	
	include(plugin_dir_path( __FILE__ ) .'/ranking.php');
	
}
add_shortcode('ranking-from-records', 'ranking_form_function');	



?>
