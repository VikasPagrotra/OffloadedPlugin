
<script src="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.jquery.min.js"></script>
<link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet"/>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>

<script>
$(".chosen-select").chosen({
  no_results_text: "Oops, nothing found!"
})


    
    
</script>
<style>
.chosen-select {
    display: block;
    width: 50%;
}
.check-boxs {
    display: block !important;
}
</style>



<?php
$content = file_get_contents("http://202.164.62.212:8080/api/getDeviceinfo");
$result  = json_decode($content, true);
?>

<div class="ibox-content col-md-12">	    
        <form id="form" class="wizard-big" onclick="this.disabled = true">
            <h1>Model</h1>
            <fieldset>
                <h2>Model</h2>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
							
							<label>Select Your Modelds</label>
                           <!-- <input id="" name="model_id" type="text" class="form-control"> -->
                           	<select id="ModelIds" name="sel" multiple class="form-control">
                           <?php
							   foreach ($result as $values) {?>					
                                
                               <?php echo "<option value='".$values['Id']."'>".$values['model_id']."</option>"; 
                               
                               }?>
                             
                            </select> 
                             

                        </div>
                    </div>
                </div>
            </fieldset>
            <h1>Details</h1>
            <fieldset>
                <h2>Details</h2>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>Tester</label>
                            
                            <input type="checkbox" name="tester" value="tester" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>OEM</label>
                            <input type="checkbox" name="oem" value="oem" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>CPU</label>
                         
                            <input type="checkbox" name="cpu" value="cpu" class="check-boxs">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>RAM <small>(GB)</small></label>
                  
                            <input type="checkbox" name="ram_gb" value="ram_gb" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>Date Tested</label>
                            
                            <input type="checkbox" name="date_tested" value="date_tested" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>OS Version</label>
                            
                            <input type="checkbox" name="os_version" value="os_version" class="check-boxs">
                        </div>
                    </div>
                </div>
            </fieldset>
            <h1>Display</h1>
            <fieldset>
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-6">
                            <h2>Adaptive/Default Mode</h2>
                            <div class="form-group">
                                <label>Display % at 200 nits</label>
                              
                                <input type="checkbox" name="display200nits" value="display200nits" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Color Temperature <small>(as kelvin)</small></label>
                                
                                <input type="checkbox" name="color_temp" value="color_temp" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Max brightness</label>
                                
                                <input type="checkbox" name="max_brightness" value="max_brightness" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Max brightness <small>(auto)</small></label>
                                
                                <input type="checkbox" name="max_brightness_auto" value="max_brightness_auto" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Low brightness</label>
                                
                                <input type="checkbox" name="low_brightness" value="low_brightness" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Low brightness <small>(auto)</small></label>
                                
                                <input type="checkbox" name="low_brightness_auto" value="low_brightness_auto" class="check-boxs">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <h2>Standard Mode</h2>
                            <div class="form-group">
                                <label>Display % at 200 nits</label>
                               
                                <input type="checkbox" name="standard_display200nits" value="standard_display200nits" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Color Temperature <small>as kelvin</small></label>
                                
                                <input type="checkbox" name="standard_color_temp" value="standard_color_temp" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Max brightness</label>
                                
                                <input type="checkbox" name="standard_max_brightness" value="standard_max_brightness" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Max brightness <small>(auto)</small></label>
                                
                                <input type="checkbox" name="standard_max_brightness_auto" value="standard_max_brightness_auto" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Low brightness</label>
                               
                                <input type="checkbox" name="standard_low_brightness" value="standard_low_brightness" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Low brightness <small>(auto)</small></label>
                                
                                <input type="checkbox" name="standard_low_brightness_auto" value="standard_low_brightness_auto" class="check-boxs">
                            </div>
                        </div>
                    </div>
                </div>$(document).ready(function () {
            </fieldset>
            <h1>Audio</h1>
            <fieldset>
                <div class="row">
                    <div class="col-lg-12">
                        <h2>Audio</h2>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Loudspeaker loudness <small>as db</small></label>
                   
                                <input type="checkbox" name="loudspeaker_loudness" value="loudspeaker_loudness" class="check-boxs">
                                
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Headphone Output <small>as volts</small></label>
                                <input type="checkbox" name="headphone_output" value="headphone_output" class="check-boxs">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <h2>Focusrite Readings</h2>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Noise level <small>as dBA</small></label>
                       
                                <input type="checkbox" name="noise_level" value="noise_level" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Total Harmonic Distortion</label>
                 
                                <input type="checkbox" name="total_harmonic" value="total_harmonic" class="check-boxs">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Frequency Response</label>
                         
                                <input type="checkbox" name="frequency_response" value="frequency_response" class="check-boxs">
                            </div>
                        
                        </div>
                    </div>
                </div>
            </fieldset>
            <h1>Battery</h1>
            <fieldset>
                <h2>Battery</h2>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Battery Size <small>as mAh</small></label>
                                
                                <input type="checkbox" name="battery_size" value="battery_size" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>General Battery test <small>as Minutes</small></label>
                                
                                <input type="checkbox" name="gen_battery_size" value="gen_battery_size" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Wi_Fi browsing test <small>as Minutes</small></label>
                                
                                <input type="checkbox" name="browsing_test" value="browsing_test" class="check-boxs">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Gaming Battery Life test <small>as Minutes</small></label>
                                
                                <input type="checkbox" name="gaming_battery_test" value="gaming_battery_test" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Video Playback battery test <small>as Minutes</small></label>
                               
                                <input type="checkbox" name="video_playback_test" value="video_playback_test" class="check-boxs">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <h2>Battery Recharge Time (minutes)</h2>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Charge Full Time</label>
                                <input type="checkbox" name="battery_full_charge" value="battery_full_charge" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>15 min %</label>
                                
                                <input type="checkbox" name="battery_15_min" value="battery_15_min" class="check-boxs">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>30 min %</label>
                              
                                <input type="checkbox" name="battery_30_min" value="battery_30_min" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>60 min %</label>
                                
                                <input type="checkbox" name="battery_60_min" value="battery_60_min" class="check-boxs">
                            </div>
                        </div>
                    </div>
                </div>
            </fieldset>
            <h1>Camera</h1>
            <fieldset>
                <div class="row">
                    <div class="col-lg-12">
                        <h2>Daylight</h2>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Color (<small>ΔC 00 (Saturation corrected)</small></label>
                            
                                <input type="checkbox" name="color_daylight" value="color_daylight" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Noise (<small>%</small></label>
                                
                                <input type="checkbox" name="noise_daylight" value="noise_daylight" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Sharpness <small>(AVG)</small></label>
                                
                                <input type="checkbox" name="camera_sharpness" value="camera_sharpness" class="check-boxs">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Sharpness <small>(Center MTF50)</small></label>
                              
                                <input type="checkbox" name="sharpness_daylight_Center_MTF50" value="sharpness_daylight_Center_MTF50" class="check-boxs">
                            </div>
                            <div class="form-group">
                                <label>Sharpness <small>(Corner average MTF50)</small></label>
                                
                                <input type="checkbox" name="sharpness_daylight_Corner_averageMTF50" value="sharpness_daylight_Corner_averageMTF50" class="check-boxs">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <h2>Lowlight</h2>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Color (<small>ΔC 00 (Saturation corrected)</small></label>
                           
                                <input type="checkbox" name="color_lowlight" value="color_lowlight" class="check-boxs">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Noise (<small>%</small></label>
                             
                                <input type="checkbox" name="noise_lowlight" value="noise_lowlight" class="check-boxs">
                            </div>
                        </div>
                    </div>
                   
                </div>
            </fieldset>
            <h1>Performance</h1>
            <fieldset>
                <h2>Performance</h2>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>AnTuTu</label>
                           
                            <input type="checkbox" name="antutu" value="antutu" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>GFXBench T_Rex HD Onscreen</label>
                            
                            <input type="checkbox" name="hd_onscreen" value="hd_onscreen" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>GFXBench Manhattan Onscreen</label>
                            
                            <input type="checkbox" name="manhattan_onscreen" value="manhattan_onscreen" class="check-boxs">
                        </div>

                        <div class="form-group">
                            <label>Vellamo Metal</label>
                            
                            <input type="checkbox" name="vellamo_metal" value="vellamo_metal" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>Vellamo Browser <small>(default browser)</small></label>
                       
                            <input type="checkbox" name="vellamo_browser" value="vellamo_browser" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>Basemark OS Platform <small>(overall scrore)</small></label>
                            
                            <input type="checkbox" name="basemark_os_platform" value="basemark_os_platform" class="check-boxs">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>JetStream <small>(default browser)</small></label>
                   
                            <input type="checkbox" name="jetstream" value="jetstream" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>Sunspider</label>
                           
                            <input type="checkbox" name="sunspider" value="sunspider" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>GeekBench 4 Single-core</label>
                           
                            <input type="checkbox" name="geekbench_single_core" value="geekbench_single_core" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>GeekBench 4 multi-core</label>
                            
                            <input type="checkbox" name="geekbench_multi_core" value="geekbench_multi_core" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>3DMark test name</label>
                  
                            <input type="checkbox" name="3d_mark_test" value="3d_mark_test" class="check-boxs">
                        </div>
                        <div class="form-group">
                            <label>3DMark overall test scrore</label>
                           
                            <input type="checkbox" name="3d_mark_overall_test" value="3d_mark_overall_test" class="check-boxs">
                        </div>
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
    
    <div id="divShow"></div>
 
<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>


    
    
   <script>
        $(document).ready(function () {
			
			var data5 ="hello";
			
            $("#wizard").steps();
            $("#form").steps({
                bodyTag: "fieldset",
                onStepChanging: function (event, currentIndex, newIndex) {
                    // Always allow going backward even if the current step contains invalid fields!
                    if (currentIndex > newIndex) {
                        return true;
                    }
                    if (newIndex === 3 && Number($("#age").val()) < 18) {
                        return false;
                    }
                    var form = $(this);
     
                    if (currentIndex < newIndex) {
                        // To remove error styles
                        $(".body:eq(" + newIndex + ") label.error", form).remove();
                        $(".body:eq(" + newIndex + ") .error", form).removeClass("error");
                    }
         
                    form.validate().settings.ignore = ":disabled,:hidden";

            
                    return form.valid();
                },
                onStepChanged: function (event, currentIndex, priorIndex) {
                    if (currentIndex === 2 && Number($("#age").val()) >= 18) {
                        $(this).steps("next");
                    }

                    if (currentIndex === 2 && priorIndex === 3) {
                        $(this).steps("previous");
                    }
                },
                onFinishing: function (event, currentIndex) {
                    var form = $(this);
                    
                    
	 
                    form.validate().settings.ignore = ":disabled";

                    return form.valid();
                },
                onFinished: function (event, currentIndex) {
					
					var check = $('input[type=checkbox]:checked').map(function() {return this.value;}).get().join(',');				
                    var form = $(this);                  

                    var data = $('#ModelIds').val().join(',');
                    
                    var newdata = '{"devices": ['+data+'] ,"criteria": "model_id,'+check+'"}';
                    var colm = 'criteria:'+check;
                    
                    var modelss = [];
                    var peram = [];
                    
                   
					
            $.ajax({
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                url: 'http://202.164.62.212:8080/api/getDeviceModelsinfo',
                type: 'PUT',
                data: newdata,
                success: function (response, textStatus, jqXhr) {
                    console.log("Venue Successfully Patched!");
                    
                    var result = response;
                                
                    var str = "model_id,"+check;
                    var obj = [];
                   $.each(response, function (idx, value) {
                       var retObj= BindObj(value,str);
                       obj.push({[value.model_id]: retObj});
                       
                    
                    });
                     $('#divShow').text('');
                    var content = "<table id='datatable2'>";
                       	content +="<tr><th></th>";
                    $.each(obj, function (key, value) {						
						
						
						var i = 0;
							
                        $.each(value, function (idx, val) {
							 var arr = str.split(',');
                           content+="<th>"+ idx+"</th>";
                            $.each(arr, function (index, vl) {
                             //content += "<td>" + val[vl] +"</td>";                            
                          });						                         
                           
                        });							
                    });
                    content += '</tr>';
                    $.each(obj, function (key, value) {
							
                        $.each(value, function (idx, val) {
	
							 var arr = str.split(',');
							
							 modelss.push(idx);
							 
							content +="<tr>";
                            $.each(arr, function (index, vl) {
                             content += "<td>" + val[vl] +"</td>"; 
                             
                              if(index>0){
                                       peram.push(val[vl]);  
                              }                        
                          });	
                           
                          content += '</tr>';					                         
                           
                        });		
                        		
                    });      
                   
                    content += "</table>";
                    $('#divShow').append(content);
                    
                    
                    var checkk = check.split(',');
                     var series_val = [];     
                    var k = 0;
                    for(k = 0; k < checkk.length; k++) { 
						var valo = [107, 31, 635, 203, 12];
		                var a = [checkk[k],valo];
						series_val.push(a);				
					}
					
					var myJsonString = JSON.stringify(series_val);				
					var arrays = $.parseJSON(myJsonString);
		
                   
                     
                     var a = [];
                     
                    for($i=0;$i<series_val.length;$i++){
						var out = {};	
						out['name'] = series_val[$i][0];
						out['data'] = series_val[$i][1];
						a.push(out);
					 }
					
                   Highcharts.chart('container', {
				
					chart: {
						type: 'column'
					},
					title: {
						text: ' '
					},
					subtitle: {
						text: 'Source: <a href="https://en.wikipedia.org/wiki/World_population">Wikipedia.org</a>'
					},
					
					xAxis: {		
						categories:modelss,
						title: {
							text: null
						}
					},
					yAxis: {
							min: 0,
							title: {
								text: 'Population (millions)',
								align: 'high'
							},
							labels: {
								overflow: 'justify'
							}
						},
						tooltip: {
							valueSuffix: 'millions'
						},
						plotOptions: {
							bar: {
								dataLabels: {
									enabled: true
								}
							}
						},
						legend: {
							layout: 'vertical',
							align: 'right',
							verticalAlign: 'top',
							x: -40,
							y: 80,
							floating: true,
							borderWidth: 1,
							backgroundColor: ((Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'),
							shadow: true
						},
						credits: {
							enabled: false
						},
						series:a
					});
																 
                },
                
  
                error: function (jqXHR, textStatus, errorThrown) {
                    // log the error to the console
                    console.log("The following error occured: " + textStatus, errorThrown);
                    
                },
                complete: function () {
                    console.log("Venue Patch Ran");
                }
                

                
            }); 
     
            
            function BindObj(value, str) {
                var arr = str.split(',');
                var obj = {};
                $.each(arr, function (index, val) {

                    obj[val] = value[val];
                });
                return obj;
            }
				
					
                    // Submit form input                
                // form.submit();
                }
            }).validate({
                errorPlacement: function (error, element) {
                    element.before(error);
                },
                rules: {
                    confirm: {
                        equalTo: "#password"
                    }
                }
            });

 var kk = Object.getOwnPropertyNames(response[j]);
                       j++;
        });
$(document).ready(function() {
    $(".numeric").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
         
        
    });
    $(".numeric").attr("maxlength","10")
    
    $('.negitive').on("input", function(){
        this.value = this.value.replace(/[^0-9.-]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');
	});
	
  
    $('.percentage').keyup(function(){
	if ($(this).val() > 100){
		alert("Max Percentage Shouls be 100");
		$(this).val('100');
		}
	});

 });
 

</script>   
    
<script>
Highcharts.chart('container', {
    data: {
        table: 'datatable'
    },
    chart: {
        type: 'column'
    },
    title: {
        text: 'Data extracted from a HTML table in the page'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Units'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    }
});

</script>

     
