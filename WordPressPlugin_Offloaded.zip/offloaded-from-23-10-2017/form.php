

<div class="ibox-content col-md-12">	    
        <form id="form" class="wizard-big" onSubmit="swal('Good job!','Your Data is Submitted Successfully','success')" onclick="this.disabled = true">
            <h1>Model</h1>
            <fieldset>
                <h2>Model</h2>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
							<label>Add Your Model Name</label>
                            <input id="" name="model_id" type="text" class="form-control" >
							
                            <!--<select id="model_id" name="model_id" class="form-control">
                                <option value="">Select A Model</option>
                                <option name="Alcatel_Idol_4s">Alcatel Idol 4s</option>
                                <option name="Apple_iphone_6S">Apple iphone 6S</option>
                                <option name="Apple_iphone_7">Apple iphone 7</option>
                                <option name="Apple_iphone_7_Plus">Apple iphone 7 Plus</option>
                                <option name="Asus_Zenfone_3">Asus Zenfone 3</option>
                                <option name="Asus_Zenfone_3_Deluxe">Asus_Zenfone_3_Deluxe</option>
                                <option name="BlackBerry_DTEK50">BlackBerry DTEK50</option>
                                <option name="BlackBerry_Priv">BlackBerry Priv</option>
                                <option name="Google_Nexus_6P">Google Nexus 6P</option>
                                <option name="Google_Nexus_6P">Google Nexus 6P</option>
                                <option name="Google_Nexus_6P">Google Nexus 6P</option>
                                <option name="Google_Nexus_6P">Google Nexus 6P</option>
                                <option name="Google_Nexus_6P">Google Nexus 6P</option>
                                <option name="Google_Nexus_6P">Google Nexus 6P</option>
                                <option name="Google_Nexus_6P">Google Nexus 6P</option>
                                <option name="Google_Pixel">Google Pixel</option>
                                <option name="Google_Pixel_XL">Google Pixel XL</option>
                                <option name="Google_Pixel_XL(benchmark _test)">Google Pixel XL(benchmark test)</option>
                                <option name="Honor_9">Honor 9</option>
                                <option name="Honor_8">Honor 8</option>
                                <option name="HTC_10">HTC 10</option>
                                <option name="HTC_Bolt">HTC Bolt</option>
                                <option name="HTC_One_A9">HTC One A9</option>
                                <option name="Huawei_Mate_8">Huawei Mate 8</option>
                                <option name="Huawei_Mate_9">Huawei Mate 9</option>
                                <option name="Huawei_Mate_9_Porsche_Design">Huawei Mate 9 Porsche Design</option>
                                <option name="Huawei_Nova">Huawei Nova</option>
                                <option name="Huawei_Nova_Plus">Huawei Nova Plus</option>
                                <option name="Huawei_P10">Huawei P10</option>
                                <option name="Huawei_P10_Lite">Huawei P10 Lite</option>
                                <option name="Huawei_P10_Plus">Huawei P10 Plus</option>
                                <option name="Huawei_P9">Huawei P9</option>
                                <option name="Huawei_P9_Plus">Huawei P9 Plus</option>
                                <option name="LeEco_Le_pro_3">LeEco Le pro 3</option>
                                <option name="LG_G5">LG G5</option>
                                <option name="LG_G6">LG G6</option>
                                <option name="LG_Nexus_5X">LG Nexus 5X</option>
                                <option name="LG_V10">LG V10</option>
                                <option name="LG_V20">LG V20</option>
                                <option name="Meizu_Pro_6">Meizu Pro 6</option>
                                <option name="Moto_G4_Play">Moto G4 Play</option>
                                <option name="Moto_G4_Plus">Moto G4 Plus</option>
                                <option name="Moto_X_Force">Moto X Force</option>
                                <option name="Moto_Z_Droid">Moto Z Droid</option>                            
                            </select> -->
                        </div>
                    </div>
                </div>
            </fieldset>
            <h1>Details</h1>
            <fieldset>
                <h2>Details</h2>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>Tester</label>
                            <input id="tester" name="tester" type="text" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>OEM</label>
                            <input id="oem" name="oem" type="text" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>CPU</label>
                            <input id="cpu" name="cpu" type="text" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>RAM <small>(GB)</small></label>
                            <input id="ram_gb" name="ram_gb" type="text" class="form-control numeric">
                        </div>
                        <div class="form-group">
                            <label>Date Tested</label>
                            <input id="date_tested" name="date_tested" type="text" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>OS Version</label>
                            <input id="os_version" name="os_version" type="text" class="form-control numeric">
                        </div>
                    </div>
                </div>
            </fieldset>
            <h1>Display</h1>
            <fieldset>
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-6">
                            <h2>Adaptive/Default Mode</h2>
                            <div class="form-group">
                                <label>Display % at 200 nits</label>
                                <input id="display200nits" name="display200nits" type="text" class="form-control percentage negitive">
                            </div>
                            <div class="form-group">
                                <label>Color Temperature <small>(as kelvin)</small></label>
                                <input id="color_temp" name="color_temp" type="text" class="form-control numeric">
                            </div>
                            <div class="form-group">
                                <label>Max brightness</label>
                                <input id="max_brightness" name="max_brightness" type="text" class="form-control numeric">
                            </div>
                            <div class="form-group">
                                <label>Max brightness <small>(auto)</small></label>
                                <input id="max_brightness_auto" name="max_brightness_auto" type="text" class="form-control numeric">
                            </div>
                            <div class="form-group">
                                <label>Low brightness</label>
                                <input id="low_brightness" name="low_brightness" type="text" class="form-control numeric">
                            </div>
                            <div class="form-group">
                                <label>Low brightness <small>(auto)</small></label>
                                <input id="low_brightness_auto" name="low_brightness_auto" type="text" class="form-control numeric">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <h2>Standard Mode</h2>
                            <div class="form-group">
                                <label>Display % at 200 nits</label>
                                <input id="standard_display200nits" name="standard_display200nits" type="text" class="form-control percentage negitive">
                            </div>
                            <div class="form-group">
                                <label>Color Temperature <small>as kelvin</small></label>
                                <input id="standard_color_temp" name="standard_color_temp" type="text" class="form-control numeric">
                            </div>
                            <div class="form-group">
                                <label>Max brightness</label>
                                <input id="standard_max_brightness" name="standard_max_brightness" type="text" class="form-control numeric">
                            </div>
                            <div class="form-group">
                                <label>Max brightness <small>(auto)</small></label>
                                <input id="standard_max_brightness_auto" name="standard_max_brightness_auto" type="text" class="form-control numeric">
                            </div>
                            <div class="form-group">
                                <label>Low brightness</label>
                                <input id="standard_low_brightness" name="standard_low_brightness" type="text" class="form-control numeric">
                            </div>
                            <div class="form-group">
                                <label>Low brightness <small>(auto)</small></label>
                                <input id="standard_low_brightness_auto" name="standard_low_brightness_auto" type="text" class="form-control numeric">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="col-lg-6">
                            <h1>Calman Files Uploaded ?</h1>
                            <select id="calman_uploaded" name="calman_uploaded" class="form-control">
                                <option value="Y">Yes</option>
                                <option value="N">No</option>
                            </select>
                        </div>
                    </div>
                </div>
            </fieldset>
            <h1>Audio</h1>
            <fieldset>
                <div class="row">
                    <div class="col-lg-12">
                        <h2>Audio</h2>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Loudspeaker loudness <small>as db</small></label>
                                <input id="loudspeaker_loudness" name="loudspeaker_loudness" type="text" class="form-control numeric">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Headphone Output <small>as volts</small></label>
                                <input id="headphone_output" name="headphone_output" type="text" class="form-control numeric">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <h2>Focusrite Readings</h2>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Noise level <small>as dBA</small></label>
                                <input id="noise_level" name="noise_level" type="text" class="form-control negitive">
                            </div>
                            <div class="form-group">
                                <label>Total Harmonic Distortion</label>
                                <input id="total_harmonic" name="total_harmonic" type="text" class="form-control numeric">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Frequency Response</label>
                                <input id="frequency_response" name="frequency_response" type="text" class="form-control numeric">
                            </div>
                            <div class="form-group">
                                <label>Rightmark Files Uploaded ?</label>
                                <select id="rightmark_uploaded" name="rightmark_uploaded" class="form-control">
                                    <option value="Y">Yes</option>
                                    <option value="N">No</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </fieldset>
            <h1>Battery</h1>
            <fieldset>
                <h2>Battery</h2>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Battery Size <small>as mAh</small></label>
                                <input id="battery_size" name="battery_size" type="text" class="form-control numeric">
                            </div>
                            <div class="form-group">
                                <label>General Battery test <small>as Minutes</small></label>
                                <input id="gen_battery_size" name="gen_battery_size" type="text" class="form-control ">
                            </div>
                            <div class="form-group">
                                <label>Wi_Fi browsing test <small>as Minutes</small></label>
                                <input id="browsing_test" name="browsing_test" type="text" class="form-control ">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Gaming Battery Life test <small>as Minutes</small></label>
                                <input id="gaming_battery_test" name="gaming_battery_test" type="text" class="form-control ">
                            </div>
                            <div class="form-group">
                                <label>Video Playback battery test <small>as Minutes</small></label>
                                <input id="video_playback_test" name="video_playback_test" type="text" class="form-control ">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <h2>Battery Recharge Time (minutes)</h2>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Charge Full Time</label>
                                <input id="battery_full_charge" name="battery_full_charge" type="text" class="form-control numeric">
                            </div>
                            <div class="form-group">
                                <label>15 min %</label>
                                <input id="battery_15_min" name="battery_15_min" type="text" class="form-control ">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>30 min %</label>
                                <input id="battery_30_min" name="battery_30_min" type="text" class="form-control ">
                            </div>
                            <div class="form-group">
                                <label>60 min %</label>
                                <input id="battery_60_min" name="battery_60_min" type="text" class="form-control ">
                            </div>
                        </div>
                    </div>
                </div>
            </fieldset>
            <h1>Camera</h1>
            <fieldset>
                <div class="row">
                    <div class="col-lg-12">
                        <h2>Daylight</h2>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Color (<small>ΔC 00 (Saturation corrected)</small></label>
                                <input id="color_daylight" name="color_daylight" type="text" class="form-control ">
                            </div>
                            <div class="form-group">
                                <label>Noise (<small>%</small></label>
                                <input id="noise_daylight" name="noise_daylight" type="text" class="form-control ">
                            </div>
                            <div class="form-group">
                                <label>Sharpness <small>(AVG)</small></label>
                                <input id="camera_sharpness" name="camera_sharpness" type="text" class="form-control ">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Sharpness <small>(Center MTF50)</small></label>
                                <input id="sharpness_daylight_Center_MTF50" name="sharpness_daylight_Center_MTF50" type="text" class="form-control ">
                            </div>
                            <div class="form-group">
                                <label>Sharpness <small>(Corner average MTF50)</small></label>
                                <input id="sharpness_daylight_Corner_averageMTF50" name="sharpness_daylight_Corner_averageMTF50" type="text" class="form-control ">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <h2>Lowlight</h2>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Color (<small>ΔC 00 (Saturation corrected)</small></label>
                                <input id="color_lowlight" name="color_lowlight" type="text" class="form-control ">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Noise (<small>%</small></label>
                                <input id="noise_lowlight" name="noise_lowlight" type="text" class="form-control ">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="col-lg-6">
                            <h1>Camera Samples Uploaded to Drive ?</h1>
                            <select id="camera_sample_uploaded_drive" name="camera_sample_uploaded_drive" class="form-control ">
                                <option value="Y">Yes</option>
                                <option value="N">No</option>
                            </select>
                        </div>
                    </div>
                </div>
            </fieldset>
            <h1>Performance</h1>
            <fieldset>
                <h2>Performance</h2>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>AnTuTu</label>
                            <input id="antutu" name="antutu" type="text" class="form-control numeric">
                        </div>
                        <div class="form-group">
                            <label>GFXBench T_Rex HD Onscreen</label>
                            <input id="hd_onscreen" name="hd_onscreen" type="text" class="form-control numeric">
                        </div>
                        <div class="form-group">
                            <label>GFXBench Manhattan Onscreen</label>
                            <input id="manhattan_onscreen" name="manhattan_onscreen" type="text" class="form-control numeric">
                        </div>

                        <div class="form-group">
                            <label>Vellamo Metal</label>
                            <input id="vellamo_metal" name="vellamo_metal" type="text" class="form-control numeric">
                        </div>
                        <div class="form-group">
                            <label>Vellamo Browser <small>(default browser)</small></label>
                            <input id="vellamo_browser" name="vellamo_browser" type="text" class="form-control numeric">
                        </div>
                        <div class="form-group">
                            <label>Basemark OS Platform <small>(overall scrore)</small></label>
                            <input id="basemark_os_platform" name="basemark_os_platform" type="text" class="form-control numeric">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>JetStream <small>(default browser)</small></label>
                            <input id="jetstream" name="jetstream" type="text" class="form-control numeric">
                        </div>
                        <div class="form-group">
                            <label>Sunspider</label>
                            <input id="sunspider" name="sunspider" type="text" class="form-control ">
                        </div>
                        <div class="form-group">
                            <label>GeekBench 4 Single-core</label>
                            <input id="geekbench_single_core" name="geekbench_single_core" type="text" class="form-control numeric">
                        </div>
                        <div class="form-group">
                            <label>GeekBench 4 multi-core</label>
                            <input id="geekbench_multi_core" name="geekbench_multi_core" type="text" class="form-control numeric">
                        </div>
                        <div class="form-group">
                            <label>3DMark test name</label>
                            <input id="3d_mark_test" name="3d_mark_test" type="text" class="form-control ">
                        </div>
                        <div class="form-group">
                            <label>3DMark overall test scrore</label>
                            <input id="3d_mark_overall_test" name="3d_mark_overall_test" type="text" class="form-control numeric">
                        </div>
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
    
   <script>
        $(document).ready(function () {
            $("#wizard").steps();
            $("#form").steps({
                bodyTag: "fieldset",
                onStepChanging: function (event, currentIndex, newIndex) {
                    // Always allow going backward even if the current step contains invalid fields!
                    if (currentIndex > newIndex) {
                        return true;
                    }
                    if (newIndex === 3 && Number($("#age").val()) < 18) {
                        return false;
                    }
                    var form = $(this);
     
                    if (currentIndex < newIndex) {
                        // To remove error styles
                        $(".body:eq(" + newIndex + ") label.error", form).remove();
                        $(".body:eq(" + newIndex + ") .error", form).removeClass("error");
                    }
         
                    form.validate().settings.ignore = ":disabled,:hidden";

            
                    return form.valid();
                },
                onStepChanged: function (event, currentIndex, priorIndex) {
                    if (currentIndex === 2 && Number($("#age").val()) >= 18) {
                        $(this).steps("next");
                    }

                    if (currentIndex === 2 && priorIndex === 3) {
                        $(this).steps("previous");
                    }
                },
                onFinishing: function (event, currentIndex) {
                    var form = $(this);
                    
                    
	 
                    form.validate().settings.ignore = ":disabled";

                    return form.valid();
                },
                onFinished: function (event, currentIndex) {
                    var form = $(this);
                    
                    var data = $('form').serialize();
				    $.post('http://202.164.62.212:8080/api/insertDeviceInfo', data);
					
                    // Submit form input
                    form.submit();
                }
            }).validate({
                errorPlacement: function (error, element) {
                    element.before(error);
                },
                rules: {
                    confirm: {
                        equalTo: "#password"
                    }
                }
            });
        });
$(document).ready(function() {
    $(".numeric").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
        
       
        
    });
    $(".numeric").attr("maxlength","10")
    
    $('.negitive').on("input", function(){
        this.value = this.value.replace(/[^0-9.-]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');
	});
	
  
    $('.percentage').keyup(function(){
	if ($(this).val() > 100){
		alert("Max Percentage Shouls be 100");
		$(this).val('100');
		}
	});

 });

    </script>    
