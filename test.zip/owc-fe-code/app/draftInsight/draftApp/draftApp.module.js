(function(){
	'use strict';

	//Manual bootstrap application
	google.load('visualization', '1', { packages: ['corechart', 'line', 'table'], 'language': 'nl' });

	google.setOnLoadCallback(function() {
	  angular.bootstrap(document, ['olympia-draftApp']);
	});

	angular.module('olympia-draftApp', [
		/* 3rd Party*/
		'ui.router',
		'ui.bootstrap-slider',

		/*Shared modules*/
		'core.module',

		/*Helper*/
		'lineChart.module',
		'loader.module',
		'ontdek.module',
		'dateRange.module',
		'dateTimePicker.module',
		'richTextEditor.module',
		'uiAutocomplete.module',

		/*Application specific*/
        'fms.module',
		'fmsVacature.module',
		'keywordPlanner.module',
		'publicatieInhoud.module',
		'forecast.module',
		'instroom.module',
		'publiceren.module',
		'opdracht.module',
        'vestigingsOverzicht.module',
        'zichtbaarheidOverzicht.module',
        'conversieOverzicht.module',
        'user.module',
        'new.module',
        'editVacature.module',
        'conceptsPreview.module',
        'aanbodAnalyse.module'
	]);
})();
