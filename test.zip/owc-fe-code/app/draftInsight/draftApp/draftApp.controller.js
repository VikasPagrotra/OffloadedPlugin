(function () {
    'use strict';
    angular.module('olympia-draftApp')
		.controller('draftAppCntl', draftAppCntl);

    draftAppCntl.$inject = ['ontdekService', '$location', 'keywordPlannerService', 'draftAppService', '$scope', '$timeout', '$state', 'publicatieInhoudService', 'forecastService', 'publicerenService', 'dateRangeService', 'lineChartService', 'coreService', 'instroomModel', '$interval', 'opdrachtService', 'loaderService', '$window', '$rootScope', 'enumApp', 'instroomService', '$q', '$sce'];

    function draftAppCntl(ontdekService, $location, keywordPlannerService, draftAppService, $scope, $timeout, $state, publicatieInhoudService, forecastService, publicerenService, dateRangeService, lineChartService, coreService, instroomModel, $interval, opdrachtService, loaderService, $window, $rootScope, enumApp, instroomService, $q, $sce) {

        var vm = this,
            url = "";
        vm.ssoEnabled = true;

        vm.signOut = signOut;

        function signOut() {
            draftAppService.signOut().then(function (data) {
                var landingUrl = "http://" + $window.location.host + "/account/login";
                $window.location.href = landingUrl;
            });
        };

        $rootScope.$on("$locationChangeStart", function (event, next, current) {
            if (next.indexOf('#/new') != -1 && vm.userSession.Permissions.indexOf('Vacature Creeren') == -1) {
                event.preventDefault();
            }
        });

        $scope.appResources = {};
        vm.setLanguage = setLanguage;

        vm.initializeResources = initializeResources;

        vm.initializeResources();

        vm.publicationDateRange = {};
        vm.selectedChannels = [];

        draftAppService.getUserSession().then(function (data) {
            vm.userSession = data;
            loaderService.toggle(false);
        });
        draftAppService.ssoEnabled().then(function (data) {
            vm.ssoEnabled = data;
        });
        //this is for kanalenmix(instroom)
        vm.addThisToChannels = addThisToChannels;
        vm.addChannelToConcept = addChannelToConcept;

        vm.bestaandKlantList = opdrachtService.bestaandKlantList;

        vm.aantalconcurrenetnList = opdrachtService.aantalconcurrenetnList;

        vm.vacatureprioreitList = opdrachtService.vacatureprioreitList;

        vm.showPublicatieDiscard = false;
        vm.similarJobsCount = -1;

        vm.disableTabGreaterThanOpdracht = false;

        vm.disableTabGreaterThanKeywords = false;

        vm.disableTab = false;

        vm.spinTheRefreshIcon = false;

        vm.changeTimeOfPublication = changeTimeOfPublication;

        vm.publishPublicatieChanges = publishPublicatieChanges;

        vm.changeTemplateContents = changeTemplateContents;
        vm.templateValid = {};
        vm.templateValid.isValidThankYouContent = true;
        vm.templateValid.isValidConfirmationContent = true;

        vm.checkForAllFilledOn = checkForAllFilledOn;

        vm.openLastClosedConcept = openLastClosedConcept;

        vm.resultatenOverzicht = resultatenOverzicht;

        vm.saveConceptValue = saveConceptValue;

        vm.showBackToConcept = false;

        vm.copyFMSVacatureHere = copyFMSVacatureHere; // use math in the view

        vm.Math = window.Math;

        vm.getLiveCount = getLiveCount;

        vm.changeInDiscoveryKeuwords = changeInDiscoveryKeuwords;
        //vm.initializeTheSelectedKeywords = initializeTheSelectedKeywords;

        vm.fullPartTimeKeywords = keywordPlannerService.fullPartTimeKeywords;
        vm.isExceededMaxValue = isExceededMaxValue;
        vm.hoverIn = hoverIn;
        vm.hoverOut = hoverOut;
        vm.settings = {};
        vm.openPopup = openPopup;
        vm.openPopupSection = openPopupSection;
        vm.showStudentKeywordAlarm = false;

        vm.plagiarism = [];
        vm.conceptPlagiarism = [];
        vm.aantalPlagSelected = {};

        vm.openPlagiarismOverlay = openPlagiarismOverlay;
        vm.loadPlagDataForCNP = loadPlagDataForCNP;
        vm.openLastAddedView = openLastAddedView;

        vm.showBackToAantal = false;
        vm.showPublicationsInSideMenu = false;
        vm.showConceptsInSideMenu = false;
        vm.newDomain = '';
        vm.addNewDomain = addNewDomain;
        vm.showDomainMessage = false;
        vm.domainMessage = '';
        vm.isDomainCreated = false;
        vm.domains = [];
        vm.loadDomains = loadDomains;

        $scope.$on('fullPartTimeKeywordsFetched', function (event, data) {
            vm.fullPartTimeKeywords = data;
        }, true);

        vm.contractDurationKeywords = keywordPlannerService.contractDurationKeywords;
        $scope.$on('contractDurationKeywordsFetched', function (event, data) {
            vm.contractDurationKeywords = data;
        }, true);

        $scope.$on('aanbodScrapeJobs', function (event, data) {
            vm.aanbodScrapejobs = data;
        }, true);

        $scope.$on('removeTogglePopup', function (event, data) {
            if (data.data == 'remove-additionele') {
                togglePopup(false, '', false);
                coreService.showalertMessage('additionele-alert');
            }
        }, true);

        draftAppService.getSettings().then(resolveSettings);

        function resolveSettings(data) {
            vm.settings.companyName = data.CompanyName;
            vm.settings.logoUrl = data.LogoUrl;
            // html builder settings
            vm.settings.isHtmlBuilderEnabled = data.IsHtmlBuilderEnabled;
            vm.settings.htmlBuilderUrl = $sce.trustAsResourceUrl(data.HtmlBuilderUrl);;
            vm.settings.htmlPagesUrl = data.HtmlPagesUrl;;
            vm.settings.editVacatureEnabled = data.editVacatureEnabled;
            // instroom active features
            vm.settings.activeInstroomFeatures = data.ActiveInstroomFeatures;
            instroomModel.settings = vm.settings;
            // load domain of html builder
            vm.loadDomains();
        }

        var countDisableOpdracht = 0, countDisableKeyword = 0;
        $interval(function () {
            // compare main obj
            if (!angular.equals(vm.vacature, vm.vacatureBackup)) {
                draftAppService.saveVacature(vm.vacature, vm.activeTab);
                vm.vacatureBackup = angular.copy(vm.vacature);
                //Check for opdracht page
            }
            if (angular.isDefined(vm.vacature)) {
                calculateTotalForUrenEnMarge();
                if (vm.vacature.opdracht.bestaandKlant == '' || vm.vacature.opdracht.aantalconcurrenetn == '' || vm.vacature.opdracht.priority == '' || vm.vacature.opdracht.urenEnMarge.total == 0) {
                    vm.disableTabGreaterThanOpdracht = true;
                    countDisableOpdracht = 0;
                } else {
                    vm.disableTabGreaterThanOpdracht = false;
                    if (vm.vacature.keywords.funcKeywords.length == 0 || vm.vacature.keywords.locKeywords.length == 0 || vm.vacature.keywords.fullPartTimeKeywords.length == 0 || vm.vacature.keywords.contractDurationKeywords.length == 0 || vm.vacature.selectedProfile == null) {
                        vm.disableTabGreaterThanKeywords = true;
                        countDisableKeyword = 0;
                    } else {
                        vm.disableTabGreaterThanKeywords = false;

                        if (countDisableKeyword == 0) {
                            countDisableKeyword++;
                            vm.disableTab = false;
                        }
                    }

                    if (countDisableOpdracht == 0) {
                        countDisableOpdracht++;
                        vm.disableTab = false;
                    }
                }
            }



            if (vm.publicatieDataBackup != undefined && !angular.equals(vm.publicatieData, vm.publicatieDataBackup)) {
                // change noOfDays=0 if updated
                vm.publicatieData.noOfDays = 0;
                vm.publicatieData.updateDate = moment.tz(new Date(), "Europe/Amsterdam").format('DD-MM-YYYY [om] HH:mm');
                vm.publicatieDataBackup = angular.copy(vm.publicatieData);
                // if(JSON.stringify(vm.publicatieDataBackup) == JSON.stringify({})){
                // 	if(vm.vacature != null && vm.publicatieData != null)
                // 		draftAppService.getAdvice(vm.vacature, vm.publicatesConcept).then(resolveAdviceData);
                // }else{
                // 	vm.showPublicatieDiscard = true;
                // }
                vm.spinTheRefreshIcon = true;
                draftAppService.getAdvice(vm.vacature, vm.publicatesConcept).then(resolveAdviceData, errorAdviceData);
            }
        }, 100);

        // get tags
        draftAppService.getTagsSets().then(resolveTagsSets);
        function resolveTagsSets(data) {
            vm.tags = data;
        }

        function publishPublicatieChanges(data) {
            vm.showPublicatieDiscard = false;
            if (!data) {
                //discard changes
                vm.publicatieData = angular.copy(vm.publicatieDataBackup);
            } else {
                //accept changes and updated the backup object
                vm.publicatieDataBackup = angular.copy(vm.publicatieData);
            }
        }

        function resolveAdviceData(data) {
            if (data) {
                vm.spinTheRefreshIcon = false;
                vm.publicatieData.advices = data;
                vm.publicatieData.publicatieScore = Math.round(data[0].advice[0].adviceTitle);
            }
            //fill the backup data with the latest object
            vm.publicatieDataBackup = angular.copy(vm.publicatieData);
        };

        function errorAdviceData(error) {
            vm.spinTheRefreshIcon = false;
            console.log(error);
        }

        $scope.$on('vacatureFetched', function (event, vacature) {
            // get current fmsId from route.
            $window.scrollTo(0, 0);
            var currentFmsId = $state.params.fmsId;

            vm.vacature = vacature;
            vm.vacatureBackup = angular.copy(vm.vacature);
            if (vm.activeTab === "mijnPublicaties.vacature") {

            }

            if (vm.activeTab === "mijnPublicaties.opdracht") {
                //opdracht page
                opdrachtService.planBucket['bestaandeklant'].data = vm.vacature.opdracht.bestaandKlant;
                opdrachtService.planBucket['aantalconcurrenetn'].data = vm.vacature.opdracht.aantalconcurrenetn;
                opdrachtService.planBucket['vacatureprioreit'].data = vm.vacature.opdracht.priority;
                vm.opdrachtPlanBucket = opdrachtService.planBucket;

                //to select the previous existing client type
                angular.forEach(vm.bestaandKlantList, function (item) {
                    if (vm.vacature.opdracht.bestaandKlant === item.label) {
                        item.addToPlan = true;
                    }
                });

                angular.forEach(vm.aantalconcurrenetnList, function (item) {
                    if (vm.vacature.opdracht.aantalconcurrenetn === item.label) {
                        item.addToPlan = true;
                    }
                });

                angular.forEach(vm.vacatureprioreitList, function (item) {
                    if (vm.vacature.opdracht.priority === item.label) {
                        item.addToPlan = true;
                    }
                });
            }

            if (vm.activeTab === "mijnPublicaties.keywords") {
                keywordPlannerService.planBucket['fullPartTime'].data = vm.vacature.keywords.fullParttime;
                keywordPlannerService.planBucket['keywordPlanner'].data = vm.vacature.keywords.funcKeywords;
                keywordPlannerService.planBucket['recruitmentArea'].data = vm.vacature.keywords.locKeywords;
                keywordPlannerService.planBucket['discoverKeywords'].data = vm.vacature.keywords.discoverKeywords;
                keywordPlannerService.planBucket['fullPartTimeKeywords'].data = vm.vacature.keywords.fullPartTimeKeywords;
                keywordPlannerService.planBucket['contractDuur'].data = vm.vacature.keywords.contractDuration;
                keywordPlannerService.planBucket['contractDurationKeywords'].data = vm.vacature.keywords.contractDurationKeywords;
                vm.planBucket = keywordPlannerService.planBucket;
                vm.planBucketBackup = angular.copy(vm.planBucket);
                vm.showStudentKeywordAlarm = keywordPlannerService.isAlarmedStudentKeywordsUsed(vm.planBucket['fullPartTimeKeywords'].data);

                angular.forEach(vm.dummyFullPartTime, function (item) {
                    if (vm.vacature.keywords.fullParttime === item.label) {
                        item.addToPlan = true;
                    }
                });

                angular.forEach(vm.dummyContractduur, function (item) {
                    if (vm.vacature.keywords.contractDuration === item.label) {
                        item.addToPlan = true;
                    }
                });

                var stopfullPartTime = $interval(function () {
                    var isDefinded = angular.isDefined(vm.fullPartTimeKeywords);
                    angular.forEach(vm.fullPartTimeKeywords, function (item) {
                        angular.forEach(vm.vacature.keywords.fullPartTimeKeywords, function (selectedItem) {
                            if (selectedItem && selectedItem.keyword === item.keyword) {
                                item.addToPlan = true;
                            }
                        });
                    });

                    if (isDefinded) {
                        $interval.cancel(stopfullPartTime);
                    }
                }, 500);

                // contract duration selection
                angular.forEach(vm.dummyContractduur, function (item) {
                    if (vm.vacature.keywords.contractDuration === item.label) {
                        item.addToPlan = true;
                    }
                });

                var stopContractDuration = $interval(function () {
                    var isDefinded = angular.isDefined(vm.contractDurationKeywords);
                    angular.forEach(vm.contractDurationKeywords, function (item) {
                        angular.forEach(vm.vacature.keywords.contractDurationKeywords, function (selectedItem) {
                            if (selectedItem && selectedItem.keyword === item.keyword) {
                                item.addToPlan = true;
                            }
                        });
                    });

                    if (isDefinded) {
                        $interval.cancel(stopContractDuration);
                    }
                }, 500);
                // fetch default keywords
                if (vm.vacature.functionKeys.length > 0) {
                    vm.selectedKeywords = angular.copy(vm.vacature.functionKeys);
                    vm.fetchFunctionKeywords(vm.selectedKeywords);
                }

                // fetch default locations
                if (vm.vacature.fmsCity !== '') {
                    vm.fetchLocations(vm.vacature.fmsCity);
                }
            }

            //if (vm.activeTab === "mijnPublicaties.conceptsPreview") {                

            //}

            if (vm.activeTab === "mijnPublicaties.forecast") {

            }

            if (vm.activeTab === "mijnPublicaties.instroom") {
                var stopChannels = $interval(function () {
                    var isDefinded = angular.isDefined(vm.vacatureChannels);

                    angular.forEach(vm.vacatureChannels, function (item) {
                        // push preselected channels
                        if (item.preSelected &&
                            vm.vacature.instroom.channels.indexOf(item.class) === -1 &&
                            vm.vacature.instroom.unselectedChannels.indexOf(item.class) === -1) {
                            vm.vacature.instroom.channels.push(item.class);
                        }

                        if (vm.vacature.instroom.channels.indexOf(item.class) > -1) {
                            item.selected = true;
                        }

                        if (item.preSelected &&
                            vm.selectedChannels.indexOf(item.class) === -1) {
                            addChannelToSelected(item);
                        }
                    });

                    if (isDefinded) {
                        $interval.cancel(stopChannels);
                    }
                }, 500);

                // add custom template to instroom.templateContentents if exists
                if (instroomModel.emailTemplate["custom"] == null && vm.vacature.instroom.templateContents.type == "custom") {
                    var customTemplate = {
                        "custom": {
                            "type": "custom",
                            "pageTitle": vm.vacature.instroom.templateContents.confirmationTitle,
                            "pageBody": vm.vacature.instroom.templateContents.confirmationContent,
                            "pageRows": 7,
                            "emailRows": 10,
                            "emailTitle": vm.vacature.instroom.templateContents.emailTitle,
                            "emailBody": vm.vacature.instroom.templateContents.emailContent
                        }
                    };
                    angular.extend(instroomModel.emailTemplate, customTemplate);
                    vm.instroomBedankpagina = instroomModel.emailTemplate;
                }
                draftAppService.initPopover('.btn-popup');
                // get the selected template acording to the template stored in vacature object
                vm.selectedTemplate = angular.copy(vm.instroomBedankpagina[vm.vacature.instroom.templateContents.type]);
                vm.templateBackup = angular.copy(vm.selectedTemplate);
                vm.liveLength = getLiveCount();
                // contents
                if (!angular.equals(vm.selectedTemplate, vm.templateBackup)) {
                    // before save change type to custom if user change any
                    changeTemplateContents(false);
                }
            }

            if (vm.activeTab === "mijnPublicaties.publicatieInhoud") {
                //publicatie inhound and concpeten page
                vm.publicatieInhoundDataPs = publicatieInhoudService.publicatieInhoundDataPs = vm.vacature.publicatieInhoud.publications;
                vm.publicatieInhoundDataCs = publicatieInhoudService.publicatieInhoundDataCs = vm.vacature.publicatieInhoud.drafts;
                var city = vm.vacature.fmsVacature.city;
                var q = vm.vacature.fmsVacature.organisatieOmschrijving.content
                    + ' ' + vm.vacature.fmsVacature.onsAanbod.content
                    + ' ' + vm.vacature.fmsVacature.wijVragen.content
                    + ' ' + vm.vacature.fmsVacature.functieOmschrijving.content;
                draftAppService.plagiarismCheck(city, q).then(function (data) {
                    vm.plagiarism = data;
                    var today = moment();
                    angular.forEach(vm.plagiarism, function (item) {
                        item.isOffline = today.diff(moment(item.updatedOn), 'days') > 1;
                    });
                });
            }

            if (vm.activeTab === "mijnPublicaties.publiceren") {
                //publicatie inhound and concpeten page
                vm.publicatieInhoundDataPs = publicatieInhoudService.publicatieInhoundDataPs = vm.vacature.publicatieInhoud.publications;
                vm.publicatieInhoundDataCs = publicatieInhoudService.publicatieInhoundDataCs = vm.vacature.publicatieInhoud.drafts;
            }

            // fetch default keywords if there are old functions
            //if (vm.vacature.functionKeys != null && vm.vacature.functionKeys.length && vm.functionSearchKeys && vm.functionSearchKeys.length) {
            //    initializeTheSelectedKeywords(vm.vacature.functionKeys, vm.functionSearchKeys);
            //}
            vm.similarJobsCount = -1;
            if (draftAppService.prevFmsId === '' || draftAppService.prevFmsId !== currentFmsId) {
                //console.log('Prev fmsId:', draftAppService.prevFmsId);
                //console.log('current fmsId:', currentFmsId);



                // pass user id or office id according to bussiness
                draftAppService.getVacatureChannels(vm.vacature.vacatureExtras.job_branch).then(resolveVacatureChannels);

                // get similar jobs
                draftAppService.getSimilarJobs(currentFmsId).then(function (data) {
                    vm.similarJobs = data;
                    vm.similarJobsCount = (data) ? data.length : 0;
                }, function (data) {
                    console.log("Error: " + data);
                    vm.similarJobsCount = 0;
                });
            }
            else {
                vm.similarJobsCount = (vm.similarJobs) ? vm.similarJobs.length : 0;
            }

            // set the previous vacature fmsid with the current if null
            draftAppService.prevFmsId = currentFmsId; //vm.vacature.fmsId;


        }, true);

        function resolveVacatureChannels(data) {
            vm.vacatureChannels = draftAppService.vacatureChannels = data;
        }

        vm.numbers = [];
        for (var i = 1; i <= 100; i++) {
            vm.numbers.push(i);
        }

        function getLiveCount() {
            var pubCount = 0;
            angular.forEach(vm.vacature.publicatieInhoud.publications, function (publicatie) {
                var isVacatureOffline = vm.vacature.isOffline;
                var isOffline = publicatie.isOffline;
                var startDate = moment(publicatie.vandaag, 'DD/MM/YYYY hh:mm');
                var endDate = moment(publicatie.afsluiting, 'DD/MM/YYYY hh:mm');
                var currentTime = moment(new Date());

                if (!isVacatureOffline && startDate <= currentTime && endDate >= currentTime && !isOffline) {
                    var validateObj = publicatieInhoudService.checkValidConcept(publicatie, vm.vacature);
                    if (validateObj.isValidPub && publicatie.publishDate != null) {
                        // "Live!";
                        pubCount++;
                    }
                }
            });
            return pubCount;
        }

        // vm.activeTab = 'mijnPublicaties.FMSvacature';

        vm.keywordView = "";

        vm.publicatesConcept = "";

        vm.stringPublicatesConcept = "";

        vm.wizrad = [];

        vm.showBreadkcrumb = true;

        vm.showPopup = false;

        vm.showAdvices = false;

        vm.showInputTag = false;

        vm.iskeywordPlanner = false;

        vm.iskeywordSection = false;

        vm.isForecast = false;

        vm.isInstroomSection = false;

        vm.hideShowPlanner = false;

        vm.hideShowSideMenu = false;

        vm.isWizard = 'false';

        vm.isCurrentWizard = '';

        vm.fetchLocations = fetchLocations;

        vm.fetchFunctionKeywords = fetchFunctionKeywords;

        vm.fetchDiscoveredKeywords = fetchDiscoveredKeywords;

        vm.functionSearchKeys = [];

        $scope.$on('searchFunctionKeysFetched', function (event, data) {
            vm.functionSearchKeys = data;
            vm.ontdekSearchKeys = [];
            angular.forEach(vm.functionSearchKeys, function (item) {
                if (item.key != null) {
                    vm.ontdekSearchKeys.push(item.key);
                }
            });

            //if (angular.isDefined(vm.vacature))
            //    initializeTheSelectedKeywords(vm.vacature.functionKeys, data)
        }, true);

        vm.dummyFullPartTime = keywordPlannerService.dummyFullPartTime;

        //vm.dummyRecruitmentTable = keywordPlannerService.dummyRecruitmentTable;

        vm.dummyContractduur = keywordPlannerService.dummyContractduur;

        $scope.$on('fmsLocationsFetched', function (event, data) {
            vm.fmsLocations = data;
        }, true);


        vm.instroomBedankpagina = instroomModel.emailTemplate;
        vm.allowedThankYouPlaceholders = instroomModel.allowedThankYouPlaceholders;
        vm.allowedConfirmationPlaceholders = instroomModel.allowedConfirmationPlaceholders;

        vm.changeActiveTab = changeActiveTab;

        vm.tabIsDisabled = tabIsDisabled;

        vm.removeThisToPlan = removeThisToPlan;

        vm.removeDiscoverFromPlan = removeDiscoverFromPlan;

        vm.returnPartial = returnPartial;

        vm.togglePopup = togglePopup;

        vm.closeOverlayOnClickingShadow = closeOverlayOnClickingShadow;

        vm.isPublicationConcept = isPublicationConcept;

        //vm.loadChart = loadChart;

        vm.loadForecastChart = loadForecastChart;

        vm.manuallyupdateScore = manuallyupdateScore;

        vm.toggleAdvices = toggleAdvices;

        vm.toggleBodyClass = toggleBodyClass;

        vm.inputTagValue = draftAppService.inputTagValue;

        vm.backPageName = backPageName;

        //Set current wizrad - keywordplanner or instroom
        vm.setCurrentWizard = setCurrentWizard;

        vm.wizardButtonShow = wizardButtonShow;

        vm.isPublicatesView = isPublicatesView;

        //resultanet page variables and function
        vm.tableData = {};
        vm.dateRange = {};
        vm.displayMode = { mode: 'chart', title: 'Show Map' };
        vm.chartPeriod = "Dag";
        vm.rawData = {};
        vm.mapsEnabled = coreService.isMapsEnabled();

        vm.changeDisplayMode = changeDisplayMode;
        vm.getJobViews = getJobViews;
        vm.changeChartPeriod = changeChartPeriod;
        vm.convertSecondsToDate = convertSecondsToDate;
        vm.publishConcept = publishConcept;

        vm.changeSalaryToDutch = changeSalaryToDutch;
        vm.changeSalToDutch = changeSalToDutch;

        vm.textareaResizable = textareaResizable;

        $scope.$watch('vModel.dateRange', dateRangeWatcher, true);

        vm.addThisToPlan = function (index, data, label, obj) {
            var arr = [], keyToDelete = [];
            if (label === 'fullPartTime' || label === 'contractDuur') {
                keywordPlannerService.planBucket[label].data = [];
                keywordPlannerService.planBucket[label].data.push(data);
                angular.forEach(obj, function (value, key) {
                    if (value.label === data.label) {
                        value.addToPlan = true;
                        if (label === 'contractDuur') {
                            vm.vacature.keywords.contractDuration = data.label;
                        }
                    } else {
                        value.addToPlan = false;
                    }
                });
            } else if (label === 'keywordPlanner') {
                data.addToPlan = true;
                var elementPos = obj.map(function (x) {
                    return x.keyword;
                }).indexOf(data.keyword);
                keywordPlannerService.planBucket[label].data.push(data);
                obj.splice(elementPos, 1);
            } else if (label === 'recruitmentArea') {
                data.addToPlan = true;
                var elementPos = obj.map(function (x) {
                    return x.location;
                }).indexOf(data.location);
                keywordPlannerService.planBucket[label].data.push(data);
                obj.splice(elementPos, 1);
            } else if (label === 'bestaandeklant' || label === 'aantalconcurrenetn' || label === 'vacatureprioreit') {
                opdrachtService.planBucket[label].data = [];
                opdrachtService.planBucket[label].data.push(data);
                angular.forEach(obj, function (value, key) {
                    if (value.label === data.label) {
                        value.addToPlan = true;
                        if (label === 'bestaandeklant')
                            vm.vacature.opdracht.bestaandKlant = data.label;
                        else if (label === 'aantalconcurrenetn')
                            vm.vacature.opdracht.aantalconcurrenetn = data.label;
                        else if (label === 'vacatureprioreit')
                            vm.vacature.opdracht.priority = data.label;
                    } else {
                        value.addToPlan = false;
                    }
                });
            } else if (label === 'fullPartTimeKeywords') {
                data.addToPlan = true;
                var elementPos = obj.map(function (x) {
                    return x.keyword;
                }).indexOf(data.keyword);
                keywordPlannerService.planBucket[label].data.push(data);
                obj.splice(elementPos, 1);
                vm.showStudentKeywordAlarm = keywordPlannerService.isAlarmedStudentKeywordsUsed(vm.planBucket['fullPartTimeKeywords'].data);
            } else if (label === 'contractDurationKeywords') {
                data.addToPlan = true;
                var elementPos = obj.map(function (x) {
                    return x.keyword;
                }).indexOf(data.keyword);
                keywordPlannerService.planBucket[label].data.push(data);
                obj.splice(elementPos, 1);
            } else if (label === 'discoverKeywords') {
                data.addToPlan = true;
                var elementPos = obj.map(function (x) {
                    return x.target;
                }).indexOf(data.target);
                keywordPlannerService.planBucket[label].data.push(data.target);
                obj.splice(elementPos, 1);
            } else {
                data.addToPlan = true;
                keywordPlannerService.planBucket[label].data.push(data);
                obj.splice(index, 1);
            }

            // update db object
            if (label === 'fullPartTime') {
                // vm.vacature.fullParttime = '';
                // angular.forEach(keywordPlannerService.planBucket[label].data, function (value, key) {
                // 	vm.vacature.fullParttime += value.label + ' ';
                // });
                vm.vacature.keywords.fullParttime = data.label;
            }
            else if (label === 'keywordPlanner') {
                vm.vacature.keywords.funcKeywords = keywordPlannerService.planBucket[label].data;
            }
            else if (label === 'recruitmentArea') {
                vm.vacature.keywords.locKeywords = keywordPlannerService.planBucket[label].data;
            }
            else if (label === 'discoverKeywords') {
                vm.vacature.keywords.discoverKeywords = keywordPlannerService.planBucket[label].data;
            }
        }

        $scope.$on('openPopup', function (data, obj) {
            // todo: pass actual url.
            togglePopup(true, obj.view);
            if (obj.view == "publiceren") {
                vm.concept = angular.copy(vm.publicatieInhoundDataCs[obj.index]);
                vm.concept.index = obj.index;
            }
            else if (obj.view == "forecastePat") {
                vm.activeForecastModelData = angular.copy(obj.data);
                vm.activeForecastModelData.index = obj.index;
            }
        }, true);

        $scope.$on('openPopupSection', function (data, obj) {
            togglePopup(true, obj.view, true);
            setCurrentWizard(obj.view);
            wizardButtonShow(obj.screen);

            if (obj.view == "forecastPat") {
                loadForecastChart();
            } else if (obj.view == "publiceren") {
                //vm.publicatieData = vm.publicatieInhoundDataCs[obj.screen];
                //vm.publicatieData.index = obj.screen;

                vm.concept = angular.copy(vm.publicatieInhoundDataCs[obj.screen]);
                //case of edit publication                    
                if (!vm.concept) {
                    vm.concept = vm.publicatieInhoundDataPs[obj.screen];
                    if (!vm.concept.channels) {
                        vm.concept.channels = [];
                        for (var i = 0; i < vm.selectedChannels.length; i++) {
                            if (vm.selectedChannels[i].selected)
                                vm.concept.channels.push(vm.selectedChannels[i].class);
                        }
                    }
                    for (var i = 0; i < vm.selectedChannels.length; i++) {
                        if (vm.concept.channels.indexOf(vm.selectedChannels[i].class) > -1)
                            vm.selectedChannels[i].selected = true;
                        else
                            vm.selectedChannels[i].selected = false;
                    }
                    vm.isConcept = false;
                } else {
                    vm.isConcept = true;
                }
                vm.concept.index = obj.screen;
            } else if (obj.view == "resultatenOverzicht") {
                //call daterangeservice to get publication date
                //initialixeChart(obj.data);
            }
                //else if (obj.view == "publiceren") {
                //    vm.concept = angular.copy(vm.publicatieInhoundDataCs[obj.screen]);
                //    vm.concept.index = obj.screen;
                //}
            else if (obj.view == "aanbodAnalyse") {
                vm.aanbodScrapeJob = angular.copy(vm.aanbodScrapejobs[obj.screen]);
            }
            vm.showBackToAantal = false;

        }, true);

        $scope.$on('hideShowPlanner', function (data, obj) {
            vm.hideShowPlanner = obj.bool;
            vm.vacature.selectedProfile = obj.profileType;
        }, true);

        $scope.$on('hideShowSideMenu', function (data, obj) {
            vm.similarJobsCount = -1;
            vm.hideShowSideMenu = obj.bool;
        }, true);

        $scope.$on('callFunction', function (data, obj) {
            isPublicationConcept(obj.str, obj.data, obj.index, obj.screen)
        }, true);

        $scope.$on('conceptPlagiarism', function (data, obj) {
            //var str = obj.str, circle = obj.data, index = obj.index;
            var target = obj.data, type = obj.type;
            if (target) {
                var city = target.jobCity;
                var numberOfDays = type == 'city' ? 12 * 7 : 1;
                var q = target.publicatieOrganisatie
                    + ' ' + target.publicatieFunctie
                    + ' ' + target.publicatieOns
                    + ' ' + target.weAsk;
                draftAppService.plagiarismCheck(city, q).then(function (data) {
                    vm.conceptPlagiarism = data;
                    var today = moment();
                    angular.forEach(vm.conceptPlagiarism, function (item) {
                        item.isOffline = today.diff(moment(item.updatedOn), 'days') > numberOfDays;
                    });
                    loaderService.toggleOverlayLoader(false);
                });
            }
        }, true);

        $scope.$on('changeActiveTab', function (data, obj) {
            vm.activeTab = obj.str;
            backPageName();
            changeActiveTab(obj.str);
        }, true);

        activate();

        ///////////////////////////

        function activate() {
            //below line ic commented out as to open specific URL
            //$location.path('/FMSvacature');
            vm.planBucket = keywordPlannerService.planBucket;
            vm.opdrachtPlanBucket = opdrachtService.planBucket;
            draftAppService.initPopover('.btn-popup');

            //Add and remove body scroll bar
            vm.toggleScrollBar = draftAppService.toggleScrollBar;
        }

        function changeActiveTab(str) {
            vm.activeTab = str;
        }

        function tabIsDisabled(opdracht, keyword) {
            vm.disableTab = opdracht || keyword;

            if (opdracht) {
                vm.disableTabMessage = "Je hebt nog niet in alle opdrachtstappen een keuze gemaakt. Je dient je opdracht compleet te maken voordat je verder kunt.";
            } else if (keyword) {
                vm.disableTabMessage = "Doorloop alle stappen van het keyword-plan. Je dient alle keyword stappen doorlopen te hebben voordat je verder kunt.";
            }
        }

        function removeThisToPlan(index, data, label, obj) {
            if (label == 'keywordPlanner' || label == 'fullPartTimeKeywords' || label == 'contractDurationKeywords') {
                data.addToPlan = false;
                var elementPos = keywordPlannerService.planBucket[label].data.map(function (x) {
                    return x.keyword;
                }).indexOf(data.keyword);
                keywordPlannerService.planBucket[label].data.splice(elementPos, 1);
                obj.push(data);
                vm.showStudentKeywordAlarm = keywordPlannerService.isAlarmedStudentKeywordsUsed(vm.planBucket['fullPartTimeKeywords'].data);
            } else if (label == 'recruitmentArea') {
                data.addToPlan = false;
                var elementPos = keywordPlannerService.planBucket[label].data.map(function (x) {
                    return x.location;
                }).indexOf(data.location);
                keywordPlannerService.planBucket[label].data.splice(elementPos, 1);
                obj.push(data);
            } else if (label == 'discoverKeywords') {
                data.addToPlan = false;
                var elementPos = keywordPlannerService.planBucket[label].data.map(function (x) {
                    return x.target;
                }).indexOf(data.target);
                keywordPlannerService.planBucket[label].data.splice(elementPos, 1);
                obj.push(data);
            }
        }

        function removeDiscoverFromPlan(index, label) {
            keywordPlannerService.planBucket[label].data.splice(index, 1);
        }

        function returnPartial(view) {
            if (typeof view === 'undefined' || view === '') {
                return;
            }
            return './draftApp/shared/partial/_' + view + '.html';
        }

        function togglePopup(isPopup, view, isWizard) {
            vm.toggleScrollBar(isPopup);
            vm.showPopup = isPopup;

            if (typeof view !== 'undefined')
                vm.keywordView = view;

            if (typeof isWizard !== undefined && isWizard !== '') {
                vm.isWizard = isWizard;
            }
            if (view == 'publiceren') {
                vm.isWizard = false;
            }
            if (view == 'plagiarism') {
                vm.isWizard = false;
            }


            if (view == 'kanalenmix') {
                loaderService.toggleOverlayLoader(true);
                instroomService.onProjectIdChange(vm.vacature.keywords.funcKeywords, vm.vacature.fmsVacature.city);
            }
        }

        function closeOverlayOnClickingShadow($event) {
            var clicked = angular.element($event.target);
            if (clicked.is('.comp-overlay-container')
                || clicked.is('.fa.fa-shopping-cart')
                || clicked.parents().is('.comp-overlay-container')
                || clicked.parents().is('.small-section-horz')
                || clicked.parents().is('.select2-selection__choice')
                || clicked.parents().is('.clock-full-half-time')
                || clicked.parents().is('#search-addon1')
                || clicked.parents().is('.widget.stretched-out ')) {
                return;
            } else {
                togglePopup(false, '', false);
                removeDefaultHighlight();
                vm.showBackToAantal = false;
            }
        }

        function removeDefaultHighlight() {
            var listOfKeywords = angular.element(document.querySelectorAll('.textKeywords'));
            angular.forEach(listOfKeywords, function (item) {
                var self = angular.element(item);
                self.removeClass('excellent');
            });
        }

        function isPublicationConcept(str, data, index, screen) {
            vm.publicatesConcept = data;
            vm.stringPublicatesConcept = str;
            vm.showAdvices = false;
            vm.showInputTag = false;
            vm.showBackToAantal = false;
            if (screen === 'testResult') {
                vm.toggleAdvices();
            } else if (screen === 'resultaten') {
                vm.kenmerken = 'resultaten';
            } else {
                vm.kenmerken = 'Inhound';
            }
            if (str === 'Publicates') {
                vm.publicatieData = vm.publicatieInhoundDataPs[index];
                //vm.publicatieDataBackup = vm.publicatieData && vm.publicatieData.publicatieScore > 0 ? angular.copy(vm.publicatieData) : {};//always empty the backup object when new publicatie is opened up
                vm.publicatieDataBackup = {};//always empty the backup object when new publicatie is opened up
                vm.showPublicatieDiscard = false;//hide the publicatie popup
                vm.stringPublicatesConcept = 'Publicatie';
                togglePopup(true, 'concept');
                //to resize the textarea
                textareaResizable();
            } else if (str === 'Concept') {
                vm.publicatieData = vm.publicatieInhoundDataCs[index];
                //vm.publicatieDataBackup = vm.publicatieData && vm.publicatieData.publicatieScore > 0 ? angular.copy(vm.publicatieData) : {};//always empty the backup object when new publicatie is opened up
                vm.publicatieDataBackup = {};//always empty the backup object when new publicatie is opened up
                togglePopup(true, 'concept');
                //to resize the textarea
                textareaResizable();
                // add object to concept
                if (!vm.publicatieData) {
                    vm.publicatieData = {};
                    var conceptsLength = vm.publicatieInhoundDataCs.length;
                    if (conceptsLength > 0)
                        vm.publicatesConcept = vm.publicatesConcept.replace('1', '') + (parseInt(vm.publicatieInhoundDataCs[conceptsLength - 1].publicatieCircle.replace('C', '')) + 1);

                    vm.publicatieData.publicatieCircle = vm.publicatesConcept;
                    vm.publicatieData.tags = angular.copy(vm.vacature.fmsVacature.tagsList);
                    vm.publicatieData.salaryPerMonth = angular.copy(vm.vacature.vacatureExtras.job_month_salary_original);
                    vm.publicatieData.hoursPerWeek = angular.copy(vm.vacature.vacatureExtras.job_hours_per_week_original);
                    vm.publicatieData.jobCity = vm.vacature.fmsVacature.city;
                    vm.publicatieData.closeType = 'FmsClosed';
                    vm.publicatieInhoundDataCs.push(vm.publicatieData);
                }
            }

            draftAppService.initTagsInput();
        }

        function publishConcept() {
            if (!vm.concept) return;
            //Make sure that all selected channels are added to the concept before publishing it.       
            for (var i = 0; i < vm.selectedChannels.length; i++) {
                addChannelToConcept(vm.selectedChannels[i]);
            }
            vm.publication = angular.copy(vm.publicatieInhoundDataCs[vm.concept.index]);
            vm.publication.vandaag = vm.concept.vandaag + " " + vm.concept.startTime;
            vm.publication.afsluiting = vm.concept.afsluiting + " " + vm.concept.endTime;
            vm.publication.closeType = vm.concept.closeType;
            vm.publication.initialForecasts = vm.concept.currentForecasts;
            vm.publication.publicatieCircle = vm.concept.publicatieCircle.replace("C", "P");
            vm.publication.channels = vm.concept.channels;
            var pubCount = vm.publicatieInhoundDataPs.length;
            vm.publication.publicatieCircle = vm.publication.publicatieCircle.replace(/\d+/, '') + (pubCount + 1);
            vm.publicatieInhoundDataCs.splice(vm.concept.index, 1);
            vm.publicatieInhoundDataPs.push(vm.publication);

            togglePopup(false, '', false);
        }

        //function loadChart() {
        //if (vm.keyword && vm.keyword.ontdekName) {
        //    $timeout(function () {
        //        ontdekService.update(vm.keyword.ontdekName);
        //    });
        //}
        //else {
        //    $timeout(function () {
        //        ontdekService.init('networkKeywords');
        //    });
        //}
        //}

        function fetchDiscoveredKeywords() {
            if (vm.keyword && vm.keyword.ontdekName) {
                $timeout(function () {
                    ontdekService.fetchDiscoveredKeywords(vm.keyword.ontdekName).then(resolveDiscoveredKeyword);
                });
            } else {
                vm.discoverKeywords = [];
            }
        }

        function resolveDiscoveredKeyword(data) {
            if (data) {
                angular.element(document.getElementById('suggesties')).css('display', 'none');
            } else {
                angular.element(document.getElementById('suggesties')).css('display', 'block');
            }
            angular.forEach(data, function (item) {
                angular.forEach(vm.vacature.keywords.discoverKeywords, function (selectedItem) {
                    if (selectedItem === item.target) {
                        item.addToPlan = true;
                    }
                });
            });
            vm.discoverKeywords = data;
        }

        function changeInDiscoveryKeuwords() {
            angular.element(document.getElementById('suggesties')).css('display', 'none');
        }

        //function initializeTheSelectedKeywords(functionKeysFrmFMS, obj) {
        //    if (!functionKeysFrmFMS || !obj)
        //        return false;

        //    var dummyKeyFromFMS = [];

        //    angular.forEach(obj, function (value, key) {
        //        angular.forEach(functionKeysFrmFMS, function (v, k) {
        //            if (value.key.toLowerCase() == v.key.toLowerCase())
        //                dummyKeyFromFMS.push(value);
        //        });
        //    });

        //    vm.selectedKeywords = dummyKeyFromFMS;
        //    vm.fetchFunctionKeywords(vm.selectedKeywords);
        //}

        function loadForecastChart(fmsId, circle) {
            $timeout(function () {
                forecastService.drawBenchmarkD3(fmsId, circle);
            });
        }

        function toggleAdvices() {
            vm.kenmerken = 'Adviezen';
        }

        function toggleBodyClass() {
            //draftAppService.togglebodyClass('body', 'noScroll');
        }

        function setCurrentWizard(str) {
            if (typeof str === undefined || typeof str === '')
                return;

            vm.isCurrentWizard = str;
        }

        function wizardButtonShow(str) {
            vm.iskeywordSection = false;
            vm.isInstroomSection = false;
            vm.isForecast = false;
            vm.isOpdracht = false;
            if (str === 'keyword' || str == 'locaties' || str == 'fullPartTime' || str == 'contractduur' || str == 'ontdek') {
                vm.iskeywordSection = true;
            } else if (str == 'forecast') {
                vm.isForecast = true;
            } else if (str == 'opdracht') {
                vm.isOpdracht = true;
            } else {
                vm.isInstroomSection = true;
            }
        }

        function backPageName() {
            vm.backPageName = $state.get(vm.activeTab).data.name;
        }

        function isPublicatesView(isShow) {
            vm.showBreadkcrumb = isShow;
        }

        //resultanet page contoller will resolve later into publicere page when overlay is removed from index level page
        //to page/template level
        function initialixeChart(publicatie) {
            // get start and endDate from 
            //url = "https://www.olympia.nl/V-1811579/Magazijnmedewerkers-regio-Nijmegen";

            var vandaag = moment(publicatie.vandaag, 'DD/MM/YYYY hh:mm').format('MM/DD/YYYY');
            var afsluiting = moment(publicatie.afsluiting, 'DD/MM/YYYY hh:mm').format('MM/DD/YYYY');
            var startDate = publicerenService.dateParser(vandaag, "DDMMYYYY"),
			endDate = publicerenService.dateParser(afsluiting, "DDMMYYYY");
            // update publicationDateRange
            vm.publicationDateRange = {
                jobStartDate: moment(startDate, "DDMMYYYY"),
                jobEndDate: moment(endDate, "DDMMYYYY")
            };

            url = publicatie.publicationUrl;
            if (url && (startDate !== false || endDate !== false)) {
                loadOverzicht(url, true, startDate, endDate);
            }
        }

        function successGetPublication(data) {
            angular.copy(data, publicationDateRange);
            initialixeChart(data);
        }

        function errorGetPublication(data) {
            //Catch error here
            console.log(data);
        }

        function dateRangeWatcher(newVal, oldVal) {
            if (newVal) {
                var startDate = draftAppService.dateParser(newVal.start, "DDMMYYYY"),
					endDate = draftAppService.dateParser(newVal.end, "DDMMYYYY");

                if (startDate !== false || endDate !== false) {
                    loadOverzicht(url, true, startDate, endDate);
                }
            }
        }

        function loadOverzicht(url, isDate, startDate, endDate) {
            publicerenService.getUrlActueelVerkeerData(url, isDate, startDate, endDate).then(returnAnalyzedData);
            if (vm.displayMode.mode == 'map') {
                vm.getJobViews();
            }
        }

        function returnAnalyzedData(data) {
            if (data === "Keyset does not exist") {
                //loaderService.toggle(false);
            }
            if (data.tableData) {
                data.tableData.sort(function (a, b) {
                    return parseFloat(a.jobViews) > parseFloat(b.jobViews) ? -1 : 1;
                });

                // map chart data to be array instead of object
                var chartData = _.map(data.chartData, function (val) {
                    return [val.date, val.jobViews, val.jobApplications];
                });
                data.chartData.arrData = chartData;

                if (data.tableData.length > 0) {
                    vm.rawData = data;
                    vm.tableData = data.tableData.splice(1, data.tableData.length);
                    vm.tableDataTotal = data.tableData[0];
                }
                $timeout(function () {
                    lineChartService.createChartAndTable(data, vm.chartPeriod);
                });
            } else {
                data = {};
                vm.rawData = data;
                vm.tableData = null;
                vm.tableDataTotal = null;
            }
        }

        // change between map and chart
        function changeDisplayMode(mode) {
            if (mode == 'map') {
                vm.displayMode.mode = 'map';
                vm.displayMode.title = 'Show Chart';
                vm.getJobViews();
            }
            else {
                vm.displayMode.mode = 'chart';
                vm.displayMode.title = 'Show Map';
            }
        }

        function getJobViews() {
            var startDate = publicerenService.dateParser(vm.dateRange.start, "DDMMYYYY"),
					endDate = publicerenService.dateParser(vm.dateRange.end, "DDMMYYYY");
            publicerenService.getJobViews(url, startDate, endDate).then(resolveJobViewsData, errorReferralReport);
        }

        function resolveJobViewsData(data) {
            vm.jobViews = data;
            publicerenService.resolveMapData(data);
        }

        function errorReferralReport(error) {
            console.log(error);
        }

        function changeChartPeriod(period) {
            vm.chartPeriod = period;
            if (Object.keys(vm.rawData).length !== 0) {
                lineChartService.createChartAndTable(vm.rawData, vm.chartPeriod);
            }
        }

        function convertSecondsToDate(seconds) {
            return new Date(1970, 0, 1).setSeconds(Math.round(seconds));
        }

        function isValidPlaceholders(userPlaceholders, allowedPlaceholdersList) {
            for (var j = 0; j < userPlaceholders.length; j++) {
                if (allowedPlaceholdersList.indexOf(userPlaceholders[j]) == -1) {
                    return false;
                }
            }
            return true;
        }

        function changeTemplateContents(selectionChanged) {
            var selectedType = vm.selectedTemplate.type;
            // validate thank you content and confirmation content and allow only possible placeholders
            var tempConfirmationContent = vm.selectedTemplate.pageBody;
            var tempThankYouContent = vm.selectedTemplate.emailBody;
            var userThankYouPlaceholders = [];
            var userConfirmationPlaceholders = [];
            // insert into array all placeholders that user entered between {}
            tempConfirmationContent.replace(/\{(.*?)\}/g, function (g0, g1) { userConfirmationPlaceholders.push(g1); });
            tempThankYouContent.replace(/\{(.*?)\}/g, function (g0, g1) { userThankYouPlaceholders.push(g1); });

            vm.templateValid.isValidConfirmationContent = isValidPlaceholders(userConfirmationPlaceholders, vm.allowedConfirmationPlaceholders);
            vm.templateValid.isValidThankYouContent = isValidPlaceholders(userThankYouPlaceholders, vm.allowedThankYouPlaceholders);

            if (!selectionChanged) {
                // selectionChanged = false means the user not changed the selection but change in content itself
                // change type to custom if not equal original setting
                if (!angular.equals(vm.selectedTemplate, vm.instroomBedankpagina[vm.selectedTemplate.type]) && vm.isValidConfirmationContent && vm.isValidThankYouContent) {
                    vm.selectedTemplate.type = "custom";
                }
            }
            else {
                vm.selectedTemplate = angular.copy(vm.instroomBedankpagina[vm.selectedTemplate.type]);
            }

            // copy backup again
            vm.templateBackup = angular.copy(vm.selectedTemplate);
            vm.vacature.instroom.templateContents.type = vm.selectedTemplate.type;

            if (vm.templateValid.isValidConfirmationContent) {
                vm.vacature.instroom.templateContents.confirmationTitle = vm.selectedTemplate.pageTitle;
                vm.vacature.instroom.templateContents.confirmationContent = vm.selectedTemplate.pageBody;
            }
            if (vm.templateValid.isValidThankYouContent) {
                vm.vacature.instroom.templateContents.emailTitle = vm.selectedTemplate.emailTitle;
                vm.vacature.instroom.templateContents.emailContent = vm.selectedTemplate.emailBody;
            }
        }

        // Load Intercom
        setTimeout(function () {
            $.get('/VacatureLocal/Intercom?v=' + Date.now(), function (data) {
                $(data).appendTo(document.body);
            });
        }, 1000);
        // Update Intercom
        $rootScope.$on('$stateChangeSuccess', function () {
            if ($window.Intercom) {
                $window.intercomCalls = $window.intercomCalls || 0;
                if ($window.intercomCalls > 8) { // must refresh the whole page
                    //console.log('Intercom refresh call - x' + $window.intercomCalls);
                    return $window.location.reload(true);
                }
                $window.intercomCalls++;
                var tempDate = Date.now();
                var email = 'test@olympiagroep.nl';
                if (vm.userSession) {
                    //console.log(vm.userSession);
                    email = vm.userSession.UserName;
                }
                //console.log('Intercom update call - x' + $window.intercomCalls);
                //console.log(tempDate);
                //console.log(email);
                $window.Intercom('update', { email: email, tempDate: tempDate });
            }
        });

        function copyFMSVacatureHere(obj, concept) {
            vm.spinTheRefreshIcon = true;

            obj.publicatieTitle = angular.copy(vm.vacature.fmsVacature.jobTitle);
            obj.publicatieOrganisatie = angular.copy(vm.vacature.vacatureExtras.job_bedrijfsprofiel);
            obj.publicatieFunctie = angular.copy(vm.vacature.vacatureExtras.job_profile);
            obj.publicatieOns = angular.copy(vm.vacature.vacatureExtras.job_aanbod);
            obj.weAsk = angular.copy(vm.vacature.vacatureExtras.job_disp_additional_crit);

            draftAppService.saveVacature(vm.vacature);
            vm.vacatureBackup = angular.copy(vm.vacature);
            draftAppService.getAdvice(vm.vacature, concept).then(resolveAdviceData);

            //call directive to trigger keyup for highlighting words
            $timeout(function () {
                $('#pc-title').trigger('keyup');
            });
        }

        $scope.$on('userUpdated', function (event) {
            draftAppService.getUserSession().then(function (data) {
                data.Avatar += "?v=" + Date.now();
                vm.userSession = data;
                loaderService.toggle(false);
            });
        });

        function fetchLocations(fmsCity) {
            if (fmsCity == '') return;
            keywordPlannerService.fetchLocations(fmsCity).then(resolveLocations);
        }

        function resolveLocations(data) {
            // keywordPlannerService.planBucket['recruitmentArea'].data = vm.vacature.keywords.locKeywords;
            angular.forEach(data, function (item) {
                angular.forEach(vm.vacature.keywords.locKeywords, function (selectedItem) {
                    if (selectedItem.location === item.location) {
                        item.addToPlan = true;
                    }
                });
            });
            vm.dummyRecruitmentTable = data;
        }

        function fetchFunctionKeywords(searchKeys) {
            //if (searchKeys.length == 0) return;
            keywordPlannerService.fetchFunctionKeywords(searchKeys).then(resolveSearchKeys);
        }

        function resolveSearchKeys(data) {
            //keywordPlannerService.planBucket['keywordPlanner'].data = vm.vacature.keywords.funcKeywords;
            angular.forEach(data, function (item) {
                angular.forEach(vm.vacature.keywords.funcKeywords, function (selectedItem) {
                    if (selectedItem && selectedItem.keyword === item.keyword) {
                        item.addToPlan = true;
                    }
                });
            });
            vm.dummytable = data;
        }

        function manuallyupdateScore(obj, concept) {
            vm.spinTheRefreshIcon = true;
            vm.publicatieData.updateDate = moment.tz(new Date(), "Europe/Amsterdam").format('DD-MM-YYYY [om] HH:mm');
            draftAppService.saveVacature(vm.vacature);
            vm.vacatureBackup = angular.copy(vm.vacature);
            draftAppService.getAdvice(vm.vacature, concept).then(resolveAdviceData);
        }

        function changeTimeOfPublication(obj, time, type) {
            if (type == "start") {
                if (time == "direct") {
                    $timeout(function () {
                        vm.concept.vandaag = moment(new Date()).format("DD/MM/YYYY");
                        vm.concept.startTime = moment(new Date()).format("hh:mm");
                    });
                } else {
                    if (time === 'setOwnTime') {
                        vm.concept.vandaag = moment(new Date()).format("DD/MM/YYYY");
                    }
                    vm.concept.startTime = "18:00";
                }
            } else if (type == "end") {
                if (time == "FmsClosed") {
                    $timeout(function () {
                        vm.concept.afsluiting = moment().add(20, 'year').format("DD/MM/YYYY");
                        vm.concept.endTime = moment().add(20, 'year').format("hh:mm");
                        vm.concept.closeType = "FmsClosed";
                    });
                } else {
                    if (time === 'SetOnTime') {
                        vm.concept.afsluiting = moment(new Date()).add(15, 'days').format("DD/MM/YYYY");
                    }
                    vm.concept.endTime = "11:00";
                    vm.concept.closeType = "SetOnTime";
                }
            }
        }
        // for forcast button at opdracht tab (prevent user to add values more than maximum allowed)
        function isExceededMaxValue(inputType, currentValue, maxValue) {
            if (inputType == 'hours' && (typeof (currentValue) == "undefined" || currentValue > maxValue)) {
                vm.vacature.opdracht.urenEnMarge.hours = maxValue;
            }
            else if (inputType == 'weeks' && (typeof (currentValue) == "undefined" || currentValue > maxValue)) {
                vm.vacature.opdracht.urenEnMarge.weeken = maxValue;
            }
            else if (inputType == 'salary' && (typeof (currentValue) == "undefined" || parseFloat(currentValue.replace(",", ".")) > maxValue)) {
                vm.vacature.opdracht.urenEnMarge.salary = maxValue;
                vm.salary = maxValue + ',00';
            }
        }

        function hoverIn(current) {
            current.hoverEdit = true;
        }

        function hoverOut(current) {
            current.hoverEdit = false;
        }

        function changeSalaryToDutch(salary) {
            var number = parseFloat(salary.replace(",", "."));
            vm.vacature.opdracht.urenEnMarge.salary = number;
        }

        function changeSalToDutch(salary) {
            var number = (parseFloat(Math.round(salary * 100) / 100).toFixed(2) + "").replace(".", ",");
            vm.salary = number;
        }

        function checkForAllFilledOn(view, screen) {
            if (view == 'vacatureprioreit') {
                $timeout(function () {
                    vm.togglePopup(false, '', false);
                    vm.tabIsDisabled(vm.disableTabGreaterThanOpdracht, false);
                    if (vm.vacature.opdracht.bestaandKlant != '' && vm.vacature.opdracht.aantalconcurrenetn != '' && vm.vacature.opdracht.priority != '' && vm.vacature.opdracht.urenEnMarge.total != 0) {
                        $state.go('mijnPublicaties.keywords');
                    }
                }, 1000);
            }
        }

        function openLastClosedConcept() {
            isPublicationConcept(window.sessionStorage.getItem('cpstr'), window.sessionStorage.getItem('concept'), window.sessionStorage.getItem('cpindex'));
            vm.showBackToConcept = false;
        }

        function saveConceptValue(concept, string, obj) {

            if (string == 'Publicates' && vm.publicatieInhoundDataPs.length !== 0) {
                var elementPos = vm.publicatieInhoundDataPs.map(function (x) {
                    return x.publicatieCircle;
                }).indexOf(obj.publicatieCircle);
            } else if (string == 'Concept' && vm.publicatieInhoundDataCs.length !== 0) {
                var elementPos = vm.publicatieInhoundDataCs.map(function (x) {
                    return x.publicatieCircle;
                }).indexOf(obj.publicatieCircle);
            } else {
                return false;
            }

            window.sessionStorage.setItem('concept', concept);
            window.sessionStorage.setItem('cpstr', string);
            window.sessionStorage.setItem('cpindex', elementPos);

            vm.showBackToConcept = true;
        }

        function addChannelToSelected(data) {
            if (!vm.selectedChannels)
                vm.selectedChannels = [];
            var index = -1;
            for (var i = 0; i < vm.selectedChannels.length; i++) {
                if (vm.selectedChannels[i].class === data.class) {
                    index = i;
                    break;
                }
            }
            if (index === -1) {
                vm.selectedChannels.push(data);
            }
        }
        function removeChannelFromSelected(data) {
            if (vm.selectedChannels) {
                var index = -1;
                for (var i = 0; i < vm.selectedChannels.length; i++) {
                    if (vm.selectedChannels[i].class === data.class) {
                        index = i;
                        break;
                    }
                }
                if (index > -1) {
                    vm.selectedChannels.splice(index, 1);
                }
            }
        }
        //this is for kanalenmix(instroom)
        function addThisToChannels(data) {
            if (data.selected) {
                vm.vacature.instroom.channels.push(data.class);
                addChannelToSelected(data);
            } else {
                var index = vm.vacature.instroom.channels.indexOf(data.class);
                vm.vacature.instroom.channels.splice(index, 1);
                removeChannelFromSelected(data);
                if (data.preSelected && vm.vacature.instroom.unselectedChannels.indexOf(data.class) === -1) {
                    vm.vacature.instroom.unselectedChannels.push(data.class);
                }
            }
        }
        //This adds the channel to the concept      
        function addChannelToConcept(data) {
            if (!vm.concept.channels)
                vm.concept.channels = [];

            if (data.selected && vm.concept.channels.indexOf(data.class) === -1) {
                vm.concept.channels.push(data.class);
            }
            else {
                var index = vm.concept.channels.indexOf(data.class);
                if (index > -1)
                    vm.concept.channels.splice(index, 1);
            }
        }

        function calculateTotalForUrenEnMarge() {
            if (vm.vacature.opdracht) {
                if (vm.vacature.opdracht.urenEnMarge.hours == 0 || vm.vacature.opdracht.urenEnMarge.weeken == 0 || vm.vacature.opdracht.urenEnMarge.salary == 0) {
                    if (vm.vacature.opdracht.urenEnMarge.recruitmentFees != 0) {
                        vm.vacature.opdracht.urenEnMarge.total = vm.vacature.opdracht.urenEnMarge.recruitmentFees;
                    } else {
                        vm.vacature.opdracht.urenEnMarge.total = 0;
                    }
                } else {
                    vm.vacature.opdracht.urenEnMarge.total = vm.vacature.opdracht.urenEnMarge.hours * vm.vacature.opdracht.urenEnMarge.weeken * vm.vacature.opdracht.urenEnMarge.salary + vm.vacature.opdracht.urenEnMarge.recruitmentFees;
                }
            }
        }

        function textareaResizable() {
            $timeout(function () {
                if ($("textarea").hasClass('textarea-resizable')) {
                    $("textarea").resizable({
                        handles: "se"
                    });
                    $("textarea").resizable("destroy");
                    $("textarea").css('width', '100%');
                    var widthOfparent = $('.resizable-textarea').width();
                    $("textarea").resizable({
                        handles: "se",
                        maxWidth: widthOfparent + 30,
                        minWidth: widthOfparent + 30,
                        resize: function (event, ui) {
                            ui.originalElement.closest('div').find('.ui-icon-gripsmall-diagonal-se').css('right', -(widthOfparent - 16) + 'px');
                        }
                    });
                    $("textarea").css('width', '100%');
                    $('textarea').closest('.ui-wrapper').css('max-width', (widthOfparent + 30) + 'px');
                }
            }, 100)
        }

        function resultatenOverzicht(obj) {
            //url = "https://www.olympia.nl/V-1811579/Magazijnmedewerkers-regio-Nijmegen";
            //call daterangeservice to get publication date
            initialixeChart(obj);
        }

        function setLanguage(lang) {
            draftAppService.getResources(lang).then(function (data) {
                $scope.appResources = data;
            });
        }

        function initializeResources() {
            vm.setLanguage('nl');
        }

        function openPopup(view, screen) {
            $rootScope.$broadcast('openPopup', { 'view': view, 'screen': screen });
        }

        function openPopupSection(view, screen) {
            $rootScope.$broadcast('openPopupSection', { 'view': view, 'screen': screen });
        }

        function openPlagiarismOverlay(view, screen, lastOpenScreen, index) {
            $rootScope.$broadcast('openPopupSection', { 'view': view, 'screen': screen });
            window.sessionStorage.setItem('lastOpenScreen', lastOpenScreen);
            window.sessionStorage.setItem('lastOpenView', screen);
            vm.aantalPlagSelected = angular.copy(vm.plagiarism[index]);
            $('#overlay').animate({ scrollTop: 0 }, 600);
            vm.showBackToAantal = true;
        }

        function loadPlagDataForCNP(data, type) {
            loaderService.toggleOverlayLoader(true);
            $rootScope.$broadcast('conceptPlagiarism', { data: data, type: type });
        }

        function openLastAddedView() {
            var screen = window.sessionStorage.getItem('lastOpenScreen');
            if (screen == "false") {
                screen = vm.backPageName;
            }
            openPopupSection(screen, window.sessionStorage.getItem('lastOpenView'));
        }

        function addNewDomain() {
            var isValide = validateDomain();
            if (!isValide) {
                domainResponse(false);
                return false;
            }
            loaderService.toggleOverlayLoader(true);
            draftAppService.addNewDomain(vm.newDomain).then(function (data) {
                vm.domainMessage = 'domein succesvol toegevoegd';
                    vm.domains.push(vm.newDomain);
                    domainResponse(true);
                },
            function (error) {
                vm.domainMessage = 'fout domein niet toegevoegd';
                domainResponse(false);
                console.log(error);
            });
        }

        function validateDomain() {
            var isValide = true;
            if (vm.newDomain.length === 0) {
                vm.domainMessage = 'voer het juiste domein in';
                isValide = false;
            }
            else if (vm.domains.length > 0 && vm.domains.indexOf(vm.newDomain.trim()) > -1) {
                vm.domainMessage = 'domein bestaat al';
                isValide = false;
            }
            return isValide;
        }

        function loadDomains() {
            if (vm.settings.isHtmlBuilderEnabled && vm.domains.length == 0) {
                draftAppService.getDomains().then(function(data) {
                    vm.domains = data;
                    },
                    function(error) {
                        console.error(error);
                    }
                );
            }
        }

        function domainResponse(isCreated) {
            vm.showDomainMessage = true;
            vm.isDomainCreated = isCreated;
            loaderService.toggleOverlayLoader(false);
            setTimeout(function () {
                vm.showDomainMessage = false;
            }, 10000);
        }
    }

})();