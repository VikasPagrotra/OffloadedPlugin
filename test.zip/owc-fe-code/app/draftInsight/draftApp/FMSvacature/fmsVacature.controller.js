(function () {
    'use strict'
    angular.module('fmsVacature.module')
		.controller('fmsVacatureCntl', fmsVacatureCntl);

    fmsVacatureCntl.$inject = ['$rootScope', '$scope', '$state', 'draftAppService'];

    function fmsVacatureCntl($rootScope, $scope, $state, draftAppService) {

        var vm = this;

        var fmsId = $state.params.fmsId;
        if (fmsId) {
            draftAppService.getVacature(fmsId, true, "Overview");
        }
        $scope.$on('vacatureFetched', function (event, vacature) {
            vm.vacature = vacature;
        }, true);

        activate();

        function activate() {
            draftAppService.initPopover('.btn-popup');
            //this is for change tabs as this controller load
            $rootScope.$broadcast('changeActiveTab', { str: 'mijnPublicaties.vacature' });
        }
    }
})();
