(function(){
	'use strict'
	angular.module('fmsVacature.module', []);
})();
