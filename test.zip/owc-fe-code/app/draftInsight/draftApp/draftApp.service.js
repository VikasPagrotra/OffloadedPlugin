(function () {
    'use strict';

    angular.module('olympia-draftApp')
		.service('draftAppService', draftAppService);

    draftAppService.$inject = ['$timeout', '$rootScope', '$http', '$q', '$sce', 'enumApp', 'loaderService', '$interval', '$window'];

    function draftAppService($timeout, $rootScope, $http, $q, $sce, enumApp, loaderService, $interval, $window) {
        var service,
            inputTagValue = ['Wijchen', 'Fulltime', 'Heerenveen', 'Transport / Logistiek / Luchtvaart', 'Wijchen', '€ 3500', 'Fulltime'],
            keywordPlannerWizardData = ['functies', 'locaties', 'fullPartTime', 'ontdek'],
            instroomWizardData = ['additionele', 'vragen', 'bevestingsmail'],
            wizard = { 'currentWizard': '' },
            vacatureData = {};

        service = {
            getUserSession: getUserSession,
            togglebodyClass: togglebodyClass,
            toggleAdvicesSection: toggleAdvicesSection,
            initPopover: initPopover,
            initTagsInput: initTagsInput,
            toggleScrollBar: toggleScrollBar,
            inputTagValue: inputTagValue,
            keywordPlannerWizardData: keywordPlannerWizardData,
            instroomWizardData: instroomWizardData,
            wizard: wizard,
            getVacature: getVacature,
            refreshMl: refreshMl,
            getCanceller: $q.defer(),
            saveVacature: saveVacature,
            saveCanceller: $q.defer(),
            getAdvice: getAdvice,
            adviceCanceller: $q.defer(),
            vacatureData: vacatureData,
            getVacatureChannels: getVacatureChannels,
            dateParser: dateParser,
            getTagsSets: getTagsSets,
            vacatureChannels: [],
            isSaving: false,
            prevFmsId: '',
            getSettings: getSettings,
            userSession: null,
            plagiarismCheck: plagiarismCheck,
            getSimilarJobs: getSimilarJobs,
            randomMessage: [],
            getResources: getResources,
            ssoEnabled: ssoEnabled,
            signOut:signOut,
            addNewDomain:addNewDomain,
            getDomains: getDomains
    };

        return service;

        ////////////////////////

        function getUserSession() {
            loaderService.toggle(true);
            var deferred = $q.defer();
            $http({
                    url: enumApp.url.draftUrl + 'userSession',
                    method: "GET"
                })
                .success(function(data) {
                    deferred.resolve(data);
                    service.userSession = data;
                })
                .error(function() {
                    deferred.reject("Failed to user session");
                });
            return deferred.promise;
        }

        function togglebodyClass(ele, className) {
            $timeout(function () {
                angular.element(ele).toggleClass(className);
            });
        }

        function toggleAdvicesSection() {
            $timeout(function () {
                $('.toggleLink').on("click", function () {
                    $(this).prev().toggle("");
                    $(this).parent().toggleClass("widget-column-bg");
                    $(this).toggleClass("up-arrow");
                });
            });
        }

        function initPopover(ele) {
            $timeout(function () {
                $(ele).popover({ trigger: "manual", html: true, animation: false })
                .on("mouseenter", function () {
                    var _this = this;
                    $(this).popover("show");
                    $(".popover").on("mouseleave", function () {
                        $(_this).popover('hide');
                    });
                }).on("mouseleave", function () {
                    var _this = this;
                    setTimeout(function () {
                        if (!$(".popover:hover").length) {
                            $(_this).popover("hide");
                        }
                    }, 300);
                });
            }, 1500)
        }

        function initTagsInput() {
            $timeout(function () {
                $("input.tagsInput").tagsinput({
                    typeahead: {
                        source: ['Wijchen', 'Administratief', 'Fulltime', 'Transport / Logistiek / Luchtvaart', 'Heerenveen', '€ 3500', 'Wijchen', 'Fulltime']
                    }
                });

                $('input.tagsInput').on('itemAdded', function (event) {
                    $rootScope.$broadcast('itemAdded');
                });
            }, 10);
        }

        function toggleScrollBar(isToggle) {
            var element = angular.element('body');
            if (typeof isToggle === undefined || isToggle === false) {
                element.removeClass('noScroll');
            } else if (isToggle === true) {
                element.addClass('noScroll');
            }
        }


        function getVacature(fmsId, showLoader,activeTab) {
            // cancel any prev get
            service.getCanceller.resolve();
            service.getCanceller = $q.defer();

            showLoader = typeof showLoader !== 'undefined' ? showLoader : true;
            if (showLoader == true) {
                loaderService.toggle(true);
            }
            var deferred = $q.defer();

            var stopInterval = $interval(function () {
                if (!service.isSaving) {
                    $interval.cancel(stopInterval);

                    $http({
                        url: enumApp.url.draftUrl + 'vacature/' + fmsId + '?activeTab=' + (activeTab ? activeTab : "None"),
                        method: "GET",
                        timeout: service.getCanceller.promise
                    })
                   .success(function (data) {
                       data.orgDescHtml = $sce.trustAsHtml(data.orgDesc);
                       data.funcDescHtml = $sce.trustAsHtml(data.funcDesc);

                       $rootScope.$broadcast('vacatureFetched', data);
                       loaderService.toggle(false);
                       service.vacatureData = data;
                       deferred.resolve(data);
                   })
                   .error(function (data, status) {
                       loaderService.toggle(false);
                       deferred.reject("Failed to get vacature data");
                       // unauthorized, may be an SSO error
                       if (status == 403) {
                           var url = $window.location.href;
                           var refresh = true;
                           if (url.endsWith('?refresh=1')) {
                               url = url.replace('?refresh=1', '?refresh=2');
                           }
                           else if (url.endsWith('?refresh=2')) {
                               url = url.replace('?refresh=2', '?refresh=3');
                           }
                           else if (url.endsWith('?refresh=3')) {
                               url = url.replace('?refresh=3', '?refresh=4');
                           }
                           else if (url.endsWith('?refresh=4')) {
                               url = url.replace('?refresh=4', '?refresh=5');
                           }
                           else if (url.endsWith('?refresh=5')) {
                               refresh = false;
                           } else {
                               url += '?refresh=1';
                           }
                           if (refresh) {
                               $window.location.href = url;
                               $window.location.reload(true);
                           }
                       }
                   });
                }
            }, 100);

            return deferred.promise;
        }

        function saveVacature(job,activeTab) {

            if(activeTab){
                if(activeTab === "mijnPublicaties.vacature"){
                    activeTab = "Overview";
                }
                else if(activeTab === "mijnPublicaties.opdracht"){
                    activeTab = "Opdracht";
                }
                else if(activeTab === "mijnPublicaties.keywords"){
                    activeTab = "Keywords";
                }
                else if(activeTab === "mijnPublicaties.forecast"){
                    activeTab = "Forecast";
                }
                else if(activeTab === "mijnPublicaties.instroom"){
                    activeTab = "Instroom";
                }
                else if(activeTab === "mijnPublicaties.publicatieInhoud"){
                    activeTab = "PublicatieInhoud";
                }
                else if(activeTab === "mijnPublicaties.publiceren"){
                    activeTab = "Publiceren";
                }
            }
            else{
                activeTab = "None";
            }

            initPopover('.btn-popup');
            // don't continue if user can't edit
            if (job.canEdit == false && service.userSession != null) {
                return service.saveCanceller.resolve();
            }
            
            // cancel any prev save
            service.saveCanceller.resolve();
            service.saveCanceller = $q.defer();

            // indicate that vacature is saving now
            service.isSaving = true;
            var deferred = $q.defer();
            $http({
                url: enumApp.url.draftUrl + 'vacature/' + job.fmsId + '?activeTab=' + activeTab,
                method: "POST",
                data: job,
                timeout: service.saveCanceller.promise
            })
            .success(function (data) {
                // saving done
                service.isSaving = false;
                service.vacatureData = job;
                deferred.resolve(data);
            })
            .error(function (data, status) {
                // saving done
                service.isSaving = false;
                deferred.reject("Failed to save vacature data");
                // unauthorized, may be an SSO error
                if (status == 403) {
                    var url = $window.location.href;
                    var refresh = true;
                    if (url.endsWith('?refresh=1')) {
                        url = url.replace('?refresh=1', '?refresh=2');
                    }
                    else if (url.endsWith('?refresh=2')) {
                        url = url.replace('?refresh=2', '?refresh=3');
                    }
                    else if (url.endsWith('?refresh=3')) {
                        url = url.replace('?refresh=3', '?refresh=4');
                    }
                    else if (url.endsWith('?refresh=4')) {
                        url = url.replace('?refresh=4', '?refresh=5');
                    }
                    else if (url.endsWith('?refresh=5')) {
                        refresh = false;
                    } else {
                        url += '?refresh=1';
                    }
                    if (refresh) {
                        $window.location.href = url;
                        $window.location.reload(true);
                    }
                }
            });

            return deferred.promise;
        }

        function getAdvice(job, concept) {
            // cancel any prev advice
            service.adviceCanceller.resolve();
            service.adviceCanceller = $q.defer();

            var deferred = $q.defer();

            $http({
                url: enumApp.url.draftUrl + 'vacature/advice/' + concept,
                method: "POST",
                data: job,
                timeout: service.adviceCanceller.promise
            })
			.success(function (data) {
			    initPopover('.btn-popup');
			    deferred.resolve(data);
			})
			.error(function () {
			    deferred.reject("Failed to get publication");
			});

            return deferred.promise;
        }

        function getVacatureChannels(branchId) {
            var deferred = $q.defer();
            branchId = branchId != "" ? branchId : "132";
            $http({
                url: enumApp.url.draftUrl + 'channels/' + branchId,
                method: "GET"
            })
			.success(function (data) {
			    deferred.resolve(data);
			})
			.error(function () {
			    deferred.reject("Failed to get user channels");
			});

            return deferred.promise;
        }

        function getTagsSets() {
            var deferred = $q.defer();
            $http({
                url: enumApp.url.draftUrl + 'categories/tags',
                method: "GET"
            })
			.success(function (data) {
			    deferred.resolve(data);
			})
			.error(function () {
			    deferred.reject("Failed to get tags sets");
			});

            return deferred.promise;
        }

        function dateParser(dateTimeToParse, format) {
            if (typeof dateTimeToParse === 'undefined')
                return false;

            var parsed = moment(dateTimeToParse).format("DDMMYYYY");
            return parsed;
        }

        function getSettings() {
            var deferred = $q.defer();
            $http({
                url: enumApp.url.draftUrl + 'Settings',
                method: "GET"
            })
			.success(function (data) {
			    deferred.resolve(data);
			})
			.error(function () {
			    deferred.reject("Failed Settings");
			});

            return deferred.promise;
        }

        function refreshMl(fmsId) {
            var deferred = $q.defer();
            $http({
                url: enumApp.url.draftUrl + 'ML/Refresh/' + fmsId,
                method: "Post"
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function () {
                    deferred.reject("Failed to refresh Ml data");
                });
            return deferred.promise;
        }

        function plagiarismCheck(city, q) {
            var deferred = $q.defer();

            $http({
                    url: enumApp.url.draftUrl + 'similarJobs',
                    method: "POST",
                    data: { city: city, q: q }
                })
                .success(function(data) {
                    deferred.resolve(data);
                })
                .error(function(data, status) {
                    deferred.reject("Failed to check plagiarism");
                });
            return deferred.promise;
        }

        function getSimilarJobs(fmsId) {
            loaderService.toggleOverlayLoader(true);
            var deferred = $q.defer();
                $http({
                    url: enumApp.url.draftUrl + 'vacature/SimilarJobs/' + fmsId,
                    method: "GET"
                })
                .success(function (data) {
                    deferred.resolve(data);
                    loaderService.toggleOverlayLoader(false);
                })
                .error(function () {
                    deferred.reject("Failed to get similar jobs");
                    loaderService.toggleOverlayLoader(false);
                });
            return deferred.promise;
        }

        function getResources(lang) {
            var deferred = $q.defer();
            $http({
                url: enumApp.url.draftUrl + 'resources/' + lang,
                method: "GET"
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function () {
                deferred.reject("Failed to get resources");
            });
            return deferred.promise;
        }

        function ssoEnabled() {
            var deferred = $q.defer();
            $http({
                url: enumApp.url.draftUrl + 'account/sso',
                method: "POST"
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function () {
                deferred.reject("Failed to get sso status");
            });
            return deferred.promise;
        }

        function signOut() {
            var deferred = $q.defer();
            $http({
                url: enumApp.url.draftUrl + 'account/signout',
                method: "POST"
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function () {
                deferred.reject("Failed to get sign out");
            });
            return deferred.promise;
        }

        function addNewDomain(newDomain) {
            var deferred = $q.defer();
            $http({
                url: '/api/builder/addDomain?newDomain=' + newDomain,
                method: "POST",
                data: {}
            })
           .success(function (data) {
               deferred.resolve(data);
           })
           .error(function (data, status) {
               deferred.reject("Failed to add new domain");
           });
            return deferred.promise;
        }

        // get html builder domains
        function getDomains() {
            var deferred = $q.defer();
            $http({
                url: enumApp.url.draftUrl + 'builder/domains',
                method: "GET"
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function () {
                deferred.reject("Failed to get domains");
            });
            return deferred.promise;
        }
    }
})();
