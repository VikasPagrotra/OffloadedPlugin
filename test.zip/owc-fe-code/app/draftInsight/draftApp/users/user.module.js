(function(){
	'use strict';
	angular.module('user.module', ['ngSanitize']);
})();
