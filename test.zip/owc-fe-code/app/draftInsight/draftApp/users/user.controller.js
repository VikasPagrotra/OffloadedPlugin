(function () {
    'use strict';
    angular.module('user.module')
		.controller('userCtlr', userCtlr);

    userCtlr.$inject = ['draftAppService', 'fmsService', '$rootScope', '$http', '$interval', '$scope', '$state', '$timeout', 'loaderService'];

    function userCtlr(draftAppService, fmsService, $rootScope, $http, $interval, $scope, $state, $timeout, loaderService) {
        var vm = this;
        //this is for change tabs as this controller loads
        $rootScope.$broadcast('changeActiveTab', { str: 'userProfile' });
        loaderService.toggle(true);

        $scope.appFolder = window.location.href.indexOf('app/') > -1 ? 'app' : '';
        $scope.user = {};
        $scope.userSession = {};
        $scope.ssoEnabled = true;
        $scope.successMessage = false;
        $scope.failMessage = false;

        $scope.isAvatarExist = false;
        $scope.branches = [];
        $scope.getBranches = function () {            
            fmsService.getBranches().then(function (data) {
                $scope.branches = data;
            });
            draftAppService.ssoEnabled().then(function (data) {
                $scope.ssoEnabled = data;
            });
        };

        $scope.selectedBranches = [];

        $scope.getBranches();

        $scope.getUserInfo = function (userName) {
            loaderService.toggle(true);
            $http.get('/api/users/GetUserInfo?userName=' + userName + "&v=" + Date.now())
            .success(function (data) {
                loaderService.toggle(false);
                if(data.avatar)
                    data.avatar += "?v=" + Date.now();
                $scope.user = data;
                if(data.branchNo)
                    $scope.selectedBranches = data.branchNo.split(',');
                if (data.avatar != null)
                    $scope.isAvatarExist = true;
                if (!data.nickName)
                    $scope.user.nickName = data.firstName;
            })
            .error(function () {
                loaderService.toggle(false);
                console.log('No Data Returned');
            });
        };
        draftAppService.getUserSession().then(function (data) {
            loaderService.toggle(false);
            $scope.userSession = data;
            var userName = $scope.userSession.UserName == null ? '' : $scope.userSession.UserName;
            $scope.getUserInfo(userName);
        });

        $scope.updateUser = function (user) {

            user.OriginalAvatarUrl = angular.element('#OrigProfileImageUrl').val();
            user.profileSelectedArea = angular.element('#ProfileSelectedArea').val();
            user.avatar = angular.element('#tempImagePath').val();
           
            if (!$scope.ssoEnabled) {
                user.officeId = $scope.selectedBranches.join(',');
                user.branchNo = $scope.selectedBranches.join(',');
            }
                
            $http.post('/api/users/UpdateUser', user)
            .success(function (data) {
                if (data) {
                    console.log('Update Successfully');
                    $scope.successMessage = true;
                    data.avatar += "?v=" + Date.now();
                    $("#hf-uploaded-image-path").val(data.originalAvatarUrl);
                    $scope.user = data;
                    $rootScope.$broadcast('userUpdated');
                } else {
                    console.log('email is not exist');
                    $scope.failMessage = true;
                }
            })
            .error(function () {
                console.log('Error in updating');
                $scope.failMessage = true;
            });

            $timeout(function () {
                $scope.successMessage = false;
                $scope.failMessage = false;
            }, 10000);
        };
        $scope.openImageUploadBox = function (avatar) {
            if (avatar == null)
                avatar = '';
            openImageUploadBox(avatar);
        }
    }
})();
