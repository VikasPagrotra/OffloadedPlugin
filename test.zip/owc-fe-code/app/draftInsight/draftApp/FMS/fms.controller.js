(function () {
    'use strict'
    angular.module('fms.module')
		.controller('fmsCntl', fmsCntl);

    fmsCntl.$inject = ['$rootScope', '$scope', '$state', 'draftAppService', 'fmsModel', 'loaderService', 'fmsService', '$timeout'];

    function fmsCntl($rootScope, $scope, $state, draftAppService, fmsModel, loaderService, fmsService, $timeout) {

        var vm = this;

        vm.getBranchVacatures = getBranchVacatures;
        vm.getBranches = getBranches;
        vm.changeCurrentBranch = changeCurrentBranch;
        vm.getLookupsData = getLookupsData;
        vm.startSearch = startSearch;
        vm.branchVacatures = [];
        vm.currentBranchNo = 142;
        vm.publicationsData = [];
        vm.popoverContentPublicationsStatus = [];
        vm.popoverContentWarning35 = [];
        vm.settings = {};

        vm.users = [];
        vm.clients = [];
        vm.functionSearchKeys = [];
        vm.searchFilters = { Status: "online" };
        vm.moneyRanges = fmsModel.moneyRanges;

        vm.goToSpecificJob = goToSpecificJob;
        vm.showSideMenu = showSideMenu;
        vm.changeSearchType = changeSearchType;
        vm.formatDateFormat = formatDateFormat;

        vm.dateRange = {};
        vm.publicationDateRange = {
            //jobStartDate: moment('25-2-2017', "DDMMYYYY"),
            //jobEndDate: moment('10-5-2017', "DDMMYYYY")
        };

        $scope.$watch('vModel.dateRange', dateRangeWatcher, true);

        // get data of current logged in user 
        draftAppService.getUserSession().then(function (data) {
            $scope.userSession = data;
            vm.userSession = data;
            if ($scope.userSession != null && $scope.userSession.BranchNo != null && $scope.userSession.BranchNo.length > 0) {
                vm.searchFilters.Branches = $scope.userSession.LastBranchSelection;
                vm.searchFilters.Users = $scope.userSession.LastUsersSelection;
                vm.searchFilters.Clients = $scope.userSession.LastClientsSelection;
                vm.searchFilters.FunctionKeys = toCamel($scope.userSession.LastSelectedFunctionKeys);
                vm.searchFilters.MinimumMargin = formatMoney($scope.userSession.LastMinMarginSelection);
                vm.searchFilters.MaximumMargin = formatMoney($scope.userSession.LastMaxMarginSelection);
                vm.searchFilters.SearchType = $scope.userSession.LastSearchTypeSelected;
                vm.getBranches();
                if ($scope.userSession.LastBranchSelection != null) {
                    vm.getBranchVacatures();
                    vm.getLookupsData();
                }
            }
        });

        draftAppService.getSettings().then(resolveSettings);

        function resolveSettings(data) {
            vm.settings.companyName = data.CompanyName;
            vm.settings.logoUrl = data.LogoUrl;
            vm.settings.editVacatureEnabled = data.editVacatureEnabled;
        }

        // to convert json from capital case to lower case
        function toCamel(o) {
            var newO, origKey, newKey, value;
            if (o instanceof Array) {
                newO = [];
                for (origKey in o) {
                    value = o[origKey];
                    if (typeof value === "object") {
                        value = toCamel(value);
                    }
                    newO.push(value);
                }
            } else {
                newO = {}
                for (origKey in o) {
                    if (o.hasOwnProperty(origKey)) {
                        newKey = (origKey.charAt(0).toLowerCase() + origKey.slice(1) || origKey).toString()
                        value = o[origKey];
                        if (value !== null && value.constructor === Object) {
                            value = toCamel(value);
                        }
                        newO[newKey] = value;
                    }
                }
            }
            return newO
        }

        function dateRangeWatcher(newVal, oldVal) {
            if (newVal) {
                var startDate = draftAppService.dateParser(newVal.start, "DDMMYYYY"),
					endDate = draftAppService.dateParser(newVal.end, "DDMMYYYY");

                if (startDate !== false || endDate !== false) {
                    vm.searchFilters.StartDate = moment(newVal.start).format("YYYY-MM-DD");
                    vm.searchFilters.EndDate = moment(newVal.end).format("YYYY-MM-DD");
                    //vm.getBranchVacatures();
                }
            }
        }

        $scope.$on('searchFunctionKeysFetched', function (event, data) {
            vm.functionSearchKeys = data;
        }, true);

        var fmsId = $state.params.fmsId;
        if (fmsId) {
            draftAppService.getVacature(fmsId, true, "Overview");
        }
        $scope.$on('vacatureFetched', function (event, vacature) {
            vm.vacature = vacature;
        }, true);

        activate();

        function activate() {
            draftAppService.initPopover('.btn-popup');
            //this is for change tabs as this controller load
            $rootScope.$broadcast('changeActiveTab', { str: 'mijnPublicaties.FMS' });

            $rootScope.$broadcast('hideShowSideMenu', { 'bool': false });
        }

        function goToSpecificJob(fmsId) {
            $state.go('mijnPublicaties.vacature', { 'fmsId': fmsId });
        }

        function changeCurrentBranch() {
            // clear selected users
            vm.searchFilters.Users = [];
            // clear selected clients
            vm.searchFilters.Clients = [];
            //vm.getBranchVacatures();
            vm.getLookupsData();
        }

        function getBranchVacatures() {
            // show loading page
            loaderService.toggle(true);
            var searchFilter = updateMinimumAndMaximumRange(angular.copy(vm.searchFilters));
            fmsService.getBranchVacatures(searchFilter).then(function (data) {
                vm.branchVacatures = data;
                getPopoverData(data);
                loaderService.toggle(false); // hide loading page after getting all data
                draftAppService.initPopover('.publication-popover');
            });
        }

        function updateMinimumAndMaximumRange(obj) {
            if (obj.MinimumMargin || obj.MaximumMargin) {
                obj.MinimumMargin = parseInt(obj.MinimumMargin.toString().replace(".", ""));
                obj.MaximumMargin = parseInt(obj.MaximumMargin.toString().replace(".", ""));
            }
            return obj;
        }

        function formatMoney(margin) {
            if (margin)
                margin = margin.toLocaleString('de-DE');

            return margin;
        }

        function getBranches() {
            fmsService.getBranches().then(function (data) {
                vm.branches = data;
            });
        }

        function getLookupsData() {
            loaderService.toggleOverlayLoader(true);
            fmsService.getLookupsData(vm.searchFilters.Branches).then(function (data) {
                vm.users = data.users;
                vm.clients = data.clients;
                loaderService.toggleOverlayLoader(false);
            });
        }

        function changeSearchType(newSearchType) {
            vm.searchFilters.SearchType = newSearchType;
            //vm.getBranchVacatures();
        }

        function startSearch() {
            if (vm.searchFilters.SearchText.length > 3) {
                vm.getBranchVacatures();
            }
        }

        function showSideMenu(e, data, obj) {
            var clicked = angular.element(e.target);
            if (clicked.is('.job-title'))
                return false;
            if (data.addActive == true) {
                data.addActive = !data.addActive;
                $rootScope.$broadcast('hideShowSideMenu', { 'bool': data.addActive });
                return;
            }
            angular.forEach(obj, function (value, key) {
                angular.forEach(value, function (val, ke) {
                    if (ke == 'vacatures') {
                        angular.forEach(val, function (v, k) {
                            v.addActive = false && v.addActive;
                        });
                    }
                });
            });
            data.addActive = !data.addActive;
            $state.go('mijnPublicaties.FMS', { 'fmsId': data.fmsId }, { notify: false })
            getJobDetails(data.fmsId, data.addActive);
        }

        function getJobDetails(fmsId, active) {
            if (fmsId) {
                draftAppService.getVacature(fmsId);
            }
            $scope.$on('vacatureFetched', function (event, vacature) {
                vm.vacature = vacature;
                fmsService.scrollToCenterVacatureClicked(fmsId);
                $rootScope.$broadcast('hideShowSideMenu', { 'bool': active });
            }, true);
        }

        function getPopoverData(data) {
            angular.forEach(data, function (value, key) {
                angular.forEach(value.vacatures, function (v, k) {
                    createPopoverString(fmsService.createPopoverContent(v));
                    createPublicationPopoverFor35(v);
                });
            });
        }

        function createPopoverString(popoverContent) {
            var htmlString = "";
            if (popoverContent["live"].data.length > 0) {
                htmlString += popoverContent["live"].labelName + popoverContent["live"].data;
            }
            if (popoverContent["offline"].data.length > 0) {
                if (popoverContent["live"].data.length > 0) {
                    htmlString += "<hr />"
                }
                htmlString += popoverContent["offline"].labelName + popoverContent["offline"].data;
            }
            if (popoverContent["gepland"].data.length > 0) {
                if (popoverContent["offline"].data.length > 0 || popoverContent["live"].data.length > 0) {
                    htmlString += "<hr />"
                }
                htmlString += popoverContent["gepland"].labelName + popoverContent["gepland"].data;
            }
            vm.popoverContentPublicationsStatus[popoverContent["fmsId"]] = htmlString == "" ? "Deze vacature heeft geen publicaties" : htmlString;
        }

        function createPublicationPopoverFor35(vacature) {
            var htmlString = "";
            switch (vacature.oldLivePublications.length) {
                case 0: break;
                case 1:
                    htmlString = vacature.oldLivePublications[0] + " staat langer dan 35 dagen live en is daardoor nauwelijks vindbaar.";
                    break;
                default:
                    htmlString = createWarningMessageString(vacature.oldLivePublications) + " staan langer dan 35 dagen live en zijn daardoor nauwelijks vindbaar.";
                    break;
            }
            vm.popoverContentWarning35[vacature.fmsId] = htmlString;
        }

        function createWarningMessageString(publications) {
            var collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
            return publications.sort(collator.compare).join(", ").replace(/,(?=[^,]+$)/, ' en');
        }

        function formatDateFormat(date, isDate) {
            return fmsService.formatDateFormat(date, isDate);
        }
    }
})();
