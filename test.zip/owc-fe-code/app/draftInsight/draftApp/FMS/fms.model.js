(function(){
	'use strict';
	angular.module('fms.module')
		.service('fmsModel', fmsModel);

	fmsModel.$inject = [];

	function fmsModel() {
	    this.moneyRanges = ["500", "1.000", "1.500", "2.000", "2.500", "3.000", "3.500", "4.000", "4.500", "5.000", "6.000", "7.000", "8.000", "9.000", "10.000", "12.500", "15.000", "17.500", "20.000", "25.000", "30.000", "35.000", "40.000", "45.000"];
	    this.jobsData = [
			{
				"vacature": {
					"name":"Supervisor Customer Service",
					"url": "javascript:void(0)",
					"descriptionText": "Eerste publicatie 5 dagen geleden live gezet"
				},
				"addActive": false,
				"image": "../assets/images/laag.png",
				"icon": "icon-prior-major1",
				"iconColor": "danger",
				"fms": "1592839",
				"initeele": {
					"value": "-12%",
					"icon": "fa-thumbs-o-up",
					"color": "grey"
				},
				"huidige": {
					"value": "-5%",
					"icon": "fa-thumbs-o-up",
					"color": "grey",
					"icons": [
						{
							"icon": "fa-thumbs-o-up",
							"color": "grey"
						}
					]
				},
				"publicaties": {
					"value": "4(5)",
					"icon": "fa-exclamation-triangle",
					"color": "warning"
				},
				"views": {
					"value": "125",
					"icon": "",
					"color": ""
				},
				"conversie": {
					"value": "15%",
					"icon": "",
					"color": ""
				},
				"soliciaties": {
					"value": "18",
					"icon": "",
					"color": ""
				},
				"keywords": {
					"value": "(35)",
					"icon": "",
					"color": ""
				},
				"instroom": {
					"value": "4(5)",
					"icon": "fa-exclamation-triangle",
					"color": "warning"
				},
				"opdrachtgever": "Kruidvat"
			},
			{
				"vacature": {
					"name":"Supervisor Customer Service",
					"url": "javascript:void(0)",
					"descriptionText": "Eerste publicatie 1 dag geleden live gezet"
				},
				"addActive": false,
				"image": "../assets/images/gemiddeld.png",
				"icon": "icon-prior-normal1",
				"iconColor": "warning",
				"fms": "1592839",
				"initeele": {
					"value": "",
					"icon": "",
					"color": ""
				},
				"huidige": {
					"value": "+18%",
					"icons": [
						{
							"icon": "fa-thumbs-o-down",
							"color": "danger"
						}
					]
				},
				"publicaties": {
					"value": "3(3)",
					"icon": "",
					"color": ""
				},
				"views": {
					"value": "125",
					"icon": "",
					"color": ""
				},
				"conversie": {
					"value": "15%",
					"icon": "fa-exclamation-triangle",
					"color": "warning"
				},
				"soliciaties": {
					"value": "18",
					"icon": "",
					"color": ""
				},
				"keywords": {
					"value": "(35)",
					"icon": "",
					"color": ""
				},
				"instroom": {
					"value": "(5)",
					"icon": "",
					"color": ""
				},
				"opdrachtgever": "Gemeente Amsterdam"
			},
			{
				"vacature": {
					"name":"Supervisor Customer Service",
					"url": "javascript:void(0)",
					"descriptionText": "Eerste publicatie 15 dagen geleden live gezet"
				},
				"addActive": false,
				"image": "../assets/images/hoog.png",
				"icon": "icon-prior-trivial1",
				"iconColor": "excellent",
				"fms": "1592839",
				"initeele": {
					"value": "-45%",
					"icon": "fa-thumbs-o-down",
					"color": "grey"
				},
				"huidige": {
					"value": "-27%",
					"icons": [
						{
							"icon": "fa-thumbs-o-down",
							"color": "danger"
						},
						{
							"icon": "fa-exclamation-triangle",
							"color": "warning"
						}
					]
				},
				"publicaties": {
					"value": "1(2)",
					"icon": "",
					"color": ""
				},
				"views": {
					"value": "125",
					"icon": "fa-exclamation-triangle",
					"color": "warning"
				},
				"conversie": {
					"value": "15%",
					"icon": "",
					"color": ""
				},
				"soliciaties": {
					"value": "18",
					"icon": "fa-exclamation-triangle",
					"color": "warning"
				},
				"keywords": {
					"value": "(35)",
					"icon": "fa-exclamation-triangle",
					"color": "warning"
				},
				"instroom": {
					"value": "(4)",
					"icon": "",
					"color": ""
				},
				"opdrachtgever": "Kruidvat"
			}
		]
	}
})();
