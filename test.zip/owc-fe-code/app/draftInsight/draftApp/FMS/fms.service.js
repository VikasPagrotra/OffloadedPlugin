﻿(function () {
    'use strict';
    angular.module('fms.module')
		.service('fmsService', fmsService);

    fmsService.$inject = ['fmsModel', '$http', '$q', 'enumApp', 'publicatieInhoudService'];

    function fmsService(instroomModel, $http, $q, enumApp, publicatieInhoudService) {
        vm = this;

        vm.getBranchVacatures = getBranchVacatures;
        vm.getBranches = getBranches;
        vm.getLookupsData = getLookupsData;
        vm.scrollToCenterVacatureClicked = scrollToCenterVacatureClicked;
        vm.createPopoverContent = createPopoverContent;
        vm.branches = [];
        vm.formatDateFormat = formatDateFormat;

        function getBranchVacatures(branches) {
            var deferred = $q.defer();

            $http({
                url: enumApp.url.draftUrl + 'getBranchVacatures',
                method: "POST",
                data: branches
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function () {
                deferred.reject("Failed to get vacatures for this branch");
            });

            return deferred.promise;
        }

        function getBranches() {
            var deferred = $q.defer();
            if (vm.branches.length) {
                deferred.resolve(vm.branches);
                return deferred.promise;
            }

            $http({
                url: enumApp.url.draftUrl + '/vacture/branches',
                method: "GET"
            })
            .success(function (data) {
                vm.branches = data;
                deferred.resolve(data);
            })
            .error(function () {
                deferred.reject("Failed to get all branches");
            });

            return deferred.promise;
        }

        function getLookupsData(currentBranches) {
            var deferred = $q.defer();

            $http({
                url: enumApp.url.draftUrl + '/vacture/getLookupsData',
                method: "POST",
                data: currentBranches
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function () {
                deferred.reject("Failed to get lookups Data for this branch");
            });

            return deferred.promise;
        }

        function scrollToCenterVacatureClicked(id) {
            var windowHeight = $(window).height(),
                divHeight = $('#fmsid-' + id).height(),
                offset = -(windowHeight - divHeight) / 2;
                
            $(window).scrollTop($('#fmsid-' + id).offset().top + offset);
        }

        function getPublicatieStatusText(publicatie) {
            var publicatieStatusText = '';

            var isVacatureOffline = publicatie.isVacatureOffline;
            var isOffline = publicatie.isOffline;
            var startDate = moment(publicatie.startDate, 'DD/MM/YYYY hh:mm');
            var endDate = moment(publicatie.endDate, 'DD/MM/YYYY hh:mm');
            var currentTime = moment(new Date());

            if (!isVacatureOffline && startDate <= currentTime && endDate >= currentTime && !isOffline) {
                var validateObj = publicatie.isValidConcept;
                if (validateObj && publicatie.publishDate != null) {
                    publicatieStatusText = "Live!";
                } else {
                    publicatieStatusText = "in afwachting";
                }
            }

            else if (isVacatureOffline || isOffline || (startDate < currentTime && endDate < currentTime)) {
                publicatieStatusText = "offline";
            }

            else if (startDate > currentTime && endDate > currentTime) {
                publicatieStatusText = "gepland";
            }

            return publicatieStatusText;
        }

        function formatDateFormat(date, isDate) {
            var formatedDate = isDate ? date : moment(date, 'DD/MM/YYYY HH:mm');
            return moment(formatedDate).format('DD-MM-YYYY');
        }

        function createPopoverContent(vacature) {
            var popoverContent = {
                "live": {
                    "labelName": "<label>Live publicaties</label><br />",
                    "data": ""
                },
                "gepland": {
                    "labelName": "<label>Geplande publicaties</label><br />",
                    "data": ""
                },
                "offline": {
                    "labelName": "<label>Offline publicaties</label><br />",
                    "data": ""
                },
                "fmsId": ""
            };
            popoverContent["fmsId"] = vacature.fmsId;

            var publicationArray = [];
            angular.forEach(vacature.publications, function (value, key) {
                publicationArray.push(value.circle);
            });

            var collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
            publicationArray.sort(collator.compare);
            angular.forEach(publicationArray, function (val, ke) {
                angular.forEach(vacature.publications, function (k, v) {
                    if (val == k.circle) {
                        if (getPublicatieStatusText(k) == "Live!") {
                            if (k.closeType == "FmsClosed") {
                                popoverContent["live"].data = popoverContent["live"].data + k.circle + " - van " + formatDateFormat(k.startDate, false) + "<br />";
                            } else {
                                popoverContent["live"].data = popoverContent["live"].data + k.circle + " - van " + formatDateFormat(k.startDate, false) + " tot " + formatDateFormat(k.endDate, false) + "<br />";
                            }
                        } else if (getPublicatieStatusText(k) == "offline") {
                            popoverContent["offline"].data = popoverContent["offline"].data + k.circle + " - van " + formatDateFormat(k.startDate, false) +  ((formatDateFormat(new String(k.publishDate).substring(0, 10),true) === "Invalid date") ? "" : " tot " + formatDateFormat(new String(k.publishDate).substring(0, 10),true)) + "<br />";
                        } else if (getPublicatieStatusText(k) == "gepland") {
                            if (k.closeType == "FmsClosed") {
                                popoverContent["gepland"].data = popoverContent["gepland"].data + k.circle + " - van " + formatDateFormat(k.startDate, false) + "<br />";
                            } else {
                                popoverContent["gepland"].data = popoverContent["gepland"].data + k.circle + " - van " + formatDateFormat(k.startDate, false) + " tot " + formatDateFormat(k.endDate, false) + "<br />";
                            }
                        }
                    }
                });
            })
            return popoverContent;
        }
    }
})();
