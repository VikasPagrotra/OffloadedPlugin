(function(){
	'use strict'
	angular.module('fms.module', []);
})();
