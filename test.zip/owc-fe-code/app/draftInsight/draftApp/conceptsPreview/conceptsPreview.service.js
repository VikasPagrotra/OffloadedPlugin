﻿(function () {
    'use strict';
    angular.module('conceptsPreview.module')
		.service('conceptsPreviewService', conceptsPreviewService);

    conceptsPreviewService.$inject = ['fmsModel', '$http', '$q', 'enumApp'];

    function conceptsPreviewService(instroomModel, $http, $q, enumApp) {
        var service;

        service = {
            a: 1
        };
        
        return service;
    }
})();
