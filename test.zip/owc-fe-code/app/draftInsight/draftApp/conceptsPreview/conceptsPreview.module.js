(function(){
	'use strict'
	angular.module('conceptsPreview.module', []);
})();
