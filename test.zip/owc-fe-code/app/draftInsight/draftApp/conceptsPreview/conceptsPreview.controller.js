(function(){
	'use strict'
    angular.module('conceptsPreview.module')
		.controller('conceptsPreviewCntl', conceptsPreviewCntl);

    conceptsPreviewCntl.$inject = ['$rootScope', '$scope', '$state', 'draftAppService', 'fmsModel', 'loaderService', 'fmsService', 'conceptsPreviewService'];

    function conceptsPreviewCntl($rootScope, $scope, $state, draftAppService, fmsModel, loaderService, fmsService, conceptsPreviewService) {

	    var vm = this;
	    vm.conceptPreviewNotExist = false;
        vm.conceptPreview = [];
	    var fmsId = $state.params.fmsId,
            previewId = $state.params.previewId;
		if (fmsId) {
			draftAppService.getVacature(fmsId);
		}
		$scope.$on('vacatureFetched', function (event, vacature) {
		    vm.vacature = vacature;
		    if (previewId) {
		        getConceptsPreview(previewId);
		    }
		}, true);

		activate();

		function activate() {
			draftAppService.initPopover('.btn-popup');

			$rootScope.$broadcast('changeActiveTab', { str: 'mijnPublicaties.conceptsPreview' });
		}

		function getConceptsPreview(previewId) {
		    var elementPos = vm.vacature.publicatieInhoud.drafts.map(function (x) {
		        return x.publicatieCircle;
		    }).indexOf(previewId);
		    if (elementPos != -1) {
                vm.conceptPreview = vm.vacature.publicatieInhoud.drafts[elementPos];
		    } else {
		        vm.conceptPreviewNotExist = true;
		    }
		    
        }
        
	}
})();
