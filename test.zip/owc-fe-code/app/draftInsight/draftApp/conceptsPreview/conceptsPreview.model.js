(function(){
	'use strict';
    angular.module('conceptsPreview.module')
		.service('conceptsPreviewModel', conceptsPreviewModel);

	conceptsPreviewModel.$inject = [];

	function conceptsPreviewModel() {
	    
	}
})();
