(function () {
    'use strict'
    angular.module('conversieOverzicht.module')
		.service('conversieOverzichtService', conversieOverzichtService);

    conversieOverzichtService.$inject = ['$http', '$q', 'enumApp'];

    function conversieOverzichtService($http, $q, enumApp) {
        var apiUrl = enumApp.url.draftUrl;
        //var apiUrl = 'http://olympia-jobapplicationprediction-api-test.azurewebsites.net/api/';

        return {
            getTableData: getTableData,
            getConversionStats:getConversionStats,
            getSessies: getSessies,
            getVacaturesLive: getVacaturesLive,
            getSoliciaties: getSoliciaties,
            getConversie: getConversie,
            getGemSessieduur: getGemSessieduur,
            getBounceperntage: getBounceperntage,
            getNieuweVacatures: getNieuweVacatures,
            normalizeDate: normalizeDate
        };

        function getTableData(offices, startDate, endDate, startDate2, endDate2) {
            var deferred = $q.defer();
            $http({
                url: apiUrl + 'conversion/sources',
                method: "GET",
                params: {
                    offices: offices,
                    startDate: startDate,
                    endDate: endDate,
                    startDate2: startDate2,
                    endDate2: endDate2
                }
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                console.log(JSON.stringify(data));
                deferred.reject("Failed to get data");
            });
            return deferred.promise;
        }

        function getConversionStats(offices, startDate, endDate, startDate2, endDate2) {
            var deferred = $q.defer();
            $http({
                url: apiUrl + 'conversion/stats',
                method: "GET",
                params: {
                    offices: offices,
                    startDate: startDate,
                    endDate: endDate,
                    startDate2: startDate2,
                    endDate2: endDate2
                }
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function () {
                deferred.reject("Failed to get data");
            });
            return deferred.promise;
        }

        function getSessies(offices, startDate, endDate, startDate2, endDate2) {
            var deferred = $q.defer();
            $http({
                url: apiUrl + 'conversion/views',
                method: "GET",
                params: {
                    offices: offices,
                    startDate: startDate,
                    endDate: endDate,
                    startDate2: startDate2,
                    endDate2: endDate2
                }
            }).success(function (data) {
                deferred.resolve(normalizeDate(data));
            }).error(function () {
                deferred.reject("Failed to get data");
            });
            return deferred.promise;
        }

        function getVacaturesLive(offices, startDate, endDate, startDate2, endDate2) {
            var deferred = $q.defer();
            $http({
                url: apiUrl + 'conversion/live-jobs',
                method: "GET",
                params: {
                    offices: offices,
                    startDate: startDate,
                    endDate: endDate,
                    startDate2: startDate2,
                    endDate2: endDate2
                }
            }).success(function (data) {
                deferred.resolve(normalizeDate(data));
            }).error(function () {
                deferred.reject("Failed to get data");
            });
            return deferred.promise;
        }

        function getSoliciaties(offices, startDate, endDate, startDate2, endDate2) {
            var deferred = $q.defer();
            $http({
                url: apiUrl + 'conversion/applications',
                method: "GET",
                params: {
                    offices: offices,
                    startDate: startDate,
                    endDate: endDate,
                    startDate2: startDate2,
                    endDate2: endDate2
                }
            }).success(function (data) {
                deferred.resolve(normalizeDate(data));
            }).error(function () {
                deferred.reject("Failed to get data");
            });
            return deferred.promise;
        }

        function getConversie(offices, startDate, endDate, startDate2, endDate2) {
            var deferred = $q.defer();
            $http({
                url: apiUrl + 'conversion/conversions',
                method: "GET",
                params: {
                    offices: offices,
                    startDate: startDate,
                    endDate: endDate,
                    startDate2: startDate2,
                    endDate2: endDate2
                }
            }).success(function (data) {
                deferred.resolve(normalizeDate(data));
            }).error(function () {
                deferred.reject("Failed to get data");
            });
            return deferred.promise;
        }

        function getGemSessieduur(offices, startDate, endDate, startDate2, endDate2) {
            var deferred = $q.defer();
            $http({
                url: apiUrl + 'conversion/avg-session-time',
                method: "GET",
                params: {
                    offices: offices,
                    startDate: startDate,
                    endDate: endDate,
                    startDate2: startDate2,
                    endDate2: endDate2
                }
            }).success(function (data) {
                deferred.resolve(normalizeDate(data));
            }).error(function () {
                deferred.reject("Failed to get data");
            });
            return deferred.promise;
        }

        function getBounceperntage(offices, startDate, endDate, startDate2, endDate2) {
            var deferred = $q.defer();
            $http({
                url: apiUrl + 'conversion/bounces',
                method: "GET",
                params: {
                    offices: offices,
                    startDate: startDate,
                    endDate: endDate,
                    startDate2: startDate2,
                    endDate2: endDate2
                }
            }).success(function (data) {
                deferred.resolve(normalizeDate(data));
            }).error(function () {
                deferred.reject("Failed to get data");
            });
            return deferred.promise;
        }

        function getNieuweVacatures(offices, startDate, endDate, startDate2, endDate2) {
            var deferred = $q.defer();
            $http({
                url: apiUrl + 'conversion/new-jobs',
                method: "GET",
                params: {
                    offices: offices,
                    startDate: startDate,
                    endDate: endDate,
                    startDate2: startDate2,
                    endDate2: endDate2
                }
            }).success(function (data) {
                deferred.resolve(normalizeDate(data));
            }).error(function () {
                deferred.reject("Failed to get data");
            });
            return deferred.promise;
        }

        function normalizeDate(arr, index) {
            index = index || 0;
            arr.forEach(function (item) {
                item[index] = new Date(item[index]);
            });
            return arr;
        }
    }
})();
