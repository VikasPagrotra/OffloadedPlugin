(function () {
    'use strict'
    angular.module('conversieOverzicht.module')
		.controller('conversieOverzichtCtrl', conversieOverzichtCtrl);

    conversieOverzichtCtrl.$inject = ['$scope', '$interval', 'conversieOverzichtService', 'fmsService', 'loaderService', 'draftAppService', 'lineChartService', '$rootScope'];

    function conversieOverzichtCtrl($scope, $interval, conversieOverzichtService, fmsService, loaderService, draftAppService, lineChartService, $rootScope) {
        var vm = this;

        vm.getBranchVacatures = getBranchVacatures;
        vm.getBranches = getBranches;
        vm.branchVacatures = [];
        vm.currentBranches = [];
        vm.branches = [];
        vm.currentBranchNo = 142;

        vm.dateRange = {};
        vm.dateRange2 = {};
        vm.compare = false;

        vm.publicationDateRange = {
            jobStartDate: moment('2017-2-22', "DDMMYYYY"),
            jobEndDate: moment('2017-4-30', "DDMMYYYY")
        };
        vm.publicationDateRange2 = {
            jobStartDate: moment('2017-2-22', "DDMMYYYY"),
            jobEndDate: moment('2017-4-30', "DDMMYYYY")
        };

        vm.chartPeriod = 'Dag';
        vm.changeChartPeriod = changeChartPeriod;
        vm.drawCharts = drawCharts;
        /*
        //Old Functions
        vm.drawSessiesChart = drawSessiesChart;
        vm.drawVacaturesLiveChart = drawVacaturesLiveChart;
        vm.drawSoliciatiesChart = drawSoliciatiesChart;
        vm.drawConversieChart = drawConversieChart;
        vm.drawGemSessieduurChart = drawGemSessieduurChart;
        vm.drawBounceperntageChart = drawBounceperntageChart;
        vm.drawNieuweVacaturesChart = drawNieuweVacaturesChart;
        vm.getTableData = getTableData;
        */
        vm.getFormattedDate = function (date) {
            return new moment(date).format('MMM DD, YYYY');
        };

        vm.chartSize = {
            small: { width: 500, height: 200 },
            big: { height: 300 }
        };

        vm.tableData = [];
        vm.tableDataTotal = {};

        vm.calcDiffPercentage = calcDiffPercentage;

        draftAppService.initPopover('.btn-popup');

        //this is for change tabs as this controller loads
        $rootScope.$broadcast('changeActiveTab', { str: 'vestigings.conversieOverzicht' });

        // get data of current logged in user 
        draftAppService.getUserSession().then(function (data) {
            $scope.userSession = data;
            vm.userSession = data;
            if ($scope.userSession != null && $scope.userSession.BranchNo != null && $scope.userSession.BranchNo.length > 0) {
                vm.currentBranches = $scope.userSession.LastBranchSelection;
                vm.getBranches();
                //if ($scope.userSession.LastBranchSelection != null) {
                //    vm.getBranchVacatures();
                //}
            }
        });

        var oldDateRange = null;
        var oldDateRange2 = null;
        var oldCurrentBranches = null;
        var oldCompare = false;
        $interval(function () {
            if (!angular.equals(vm.dateRange, {}) && !angular.equals(vm.currentBranches, []) && (vm.dateRange !== oldDateRange || vm.currentBranches !== oldCurrentBranches || vm.dateRange2 !== oldDateRange2 || vm.compare !== oldCompare)) {
                oldDateRange = vm.dateRange;
                oldDateRange2 = vm.dateRange2;
                oldCurrentBranches = vm.currentBranches;
                oldCompare = vm.compare;
                vm.drawCharts(true);                
                //vm.getTableData(true);
            }
        }, 500);        

        function getBranchVacatures() {
            loaderService.toggle(true);
            var searchParams = { Branches: vm.currentBranches };
            fmsService.getBranchVacatures(searchParams).then(function (data) {
                vm.branchVacatures = data;
                loaderService.toggle(false);
            });
        }

        function getBranches() {
            fmsService.getBranches().then(function (data) {
                vm.branches = data;
            });
        }

        function drawCharts(refetch) {
            var offices = vm.currentBranches;
            var startDate = vm.dateRange.start;
            var endDate = vm.dateRange.end;
            var startDate2 = vm.compare ? vm.dateRange2.start : null;
            var endDate2 = vm.compare ? vm.dateRange2.end : null;
            loaderService.toggle(true);
            if (!refetch) {
                draw();
            }
            else {
                conversieOverzichtService.getConversionStats(offices, startDate, endDate, startDate2, endDate2)
                .then(function (data) {
                    vm.sessiesChartData = conversieOverzichtService.normalizeDate(data.jobViews);
                    vm.vacaturesLiveChartData = conversieOverzichtService.normalizeDate(data.liveJobs);
                    vm.soliciatiesChartData = conversieOverzichtService.normalizeDate(data.applications);
                    vm.conversieChartData = conversieOverzichtService.normalizeDate(data.conversions);
                    vm.bounceperntageChartData = conversieOverzichtService.normalizeDate(data.bounces);
                    vm.nieuweVacaturesChartData = conversieOverzichtService.normalizeDate(data.newJobs);
                    vm.gemSessieduurChartData = conversieOverzichtService.normalizeDate(data.avgSessionTime);
                    vm.tableDataTotal = data.sources.tableDataTotal;
                    vm.tableData = data.sources.tableData;

                    vm.jobViewsChange = data.jobViewsChange;
                    vm.newJobsChange = data.newJobsChange;
                    vm.liveJobsChange = data.liveJobsChange;
                    vm.applicationsChange = data.applicationsChange;
                    vm.avgSessionTimeChange = data.avgSessionTimeChange;
                    vm.bounceChange = data.bounceChange;
                    vm.conversionChange = data.conversionChange;
                    draw();
                });
            }
            function draw() {
                drawChart('sessiesChart', 'Sessions', 'Sessions', 'Sessions (2)', 'Sessions (2)', vm.sessiesChartData, '1515');
                drawChart('vacaturesLiveChart', 'Vacatures (live!)', 'Vacatures (live!)', 'Vacatures (live!) (2)', 'Vacatures (live!) (2)', vm.vacaturesLiveChartData);
                drawChart('soliciatiesChart', 'Sollicitaties', 'Sollicitaties', 'Sollicitaties (2)', 'Sollicitaties (2)', vm.soliciatiesChartData);
                drawChart('conversieChart', 'Conversie', 'Conversie', 'Conversie (2)', 'Conversie (2)', vm.conversieChartData);
                drawChart('bounceperntageChart', 'Bouncepercentage', 'Bouncepercentage', 'Bouncepercentage (2)', 'Bouncepercentage (2)', vm.bounceperntageChartData);
                drawChart('nieuweVacaturesChart', 'Nieuwe vacatures', 'Nieuwe vacatures', 'Nieuwe vacatures (2)', 'Nieuwe vacatures (2)', vm.nieuweVacaturesChartData);
                drawChart('gemSessieduurChart', 'Gem. sessieduur', 'Gem. sessieduur', 'Gem. sessieduur (2)', 'Gem. sessieduur (2)', vm.gemSessieduurChartData);
                loaderService.toggle(false);
            }
            /*
            //Old Functions
            vm.drawSessiesChart(refetch);
            vm.drawVacaturesLiveChart(refetch);
            vm.drawSoliciatiesChart(refetch);
            vm.drawConversieChart(refetch);
            vm.drawGemSessieduurChart(refetch);
            vm.drawBounceperntageChart(refetch);
            vm.drawNieuweVacaturesChart(refetch);
            */
        }
        
        function drawChart(divId, title, exactTitle, compareTitle, compareExactTitle, arrData, width) {
            
            var chartData = {
                "chartLegends": [
                    { "title": "Date", "dataType": "date" },
                    { "title": title, "dataType": "number" }
                ],
                "chartData": { "arrData": arrData }
            };
            if (vm.compare) {
                chartData.chartLegends.push({ "title": compareTitle, "exactTitle": compareExactTitle, "dataType": "number" });
            }
            var opts = { divId: divId, height: vm.chartSize.big.height, width: (width) ? width : vm.chartSize.small.width, compare: vm.compare, colors: ['#171580', '#ff6412'],pointSize:0 };
            lineChartService.createChartAndTable(chartData, vm.chartPeriod, opts);
        }

        function changeChartPeriod(period) {
            vm.chartPeriod = period;
            vm.drawCharts(false);
        }
        /*
        //Old Functions
        function drawSessiesChart(refetch) {
            if (!refetch && vm.sessiesChartData) {
                draw();
                return;
            }

            loaderService.toggle(true);
            var offices = vm.currentBranches;
            var startDate = vm.dateRange.start;
            var endDate = vm.dateRange.end;
            var startDate2 = vm.compare ? vm.dateRange2.start : null;
            var endDate2 = vm.compare ? vm.dateRange2.end : null;
            conversieOverzichtService.getSessies(offices, startDate, endDate, startDate2, endDate2)
                .then(function (data) {
                    vm.sessiesChartData = data;
                    if (data != null) {
                        draw();
                    }
                    loaderService.toggle(false);
                });

            function draw() {
                var chartData = {
                    "chartLegends": [
                        { "title": "Date", "dataType": "date" },
                        { "title": "Sessions", "exactTitle": "Sessions", "dataType": "number" }
                    ],
                    "chartData": { "arrData": vm.sessiesChartData }
                };
                if (vm.compare) {
                    chartData.chartLegends.push({ "title": "Sessions (2)", "exactTitle": "Sessions (2)", "dataType": "number" });
                }
                var opts = { divId: 'sessiesChart', height: vm.chartSize.big.height, width: '1515', compare: vm.compare, colors: ['#171580', '#ff6412'] };
                lineChartService.createChartAndTable(chartData, vm.chartPeriod, opts);
            }
        }

        function drawVacaturesLiveChart(refetch) {
            if (!refetch && vm.vacaturesLiveChartData) {
                draw();
                return;
            }

            loaderService.toggle(true);
            var offices = vm.currentBranches;
            var startDate = vm.dateRange.start;
            var endDate = vm.dateRange.end;
            var startDate2 = vm.compare ? vm.dateRange2.start : null;
            var endDate2 = vm.compare ? vm.dateRange2.end : null;
            conversieOverzichtService.getVacaturesLive(offices, startDate, endDate, startDate2, endDate2)
                .then(function (data) {
                    vm.vacaturesLiveChartData = data;
                    if (data != null) {
                        draw();
                    }
                    loaderService.toggle(false);
                });

            function draw() {
                var chartData = {
                    "chartLegends": [
                        { "title": "Date", "dataType": "date" },
                        { "title": "Vacatures (live!)", "exactTitle": "Vacatures (live!)", "dataType": "number" }
                    ],
                    "chartData": { "arrData": vm.vacaturesLiveChartData }
                };
                if (vm.compare) {
                    chartData.chartLegends.push({ "title": "Vacatures (live!) (2)", "exactTitle": "Vacatures (live!) (2)", "dataType": "number" });
                }
                var opts = { divId: 'vacaturesLiveChart', width: vm.chartSize.small.width, height: vm.chartSize.small.height, compare: vm.compare, colors: ['#171580', '#ff6412'] };
                lineChartService.createChartAndTable(chartData, vm.chartPeriod, opts);
            }
        }

        function drawSoliciatiesChart(refetch) {
            if (!refetch && vm.soliciatiesChartData) {
                draw();
                return;
            }

            loaderService.toggle(true);
            var offices = vm.currentBranches;
            var startDate = vm.dateRange.start;
            var endDate = vm.dateRange.end;
            var startDate2 = vm.compare ? vm.dateRange2.start : null;
            var endDate2 = vm.compare ? vm.dateRange2.end : null;
            conversieOverzichtService.getSoliciaties(offices, startDate, endDate, startDate2, endDate2)
                .then(function (data) {
                    vm.soliciatiesChartData = data;
                    if (data != null) {
                        draw();
                    }
                    loaderService.toggle(false);
                });

            function draw() {
                var chartData = {
                    "chartLegends": [
                        { "title": "Date", "dataType": "date" },
                        { "title": "Sollicitaties", "exactTitle": "Sollicitaties", "dataType": "number" }
                    ],
                    "chartData": { "arrData": vm.soliciatiesChartData }
                };
                if (vm.compare) {
                    chartData.chartLegends.push({ "title": "Sollicitaties (2)", "exactTitle": "Sollicitaties (2)", "dataType": "number" });
                }
                var opts = { divId: 'soliciatiesChart', width: vm.chartSize.small.width, height: vm.chartSize.small.height, compare: vm.compare, colors: ['#171580', '#ff6412'] };
                lineChartService.createChartAndTable(chartData, vm.chartPeriod, opts);
            }
        }

        function drawConversieChart(refetch) {
            if (!refetch && vm.conversieChartData) {
                draw();
                return;
            }

            loaderService.toggle(true);
            var offices = vm.currentBranches;
            var startDate = vm.dateRange.start;
            var endDate = vm.dateRange.end;
            var startDate2 = vm.compare ? vm.dateRange2.start : null;
            var endDate2 = vm.compare ? vm.dateRange2.end : null;
            conversieOverzichtService.getConversie(offices, startDate, endDate, startDate2, endDate2)
                .then(function (data) {
                    vm.conversieChartData = data;
                    if (data != null) {
                        draw();
                    }
                    loaderService.toggle(false);
                });

            function draw() {
                var chartData = {
                    "chartLegends": [
                        { "title": "Date", "dataType": "date" },
                        { "title": "Conversie", "exactTitle": "Conversie", "dataType": "number" }
                    ],
                    "chartData": { "arrData": vm.conversieChartData }
                };
                if (vm.compare) {
                    chartData.chartLegends.push({ "title": "Conversie (2)", "exactTitle": "Conversie (2)", "dataType": "number" });
                }
                var opts = { divId: 'conversieChart', width: vm.chartSize.small.width, height: vm.chartSize.small.height, compare: vm.compare, colors: ['#171580', '#ff6412'] };
                lineChartService.createChartAndTable(chartData, vm.chartPeriod, opts);
            }
        }

        function drawGemSessieduurChart(refetch) {
            if (!refetch && vm.gemSessieduurChartData) {
                draw();
                return;
            }

            loaderService.toggle(true);
            var offices = vm.currentBranches;
            var startDate = vm.dateRange.start;
            var endDate = vm.dateRange.end;
            var startDate2 = vm.compare ? vm.dateRange2.start : null;
            var endDate2 = vm.compare ? vm.dateRange2.end : null;
            conversieOverzichtService.getGemSessieduur(offices, startDate, endDate, startDate2, endDate2)
                .then(function (data) {
                    vm.gemSessieduurChartData = data;
                    if (data != null) {
                        draw();
                    }
                    loaderService.toggle(false);
                });

            function draw() {
                var chartData = {
                    "chartLegends": [
                        { "title": "Date", "dataType": "date" },
                        { "title": "Gem. sessieduur", "exactTitle": "Gem. sessieduur", "dataType": "number" }
                    ],
                    "chartData": { "arrData": vm.gemSessieduurChartData }
                };
                if (vm.compare) {
                    chartData.chartLegends.push({ "title": "Gem. sessieduur (2)", "exactTitle": "Gem. sessieduur (2)", "dataType": "number" });
                }
                var opts = { divId: 'gemSessieduurChart', width: vm.chartSize.small.width, height: vm.chartSize.small.height, compare: vm.compare, colors: ['#171580', '#ff6412'] };
                lineChartService.createChartAndTable(chartData, vm.chartPeriod, opts);
            }
        }

        function drawBounceperntageChart(refetch) {
            if (!refetch && vm.bounceperntageChartData) {
                draw();
                return;
            }

            loaderService.toggle(true);
            var offices = vm.currentBranches;
            var startDate = vm.dateRange.start;
            var endDate = vm.dateRange.end;
            var startDate2 = vm.compare ? vm.dateRange2.start : null;
            var endDate2 = vm.compare ? vm.dateRange2.end : null;
            conversieOverzichtService.getBounceperntage(offices, startDate, endDate, startDate2, endDate2)
                .then(function (data) {
                    vm.bounceperntageChartData = data;
                    if (data != null) {
                        draw();
                    }
                    loaderService.toggle(false);
                });

            function draw() {
                var chartData = {
                    "chartLegends": [
                        { "title": "Date", "dataType": "date" },
                        { "title": "Bouncepercentage", "exactTitle": "Bouncepercentage", "dataType": "number" }
                    ],
                    "chartData": { "arrData": vm.bounceperntageChartData }
                };
                if (vm.compare) {
                    chartData.chartLegends.push({ "title": "Bouncepercentage (2)", "exactTitle": "Bouncepercentage (2)", "dataType": "number" });
                }
                var opts = { divId: 'bounceperntageChart', width: vm.chartSize.small.width, height: vm.chartSize.small.height, compare: vm.compare, colors: ['#171580', '#ff6412'] };
                lineChartService.createChartAndTable(chartData, vm.chartPeriod, opts);
            }
        }

        function drawNieuweVacaturesChart(refetch) {
            if (!refetch && vm.nieuweVacaturesChartData) {
                draw();
                return;
            }

            loaderService.toggle(true);
            var offices = vm.currentBranches;
            var startDate = vm.dateRange.start;
            var endDate = vm.dateRange.end;
            var startDate2 = vm.compare ? vm.dateRange2.start : null;
            var endDate2 = vm.compare ? vm.dateRange2.end : null;
            conversieOverzichtService.getNieuweVacatures(offices, startDate, endDate, startDate2, endDate2)
                .then(function (data) {
                    vm.nieuweVacaturesChartData = data;
                    if (data != null) {
                        draw();
                    }
                    loaderService.toggle(false);
                });

            function draw() {
                var chartData = {
                    "chartLegends": [
                        { "title": "Date", "dataType": "date" },
                        { "title": "Nieuwe vacatures", "exactTitle": "Nieuwe vacatures", "dataType": "number" }
                    ],
                    "chartData": { "arrData": vm.nieuweVacaturesChartData }
                };
                if (vm.compare) {
                    chartData.chartLegends.push({ "title": "Nieuwe vacatures (2)", "exactTitle": "Nieuwe vacatures (2)", "dataType": "number" });
                }
                var opts = { divId: 'nieuweVacaturesChart', width: vm.chartSize.small.width, height: vm.chartSize.small.height, compare: vm.compare, colors: ['#171580', '#ff6412'] };
                lineChartService.createChartAndTable(chartData, vm.chartPeriod, opts);
            }
        }

        function getTableData(refetch) {
            if (!refetch && vm.tableDataTotal && vm.tableData) {
                return;
            }

            loaderService.toggle(true);
            var offices = vm.currentBranches;
            var startDate = vm.dateRange.start;
            var endDate = vm.dateRange.end;
            var startDate2 = vm.compare ? vm.dateRange2.start : null;
            var endDate2 = vm.compare ? vm.dateRange2.end : null;
            conversieOverzichtService.getTableData(offices, startDate, endDate, startDate2, endDate2)
                .then(function (data) {
                    vm.tableDataTotal = data.tableDataTotal;
                    vm.tableData = data.tableData;
                    loaderService.toggle(false);
                });
        }
        */
        function calcDiffPercentage(n1, n2) {
            var base = n2;
            if (base === 0) base = 1;
            var rslt = (n1 - n2) * 100 / base;
            return rslt.toFixed(2);
        }
    }
})();
