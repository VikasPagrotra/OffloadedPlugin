(function(){
	'use strict'
	angular.module('conversieOverzicht.module', []);
})();
