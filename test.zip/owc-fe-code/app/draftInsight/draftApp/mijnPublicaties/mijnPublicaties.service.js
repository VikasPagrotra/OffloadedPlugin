(function(){
	'use strict'
	angular.module('mijnPublicaties.module')
		.controller('mijnPublicatiesService', mijnPublicatiesService);

	mijnPublicatiesService.$inject = [];

	function mijnPublicatiesService(){

	}
})();