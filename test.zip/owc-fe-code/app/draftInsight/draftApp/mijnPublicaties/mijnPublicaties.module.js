(function(){
	'use strict'
	angular.module('mijnPublicaties.module', []);
})();