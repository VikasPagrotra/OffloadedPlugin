(function(){
	'use strict'
	angular.module('mijnPublicaties.module')
		.controller('mijnPublicatiesCntl', mijnPublicatiesCntl);

	mijnPublicatiesCntl.$inject = ['$state'];

	function mijnPublicatiesCntl($state) {
	    $state.go('mijnPublicaties.FMS', { 'fmsId': '' });
	}
})();
