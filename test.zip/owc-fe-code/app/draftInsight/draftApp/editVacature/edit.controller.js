﻿(function () {
    'use strict';
    angular.module('editVacature.module').controller('editCtlr', editCtlr);

    editCtlr.$inject = ['$rootScope', '$http', '$interval', '$scope', '$state', '$timeout', 'draftAppService', 'loaderService', 'enumApp', '$q'];

    function editCtlr($rootScope, $http, $interval, $scope, $state, $timeout, draftAppService, loaderService, enumApp, $q) {
        var vm = this;
        vm.kenmerken = 'Inhound';
        vm.publicatieData = {tags : {}};
        vm.save = save;
        vm.getCurrentUserBranches = getCurrentUserBranches;
        vm.checkValidVacature = checkValidVacature;
        vm.bindPublicationData = bindPublicationData;
        vm.branches = [];
        vm.validationObj = {};

        var fmsId = $state.params.fmsId;
        if (fmsId) {
            draftAppService.getVacature(fmsId);
        }
        $scope.$on('vacatureFetched', function (event, vacature) {
            vm.vacature = vacature;
            vm.bindPublicationData();
        }, true);

        // get tags
        draftAppService.getTagsSets()
            .then(function (data) {
                var cancelTagesInterval = $interval(function() {
                    if (typeof (vm.vacature) != "undefined") {
                        vm.tags = data;
                        $interval.cancel(cancelTagesInterval);
                    }
                }, 1000);                
            });

        vm.getCurrentUserBranches();

        // load cities
        $http.get(enumApp.url.draftUrl + 'vacature/fmsCities')
            .then(function (rslt) {
                $rootScope.$broadcast('fmsLocationsFetched', rslt.data);
            });
        $rootScope.$on('fmsLocationsFetched', function (event, data) {
            vm.fmsLocations = data;
        }, true);

        function bindPublicationData() {
            vm.publicatieData.isOffline = vm.vacature.isOffline;
            vm.publicatieData.selectedBranch = vm.vacature.jobBranch;
            vm.publicatieData.publicatieTitle = vm.vacature.fmsVacature.jobTitle;
            vm.publicatieData.publicatieOrganisatie = vm.vacature.fmsVacature.organisatieOmschrijving.content;
            vm.publicatieData.publicatieFunctie = vm.vacature.fmsVacature.functieOmschrijving.content;
            vm.publicatieData.publicatieOns = vm.vacature.fmsVacature.onsAanbod.content;
            vm.publicatieData.weAsk = vm.vacature.fmsVacature.wijVragen.content;
            // kenmerken tab
            vm.publicatieData.jobCity = vm.vacature.vacatureExtras.job_working_address_city;
            vm.publicatieData.jobCountry = vm.vacature.fmsVacature.jobCountry;
            vm.publicatieData.jobProvince = vm.vacature.fmsVacature.jobProvince;
            vm.publicatieData.jobContactAddress = vm.vacature.fmsVacature.jobContactAddress;
            vm.publicatieData.jobContactPostalCode = vm.vacature.fmsVacature.jobContactPostalCode;
            vm.publicatieData.jobContactCity = vm.vacature.fmsVacature.jobContactCity;
            vm.publicatieData.vacancyLanguage = vm.vacature.fmsVacature.vacancyLanguage;
            vm.publicatieData.hoursPerWeek = vm.vacature.vacatureExtras.job_aantal;
            vm.publicatieData.jobZipCode = vm.vacature.vacatureExtras.job_working_address_postal_code_alpha;
            vm.publicatieData.salaryPerMonth = vm.vacature.vacatureExtras.job_month_salary_original;
            vm.publicatieData.jobCcoName = vm.vacature.vacatureExtras.job_cco_name;
            //vm.publicatieData.jobWorkingAddressCity = vm.vacature.vacatureExtras.job_working_address_city;
            vm.publicatieData.jobContactName = vm.vacature.vacatureExtras.job_contact_name;
            vm.publicatieData.jobContactEmail = vm.vacature.vacatureExtras.job_contact_email;
            vm.publicatieData.jobContactPhone = vm.vacature.vacatureExtras.job_contact_phone;
            vm.publicatieData.tags.jobBusiness = vm.vacature.fmsVacature.tagsList.jobBusiness;
            vm.publicatieData.tags.jobContract = vm.vacature.fmsVacature.tagsList.jobContract;
            vm.publicatieData.tags.jobMonthSalary = vm.vacature.fmsVacature.tagsList.jobMonthSalary;
            vm.publicatieData.tags.jobWorkLevel = vm.vacature.fmsVacature.tagsList.jobWorkLevel;
            vm.publicatieData.tags.jobLdcFunction = vm.vacature.fmsVacature.tagsList.jobLdcFunction;
            vm.publicatieData.tags.jobFulltime = vm.vacature.fmsVacature.tagsList.jobFulltime;
            vm.publicatieData.tags.jobVakgebied = vm.vacature.fmsVacature.tagsList.jobVakgebied;
            vm.publicatieData.tags.jobHoursPerWeek = vm.vacature.fmsVacature.tagsList.jobHoursPerWeek;
            vm.publicatieData.tags.jobProperties = vm.vacature.fmsVacature.tagsList.jobProperties;
            vm.publicatieData.tags.jobFunctionLevel = vm.vacature.fmsVacature.tagsList.jobFunctionLevel;
            vm.publicatieData.tags.jobLanguage = vm.vacature.fmsVacature.tagsList.jobLanguage;
            vm.publicatieData.tags.jobSalaryPeriod = vm.vacature.fmsVacature.tagsJobSalaryPeriod;
            vm.publicatieData.tags.jobExperience = vm.vacature.fmsVacature.tagsJobExperience;

            var cancelResourceInterval = $interval(function () {
                if (typeof ($scope.appResources.LblJobTitle) != "undefined") {
                    vm.checkValidVacature();
                    draftAppService.initPopover('.btn-popup');
                    $interval.cancel(cancelResourceInterval);
                }
            }, 500);
        }

        function save() {
            // prevent saving data if there are required fields not filled yet
            vm.checkValidVacature();
            if (!vm.validationObj.isValidPub) {
                return false;
            }

            $http({
                url: enumApp.url.draftUrl + 'vacature/edit/' + vm.vacature.fmsId,
                method: "POST",
                data: { vacatureDto: vm.vacature, publicationDto: vm.publicatieData }
                })
            .success(function (data) {
                // redirect to that fms
                $state.go('mijnPublicaties.vacature', { fmsId: vm.vacature.fmsId });
            })
            .error(function (data, status) {
                alert('error: ' + status + ' | ' + data);
            });
        };

        function getCurrentUserBranches() {
            var deferred = $q.defer();
            if (vm.branches.length) {
                deferred.resolve(vm.branches);
                return deferred.promise;
            }

            $http({
                url: enumApp.url.draftUrl + '/vacture/userBranches',
                method: "GET"
            })
            .success(function (data) {
                vm.branches = data;
                deferred.resolve(data);
            })
            .error(function () {
                deferred.reject("Failed to get all user's branches");
            });

            return deferred.promise;
        }

        function checkValidVacature() {
            vm.validationObj.isValidPub = true;
            vm.validationObj.message = null;
            var isValidPub = true;
            var oneValueRequiredFor = "";
            var requiredValues = "";

            if (vm.publicatieData.publicatieTitle == null || vm.publicatieData.publicatieTitle == '') {
                requiredValues += " <li>" + $scope.appResources.LblJobTitle + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.publicatieOrganisatie == null || vm.publicatieData.publicatieOrganisatie == '') {
                requiredValues += " <li>" + $scope.appResources.LblOrganizationDescription + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.publicatieFunctie == null || vm.publicatieData.publicatieFunctie == '') {
                requiredValues += " <li>" + $scope.appResources.LblJobDescription + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.publicatieOns == null || vm.publicatieData.publicatieOns == '') {
                requiredValues += " <li>" + $scope.appResources.LblOurOffer + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.weAsk == null || vm.publicatieData.weAsk == '') {
                requiredValues += " <li>" + $scope.appResources.LblWeAsk + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.jobCountry == null || vm.publicatieData.jobCountry.length < 1) {
                oneValueRequiredFor += " <li>" + $scope.appResources.LblJobCountry + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.jobCity == null || vm.publicatieData.jobCity == '') {
                requiredValues += " <li>" + $scope.appResources.LblJobLocation + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.jobZipCode == null || vm.publicatieData.jobZipCode == '') {
                requiredValues += " <li>" + $scope.appResources.LblJobZipCode + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.tags.jobBusiness == null || vm.publicatieData.tags.jobBusiness.length < 1) {
                oneValueRequiredFor += " <li>" + $scope.appResources.LblBranch + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.hoursPerWeek == null || vm.publicatieData.hoursPerWeek == '') {
                requiredValues += " <li>" + $scope.appResources.LblNumberOfHours + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.salaryPerMonth == null || vm.publicatieData.salaryPerMonth == '') {
                requiredValues += " <li>" + $scope.appResources.LblSalaryPerMonth + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.tags.jobLdcFunction == null || vm.publicatieData.tags.jobLdcFunction.length < 1) {
                oneValueRequiredFor += " <li>" + $scope.appResources.LblFunction + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.tags.jobFulltime == null || vm.publicatieData.tags.jobFulltime.length < 1) {
                oneValueRequiredFor += " <li>" + $scope.appResources.LblFullTime_PartTime + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.tags.jobVakgebied == null || vm.publicatieData.tags.jobVakgebied.length < 1) {
                oneValueRequiredFor += " <li>" + $scope.appResources.LblFieldOfStudy + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.vacancyLanguage == null || vm.publicatieData.vacancyLanguage == '') {
                requiredValues += " <li>" + $scope.appResources.LblVacancyLanguage + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.tags.jobFunctionLevel == null || vm.publicatieData.tags.jobFunctionLevel.length < 1) {
                oneValueRequiredFor += " <li>" + $scope.appResources.LblEducationLevel + "</li>";
                isValidPub = false;
            }

            if (oneValueRequiredFor != "" || requiredValues != "") {
                vm.validationObj.isValidPub = isValidPub;
                if (oneValueRequiredFor != "") {
                    oneValueRequiredFor = oneValueRequiredFor.substr(1);
                    oneValueRequiredFor += " vereist minstens 1 waarde";
                }
                if (requiredValues != "") {
                    requiredValues = requiredValues.substr(1);
                    requiredValues += " Is benodigd";
                }
                if (oneValueRequiredFor != "" || requiredValues != "") {
                    vm.validationObj.message = "<ul class='padding left--2x'>" + oneValueRequiredFor + requiredValues + "</ul>";
                } else {
                    vm.validationObj.message = oneValueRequiredFor + requiredValues;
                }
            }
        }
    }
})();
