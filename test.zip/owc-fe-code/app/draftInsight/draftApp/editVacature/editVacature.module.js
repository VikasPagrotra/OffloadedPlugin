﻿(function () {
    'use strict';
    angular.module('editVacature.module', []);
})();
