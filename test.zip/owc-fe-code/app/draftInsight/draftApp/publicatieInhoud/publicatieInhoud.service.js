(function(){
	'use strict';

	angular.module('publicatieInhoud.module')
		.service('publicatieInhoudService', publicatieInhoudService);

	publicatieInhoudService.$inject = [];

	function publicatieInhoudService(){
		var service,

			publicatieInhoundDataPs = [],
			publicatieInhoundDataCs = []

		service = {
			publicatieInhoundDataPs: publicatieInhoundDataPs,
			publicatieInhoundDataCs: publicatieInhoundDataCs,
			checkValidConcept : checkValidConcept
		}

		return service;
	}

	function checkValidConcept(publicatie,vacature) {
	    var isValidPub = true;
	    var oneValueRequredFor = "";
	    var requiredValues = "";
	    var scoreMessage = "";

	    var validationObj = {
	        "isValidPub": isValidPub,
	        "circle": publicatie.publicatieCircle
	    };

	    if (publicatie.tags.jobBusiness == null || publicatie.tags.jobBusiness.length < 1) {
	        oneValueRequredFor += " <li>Branche</li>";
	        isValidPub = false;
	    }
	    // not needed any more
	    //if (publicatie.tags.jobContract == null || publicatie.tags.jobContract.length < 1) {
	    //    oneValueRequredFor += " <li>Job contract</li>";
	    //    isValidPub = false;
	    //}
	    if (publicatie.tags.jobFulltime == null || publicatie.tags.jobFulltime.length < 1) {
	        oneValueRequredFor += " <li>Fulltime / parttime</li>";
	        isValidPub = false;
	    }
	    if (publicatie.tags.jobLdcFunction == null || publicatie.tags.jobLdcFunction.length < 1) {
	        oneValueRequredFor += " <li>Functies</li>";
	        isValidPub = false;
	    }
	    if (publicatie.tags.jobVakgebied == null || publicatie.tags.jobVakgebied.length < 1) {
	        oneValueRequredFor += " <li>Vakgebied</li>";
	        isValidPub = false;
	    }
	    if (publicatie.tags.jobWorkLevel == null || publicatie.tags.jobWorkLevel.length < 1) {
	        oneValueRequredFor += " <li>Werk-/ denkniveau</li>";
	        isValidPub = false;
	    }
	    if (publicatie.publicatieOns == null || publicatie.publicatieOns == '') {
	        requiredValues += " <li>Ons aanbod</li>";
	        isValidPub = false;
	    }
	    if (vacature.vacatureExtras.job_fms_id == null || vacature.vacatureExtras.job_fms_id == '') {
	        requiredValues += " <li>Job FmsId</li>";
	        isValidPub = false;
	    }
	    if (vacature.vacatureExtras.job_landcode == null || vacature.vacatureExtras.job_landcode == '') {
	        requiredValues += " <li>Land code</li>";
	        isValidPub = false;
	    }
	    if (vacature.vacatureExtras.job_working_address_postal_code == null || vacature.vacatureExtras.job_working_address_postal_code == '') {
	        requiredValues += " <li>working address postal code</li>";
	        isValidPub = false;
	    }
	    // disabled as per comment from Rob, not required this to publication for a concept
	    //if (vm.vacature.instroom.channels == null || vm.vacature.instroom.channels.length < 1) {
	    //    requiredValues += " <li>Kanalenmix</li>";
	    //    isValidPub = false;
	    //}
	    if (vacature.vacatureExtras.job_working_address_postal_code_alpha == null || vacature.vacatureExtras.job_working_address_postal_code_alpha == '') {
	        requiredValues += " <li>working address postal code alpha</li>";
	        isValidPub = false;
	    }
	    if (publicatie.publicatieTitle == null || publicatie.publicatieTitle == '') {
	        requiredValues += " <li>Publicatie titel</li>";
	        isValidPub = false;
	    }
	    if (publicatie.publicatieOrganisatie == null || publicatie.publicatieOrganisatie == '') {
	        requiredValues += " <li>Organisatie-omschrijving</li>";
	        isValidPub = false;
	    }
	    if (publicatie.publicatieFunctie == null || publicatie.publicatieFunctie == '') {
	        requiredValues += " <li>Functie-omschrijving</li>";
	        isValidPub = false;
	    }
	    if (publicatie.jobCity == null || publicatie.jobCity == '') {
	        requiredValues += " <li>Plaats</li>";
	        isValidPub = false;
	    }
	    if (publicatie.weAsk == null || publicatie.weAsk == '') {
	        requiredValues += " <li>Wij vragen</li>";
	        isValidPub = false;
	    }
	    if (publicatie.hoursPerWeek == null || publicatie.hoursPerWeek < 0) {
	        requiredValues += " <li>Aantal uur</li>";
	        isValidPub = false;
	    }
	    if (publicatie.salaryPerMonth == null || publicatie.salaryPerMonth < 0) {
	        requiredValues += " <li>Salaris per maand</li>";
	        isValidPub = false;
	    }

	    if (publicatie.publicatieScore < 70) {
	        if (!isValidPub) {
	            scoreMessage = "Om te kunnen publiceren heeft het concept een minimale score nodig van 70. Pas de adviezen toe op jouw vacature zodat de score voldoende is om te publiceren. <br /><br />Niet alle verplichte velden of onderdelen zijn ingevuld. Controleer onderstaande velden of onderdelen en zorg dat deze ingevuld zijn om te kunnen publiceren: ";
	        } else {
	            scoreMessage = "Om te kunnen publiceren heeft het concept een minimale score nodig van 70. Pas de adviezen toe op dit concept, zodat de score voldoende is om te publiceren.";
	        }
	        isValidPub = false;
	    } else if (publicatie.publicatieScore >= 70) {
	        scoreMessage = "Niet alle verplichte velden of onderdelen zijn ingevuld. Controleer onderstaande velden of onderdelen en zorg dat deze ingevuld zijn om te kunnen publiceren: \n";
	    }

	    if (oneValueRequredFor != "" || requiredValues != "" || scoreMessage != "") {
	        //if (oneValueRequredFor != "") {
	        //    oneValueRequredFor = oneValueRequredFor.substr(1);
	        //    oneValueRequredFor += " vereist minstens 1 waarde";
	        //}
	        //if (requiredValues != "") {
	        //    requiredValues = requiredValues.substr(1);
	        //    requiredValues += " Is benodigd";
	        //}
	        validationObj.isValidPub = isValidPub;
	        if (oneValueRequredFor != "" || requiredValues != "") {
	            validationObj.message = scoreMessage + "<ul class='padding left--2x'>" + oneValueRequredFor + requiredValues + "</ul>";
	        } else {
	            validationObj.message = scoreMessage + oneValueRequredFor + requiredValues;
	        }
	    }

	    return validationObj;
	}
})();
