(function(){
	'use strict';

	angular.module('publicatieInhoud.module', []);
})();