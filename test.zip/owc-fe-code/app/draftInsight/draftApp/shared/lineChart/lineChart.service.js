(function () {
    'use strict';

    angular.module('lineChart.module')
        .service('lineChartService', lineChartService);

    lineChartService.$inject = [];

    function lineChartService() {
        var vm = this, service;

        vm.chartOptions = {
            options: {
                'title': '',
                'titleTextStyle': {
                    'fontSize': 20
                },
                'hAxis': {
                    'title': '',
                    'textStyle': {
                        'fontSize': 10
                    }
                },
                'vAxis': {
                    'title': '',
                    'textStyle': {
                        'fontSize': 10
                    }
                },
                'stroke-width': 2,
                'width': '1000',
                'height': '500',
                'pointSize': 4,
                'series': {
                    0: {
                        'lineWidth': 0,
                        'pointShape': 'triangle',
                        'pointSize': 6
                    },
                    2: {
                        'lineWidth': 0,
                        'pointShape': 'square',
                        'pointSize': 6
                    },
                    3: {
                        'lineWidth': 2,
                        'pointSize': 0
                    }
                }
            },
            arrData: []
        }

        service = {
            prepareChartOptions: prepareChartOptions,
            createChart: createChart,
            createChartAndTable: createChartAndTable
        }

        return service;

        function prepareChartOptions(data) {
            if (typeof data === 'undefined')
                return false;

            vm.chartOptions.options.title = data.chartTitle;
            vm.chartOptions.options.vAxis.title = data.hAxisTitle;
            vm.chartOptions.options.hAxis.title = data.vAxisTitle;
            vm.chartOptions.arrData = data.chartData.arrData;
            return data.legends;
        }

        function createChart(legends) {
            if (typeof data === 'legends')
                return false;

            var data, chart;
            data = new google.visualization.DataTable();
            legends.forEach(function (value) {
                data.addColumn(value.dataType, value.title);
            });
            data.addRows(vm.chartOptions.arrData);
            chart = new google.visualization.LineChart(document.getElementById('chartdiv')); // Table
            chart.draw(data, vm.chartOptions.options); // {showRowNumber: true, width: '100%', height: '100%'}
        }

        function parseDate(str) {
            if (!/^(\d){8}$/.test(str)) return false;
            var y = str.substr(0, 4),
                m = str.substr(4, 2) - 1,
                d = str.substr(6, 2);
            return new Date(y, m, d);
        }

        function createChartAndTable(jsonData, period, opts) {
            opts = opts || {};
            var divId = opts.divId || 'chartdivActueel';
            var width = opts.width || $("body").width();
            var height = opts.height || 500;
            var compare = opts.compare;
            var colors = opts.colors || [];

            var data, chart, dateIndex = -1, ctrl = 0;
            data = new google.visualization.DataTable();

            var groups = [];

            jsonData.chartLegends.forEach(function (value, index) {
                if (index === 1) {
                    value.title = value.exactTitle || "Paginaweergaven";
                }
                else if (index === 2) {
                    value.title = value.exactTitle || "Sollicitaties";
                }

                // for other chart types, week, maand, etc
                if (index > 0) {
                    groups.push({
                        column: index,
                        label: value.title,
                        aggregation: google.visualization.data.sum,
                        type: 'number'
                    });
                }

                if (value.dataType.toLowerCase() == "date") {
                    dateIndex = ctrl;
                }
                ctrl++;
                data.addColumn(value.dataType, value.title);
            });

            var chartArray = [];

            for (var i = 0; i < jsonData.chartData.arrData.length; i++) {
                var columnData = [];
                ctrl = 0;
                for (var prop in jsonData.chartData.arrData[i]) {
                    var dateFormated = parseDate(jsonData.chartData.arrData[i][prop]);
                    if (dateFormated && ctrl == dateIndex) {
                        columnData.push(dateFormated);
                    } else {
                        columnData.push(jsonData.chartData.arrData[i][prop]);
                    }
                    ctrl++;
                }
                chartArray.push(columnData);
            }
            chartArray.sort(function (a, b) {
                return a[0] > b[0] ? 1 : -1;
            });
            jsonData.chartData.arrData = chartArray;
            data.addRows(jsonData.chartData.arrData);

            var options = {
                hAxis: {
                    //title: 'Date',
                    format: 'dd MMM',
                    gridlines: {
                        color: 'transparent'
                    }
                },
                //isStacked: true,
                vAxes: {
                    1: { maxValue: 4 } // format:"#'%'",
                },
                tooltip: { isHtml: true },
                legend: { position: 'top', alignment: 'start' },
                chartArea: { width: width * .618, height: height - 100 },
                pointSize: 10,
                'stroke-width': 2,
                width: width * .71,
                height: height,
                series: {
                    0: { targetAxisIndex: 0, color: colors.length == 0 ? "#A7DFF1" : colors[0] },
                    1: { targetAxisIndex: compare ? 0 : 1, type: 'line', color: colors.length == 0 ? "#008EC2" : colors[1] }
                }
            };

            chart = new google.visualization.AreaChart(document.getElementById(divId));

            var recentmonths = [];
            function getMonth(someDate) {
                var dateByMonth = new Date(someDate.getFullYear(), someDate.getMonth(), 1);
                recentmonths.push(dateByMonth);
                return dateByMonth;
            }

            function getWeek(d) {
                d = new Date(d);
                var day = d.getDay(),
                    diff = d.getDate() - day + (day == 0 ? -6 : 1); // adjust when day is sunday
                var date = new Date(d.setDate(diff));
                date.setHours(0, 0, 0);
                return date;
            }

            google.visualization.events.addListener(chart, 'onmouseover', eventHandler);
            var result;
            switch (period) {
                case 'Dag':
                    result = data;
                    break;
                case 'Week':
                    options.hAxis.format = "dd MMM";
                    result = google.visualization.data.group(
                        data,
                        [{
                            column: 0,
                            label: 'Date',
                            modifier: getWeek,
                            type: 'date'
                        }],
                        groups);
                    break;
                case 'Maand':
                    //get chart data by month
                    result = google.visualization.data.group(
                        data,
                        [{
                            column: 0,
                            label: 'Date',
                            modifier: getMonth,
                            type: 'date'
                        }],
                        groups);

                    //set chart options
                    var maxDate = new Date(Math.max.apply(null, recentmonths));
                    var minDate = new Date(Math.min.apply(null, recentmonths));

                    options.hAxis.format = "MMM yyyy";
                    options.hAxis.viewWindow = { min: new Date(minDate.setMonth(minDate.getMonth() - 1)), max: new Date(maxDate.setMonth(maxDate.getMonth() + 1)) };
                    break;
                default:
                    // if no period sent
                    result = data;
                    break;
            }

            //chart.draw(result, options);

            var sliceid = 0;

            function eventHandler(e) {
                chart.setSelection([e]);
                try {
                    sliceid = e.row;
                    chart.getSelection();
                }
                catch (err) {

                }
                $(".google-visualization-tooltip").css({"min-width": "170px"});
                var days = ['zondag', 'maandag', 'dinsdag', 'woensdag', 'donderdag', 'vrijdag', 'zaterdag'];
                //var months = ["Jan", "Feb", "Mrt", "Apr", "Mei", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"];

                var day = "";
                //var test = jsonData.chartData.arrData[sliceid];
                var node = result['Nf'][sliceid];
                if (node) {
                    var dt = $(".google-visualization-tooltip-item-list li:eq(0)").text().replace(",", "").split(' ');
                    day = days[node['c'][0]['v'].getDay()] + " " + dt[1] + " " + dt[0] + ", " + dt[2];

                    $(".google-visualization-tooltip-item-list li:eq(0)").html(day).css("font-weight", "bold").css("font-size", "12px");
                    $(".google-visualization-tooltip-item-list li:eq(1)").html(createHtml(node)).css("font-family", "Arial");
                }
                //var month = months[ new Date().getMonth() ];
            }

            function createHtml(_node) {
                //var test = jsonData.chartData.arrData[_sliceid];
                if (_node) {
                    var html = "";
                    var title = '';
                    var colors1 = colors.length == 0 ? '#A7DFF1' : colors[0];
                    var colors2 = colors.length == 0 ? '#008EC2' : colors[1];
                    if (_node['c'][1]) {
                        title = 'Paginaweergaven';
                        if (jsonData.chartLegends[1] && jsonData.chartLegends[1].title) {
                            title = jsonData.chartLegends[1].title;
                        }
                        html += "<label style='width: 8px;height: 8px;background: " + colors1 + "'></label><label style='margin-top: -3px; position: absolute; font-family: Arial; font-size: 10px;'>&nbsp;" + title + ": " + _node['c'][1]['v'] + "</label>";
                    }
                    if (_node['c'][2]) {
                        title = 'Sollicitaties';
                        if (jsonData.chartLegends[2] && jsonData.chartLegends[2].title) {
                            title = jsonData.chartLegends[2].title;
                        }
                        html += "<br><label style='width: 8px;height: 8px;background: " + colors2 + "'></label><label style='margin-top: -3px; position: absolute; font-family: Arial; font-size: 10px;'>&nbsp;" + title + ": " + _node['c'][2]['v'] + "</label>";
                    }
                    return html;
                }
                return "";
            }

            chart.draw(result, options);
        }
    }
})();
