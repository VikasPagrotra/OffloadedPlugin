(function(){
	'use strict';

	angular.module('lineChart.module', []);
})();