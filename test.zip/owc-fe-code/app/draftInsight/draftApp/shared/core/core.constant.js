(function(){
	'use strict',
	angular.module('core.module')
	.constant('enumApp', {
		'mapsEnabled' : true,
		'url' : {
			//'analyzerUrl' : 'http://localhost:54290/api/',
			'analyzerUrl' : 'http://olympia-jobapplicationprediction-api-test.azurewebsites.net/api/',
		    //'analyzerUrl': 'http://olympia-jobapplicationprediction-api-staging.azurewebsites.net/api/',
		 },
 		'randomMessage' : []
	});

})();
