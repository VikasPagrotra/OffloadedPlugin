(function(){
	'use strict';
	angular.module('core.module', ['ngSanitize'])
})();
