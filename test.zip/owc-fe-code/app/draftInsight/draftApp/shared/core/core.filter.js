(function(){
	'use strict';
	angular.module('core.module')
	    .filter('eurocurrency', function () {
	        return function (input, withoutDecimal) {
	            input = input || '';
	            var out = '';

	            if (withoutDecimal == 'uurs') {
	                out = parseInt(parseFloat(Math.round(input * 100) / 100).toFixed(0));
	                out = out.toLocaleString('de-DE');

	                return out;
	            }

	            if (withoutDecimal) {
	                out = parseInt(parseFloat(Math.round(input * 100) / 100).toFixed(0));
	                out = out.toLocaleString('de-DE') + ',-';
	            } else {
	                out = parseFloat(Math.round(input * 100) / 100).toFixed(2).replace('.', ',');
	            }

	            return out;
	        };
	    })
        .filter('limitHtml', function () {
            return function (text, limit) {

                var changedString = String(text).replace(/<[^>][br]>/gm, ' ').replace(/<[^>]+>/gm, '').replace(/\s\s+/g, ' ');
                var length = changedString.length;

                return changedString.length > limit ? changedString.substr(0, limit - 1) + '...' : changedString;
            }
        })
	    .filter('replaceRegex', function () {
	        return function (text) {

	            var changedString = String(text).replace(/\(\u20ac\d+\)/g, "");

	            return changedString;
	        }
	    }).filter('extractNumber', function () {
	        return function (text) {

	            return String(text).replace(/[a-zA-Z]/g, "");
	        }
        })
        .filter('conceptDescriptionFormat', function () {
            return function (str) {

                var tagFreeString = str.replace(/</g, '&#60;').replace(/>/g, '&#62;');
                if (str.indexOf("\n") >= 0) {
                    var descriptionText = tagFreeString.split('\n');
                }
                else {
                    var descriptionText = [];
                    descriptionText.push(tagFreeString);
                }
                var resultString = "";
                for (var i = 0; i < descriptionText.length; i++) {
                    if (descriptionText[i].startsWith("-")) {
                        descriptionText[i] = '<li>' + descriptionText[i].replace(/^[-]/gm, '') + '</li>';
                    }
                    else {
                        descriptionText[i] = '<li class="no-list-decoration">' + descriptionText[i] + '</li>';
                    }
                }
                for (var i = 0; i < descriptionText.length; i++) {
                    resultString += descriptionText[i];
                }
                return (resultString);
            }
        });

})();
