(function(){
	'use strict';
    angular.module('core.module')
        .directive('tableSorting', function() {
            var directive = {};

            directive.restrict = 'AE'; /* restrict this directive to elements */

            directive.scope = {
                tableIsNumber: "@tableIsNumber",
                tableColumnSortFirst: "@tableColumnSortFirst"
            }

            directive.compile = compile;

            return directive;

            function compile(element, attributes) {
                // do one-time configuration of element.
                var sortTable = function sortTable(f, n, isNumber, elem) {
                    var rows = elem.find('tbody tr').get();

                    rows.sort(function(a, b) {

                        var A = isNumber ? parseFloat($(a).children('td').eq(n).text()) : $(a).children('td').eq(n).text().toUpperCase();
                        var B = isNumber ? parseFloat($(b).children('td').eq(n).text()) : $(b).children('td').eq(n).text().toUpperCase();

                        if (A < B) {
                            return -1 * f;
                        }
                        if (A > B) {
                            return 1 * f;
                        }
                        return 0;
                    });

                    $.each(rows, function(index, row) {
                        elem.find('tbody').append(row);
                    });
                };

                var headSort = function headSort(obj, tableId, fValue) {
                    removeSortingClasses(tableId)
                    if (fValue == 1) {
                        obj.addClass('headSortDesc');
                    } else if (fValue == -1) {
                        obj.addClass('headSortAsc');
                    }
                };

                var removeSortingClasses = function removeSortingClasses(tableId) {
                    tableId.find("thead:first-child th").each(function() {
                        $(this).removeClass('headSortAsc').removeClass('headSortDesc');
                    })
                };

                var linkFunction = function linkFunction($scope, element, atttributes) {
                    var thsParentThead = element.children('thead').first();
                    var allThs = thsParentThead.find('th');
                    var f = [];
                    if (tableIsNumber != '') {
                        var tableIsNumber = atttributes.tableIsNumber.split('');
                    } else {
                        console.log('error check string is null - not able to check which column is string or number')
                    }
                    var tableDefaultSorting = atttributes.tableColumnSortFirst;

                    //add id's and sorting class
                    allThs.each(function(index) {
                        $(this).attr('id', 'th' + (index + 1));
                        $(this).addClass('headingSort');
                        if (tableDefaultSorting == (index + 1)) {
                            f.push(-1);
                        } else {
                            f.push(1);
                        }

                    })

                    //play with sorting
                    allThs.each(function(i) {
                        element.find("#th" + (i + 1)).click(function() {
                            f[i] *= -1;
                            var n = $(this).prevAll().length;
                            headSort($(this), element, f[i]);
                            if (tableIsNumber[i] == 0) {
                                sortTable(f[i], n, false, element);
                            } else {
                                sortTable(f[i], n, true, element);
                            }
                        });
                    })
                    //sort the default column
                    atttributes.$observe('tabledata', function(value) {
                        headSort(element.find("#th" + tableDefaultSorting), element, f[tableDefaultSorting - 1]);
                        if (tableIsNumber[tableDefaultSorting - 1] == 0) {
                            sortTable(f[tableDefaultSorting - 1], tableDefaultSorting - 1, false, element);
                        } else {
                            sortTable(f[tableDefaultSorting - 1], tableDefaultSorting - 1, true, element);
                        }
                    });
                };

                return linkFunction;
            }
        })
        .directive('customDisable', customDisable)
        .directive('toggleLink', toggleLink)
        .directive('highlightKeywords', highlightKeywords)
        .directive('contenteditable', [
            '$sce', function($sce) {
                return {
                    restrict: 'A', // only activate on element attribute
                    require: '?ngModel', // get a hold of NgModelController
                    link: function(scope, element, attrs, ngModel) {
                        if (!ngModel) return; // do nothing if no ng-model

                        // Specify how UI should be updated
                        ngModel.$render = function() {
                            element.html($sce.getTrustedHtml(ngModel.$viewValue || ''));
                        };

                        // Listen for change events to enable binding
                        element.on('blur keyup change', function() {
                            scope.$evalAsync(read);
                        });

                        // Write data to the model
                        function read() {
                            var html = element.html();
                            // When we clear the content editable the browser leaves a <br> behind
                            // If strip-br attribute is provided then we strip this out
                            if (attrs.stripBr && html == '<br>') {
                                html = '';
                            }
                            ngModel.$setViewValue(html);
                        }
                    }
                };
            }
        ])
        .directive('uiSrefIf', function ($compile) {
            return {
                link: function ($scope, $element, $attrs) {

                    var uiSrefVal = $attrs.uiSrefVal,
                        uiSrefIf = $attrs.uiSrefIf;

                    $element.removeAttr('ui-sref-if');
                    $element.removeAttr('ui-sref-val');
                    $scope.$watch(
                        function () {
                            return $scope.$eval(uiSrefIf);
                        },
                        function (bool) {
                            if (bool) {
                                $element.attr('ui-sref', uiSrefVal);
                            } else {
                                $element.removeAttr('ui-sref');
                                $element.removeAttr('href');
                            }
                            $compile($element)($scope);
                        }
                    );
                }
            };
        })
        .directive('compile', [
            '$compile', function($compile) {
                return function(scope, element, attrs) {
                    scope.$watch(
                        function(scope) {
                            // watch the 'compile' expression for changes
                            return scope.$eval(attrs.compile);
                        },
                        function(value) {
                            // when the 'compile' expression changes
                            // assign it into the current DOM
                            var changedString = String(value).replace(/\(\u20ac\d+\)/g, "");
                            element.html(changedString);

                            // compile the new DOM and link it to the current
                            // scope.
                            // NOTE: we only compile .childNodes so that
                            // we don't get into infinite loop compiling ourselves
                            $compile(element.contents())(scope);
                        }
                    );
                };
            }
        ]);

		customDisable.$inject = [];

		function customDisable(){
			var directive;

			directive = {
				restrict : 'A',
				scope : {
					customDisable : '='
				},
				link : linkFunction
			}

			return directive;

			///////////////////////////////////////

			function linkFunction(scope, element, attrs){
				var anchor = element.find('a');

				anchor.on('click', anchorClickHandler);

				function anchorClickHandler(event){
					if(scope.customDisable){
						event.preventDefault();
					}
				}
			}
		}

		toggleLink.$inject = [];

		function toggleLink(){
			var directive;

			directive = {
				restrict : 'C',
				scope : {
				},
				link : linkFunction
			}

			return directive;

			///////////////////////////////////////

			function linkFunction(scope, element, attrs){
				element.on('click', clickHandler);

				function clickHandler(event){
					element.prev().toggle("");
					element.parent().toggleClass("widget-column-bg");
					element.toggleClass("up-arrow");
					if (element.hasClass("up-arrow")) {
					    element.text('Verberg uitleg');
					} else if (element.hasClass("right-arrow") && element.hasClass("toggle-red")) {
					    element.text('Laat zien hoe je dit kunt verbeteren');
					} else {
					    element.text('Laat zien hoe je dit bereikt hebt');
					}
				}
			}
		}

		highlightKeywords.$inject = ['$timeout'];

		function highlightKeywords($timeout) {
		    var directive;

		    directive = {
		        restrict: 'AE',
		        scope: {
		        },
		        link: linkFunction
		    }

		    return directive;

		    ///////////////////////////////////////

		    function linkFunction(scope, element, attrs) {
		        element.on('blur', keyupHandler);

		        $timeout(function () {
		            element.trigger('blur', keyupHandler);
		        })
		        function keyupHandler(event) {
		            var groupOfEl = angular.element(this).closest('.stretched-out').find('.form-control')
		            var groupOfText = "";
		            angular.forEach(groupOfEl, function (it) {
		                groupOfText += it.value + " ";
		            });

		            var listOfKeywords = angular.element(document.querySelectorAll('.textKeywords'));
		            var listOfMatchedWords = [];
		            angular.forEach(listOfKeywords, function (item) {
		                var value = item.innerHTML.toLowerCase();
		                var self = angular.element(item);
		                self.removeClass('excellent');
		                var regex = new RegExp("\\b(" + value + ")\\b");
		                if (regex.test(groupOfText.toLowerCase())) {
                            listOfMatchedWords.push(value);
		                }
		            });
		            
		            angular.forEach(listOfKeywords, function (item) {
		                var value = item.innerHTML;
		                var self = angular.element(item);
		                angular.forEach(listOfMatchedWords, function (i) {
		                    if (i.localeCompare(value.toLowerCase()) == 0) {
		                        $timeout(function() {
		                            self.addClass('excellent');
		                        });
		                    }
		                });
		            });
		        }

		    }
		}

})();
