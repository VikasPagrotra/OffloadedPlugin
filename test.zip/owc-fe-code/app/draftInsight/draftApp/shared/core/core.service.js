(function () {
    'use strict',
	angular.module('core.module')
	.service('coreService', coreService);

    coreService.$inject = ['enumApp', '$timeout', 'draftAppService'];

    function coreService(enumApp, $timeout, draftAppService) {
        vm = this;

        this.isMapsEnabled = isMapsEnabled;
        this.getRandomMessage = getRandomMessage;
        this.showalertMessage = showalertMessage;
        this.randomMessage = [
            {
                'message': 'Dat de titel van een vacature de meeste impact heeft op hoeveel kandidaten de vacature zien.',
                'link': 'http://ignite.online'
            }
        ];
        this.activate = activate;

        activate();

        function activate() {
            draftAppService.getSettings().then(resolveSettings);
        };

        function resolveSettings(data) {
            vm.randomMessage = data.RandomMessages;
            draftAppService.randomMessage = data.RandomMessages;
        }

        function isMapsEnabled() {
            return enumApp.mapsEnabled;
        }

        function getRandomMessage() {
            if (typeof vm.randomMessage === 'undefined') {
                vm.randomMessage = draftAppService.randomMessage;
            }
            var num = Math.floor(vm.randomMessage.length * Math.random());
            return vm.randomMessage[num];
        }

        function showalertMessage(id) {
            var id = $('#' + id);
            id.removeClass('hidden');

            $timeout(function() {
                id.addClass('hidden');
            }, 10000);
        }

    }
})();
