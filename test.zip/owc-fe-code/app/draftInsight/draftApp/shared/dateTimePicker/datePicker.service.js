(function(){
	'use strict';
	angular.module('dateTimePicker.module')
		.service('dateTimePickerService', dateTimePickerService);

	dateTimePickerService.$inject = ['$http', '$q'];

	function dateTimePickerService($http, $q){
		var service;

	}
})();
