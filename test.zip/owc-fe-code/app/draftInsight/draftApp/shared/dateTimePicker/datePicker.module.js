(function(){
	'use strict';
	angular.module('dateTimePicker.module', []);
})();
