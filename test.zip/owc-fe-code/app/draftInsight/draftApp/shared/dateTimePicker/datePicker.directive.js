(function () {
    'use strict';
    angular.module('dateTimePicker.module')
        .directive('dateTimePicker', dateTimePicker);

    dateTimePicker.$inject = ['dateTimePickerService', '$timeout'];

    function dateTimePicker(dateTimePickerService, $timeout) {
        var directive;

        directive = {
            require: '?ngModel',
            restrict: 'AE',
            scope: {
                initDataWith: '@initDataWith',
                defaultDate: '@defaultDate',
                model: '=ngModel'
            },
            compile: compileFuction
        };

        return directive;

        ///////////////////////////////////////

        //compile is called during application initialization. AngularJS calls it once when html page is loaded.
        function compileFuction(element, attributes) {

            //linkFunction is linked with each element with scope to get the element specific data.
            var linkFunction = linkFunction;

            return linkFunction;

            ////////////////////////

            function linkFunction(scope, element, attributes, ngModel) {
                if (!ngModel) return; // do nothing if no ng-model

                var _this = angular.element(element),
                    datevalue = moment(new Date());
                ngModel.$render = function () {
                    element.find('input').val(ngModel.$viewValue || '');
                };

                if (angular.isDefined(scope.defaultDate)) {
                    if (scope.defaultDate !== '')
                        datevalue = moment().add(scope.defaultDate, 'days');
                }

                if (angular.isDefined(scope.initDataWith) && scope.initDataWith != '' && scope.initDataWith !== 'current') {
                    datevalue = moment(scope.initDataWith, 'DD/MM/YYYY');
                }

                _this.datetimepicker({
                    format: 'DD/MM/YYYY',
                    defaultDate: datevalue
                });

                if (ngModel.$viewValue == null || isNaN(ngModel.$viewValue)) {
                    ngModel.$setViewValue(element.val());
                }

                _this.on('dp.change', function (e) {
                    if (ngModel) {
                        $timeout(function () {
                            ngModel.$setViewValue(e.target.value);
                        });
                    }
                });

                scope.$watch('model', function (newValue, oldvalue) {
                    if (newValue != oldvalue) {
                        element.context.value = newValue;
                    }
                });

                _this.next().on('click', function (e) {
                    _this.data('DateTimePicker').show();
                });
            }
        }
    }
})();
