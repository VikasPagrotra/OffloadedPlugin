(function(){
	'use strict';
	angular.module('dateRange.module')
		.service('dateRangeService', dateRangeService);

	dateRangeService.$inject = ['$http', '$q', 'enumApp'];

	function dateRangeService($http, $q, enumApp){
		var service

		service = {
			getSincePublication : getSincePublication
		}

		return service;

		////////////////////////////////////////
        // not used now as we have enough info
		function getSincePublication(url) {

		    var deffered = $q.defer();
                //url = "https://www.olympia.nl/V-1597463/Productiemedewerker-in-dagdienst";

			$http({
			    url: enumApp.url.draftUrl + 'GeneralJobInfo',
				method : "GET",
				params : {
					URL : url
				}
			})
			.success(function(data){
				deffered.resolve(data);
			})
			.error(function(){
				deffered.reject("Failed to get Since First Publication date range");
			});

			return deffered.promise;
		}
	}
})();
