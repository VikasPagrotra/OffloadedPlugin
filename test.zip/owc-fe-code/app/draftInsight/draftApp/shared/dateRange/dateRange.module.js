(function(){
	'use strict';
	angular.module('dateRange.module', []);
})();