(function () {
    'use strict';
    angular.module('dateRange.module')
        .directive('customDateRange', customDateRange);

    customDateRange.$inject = ['dateRangeService', '$timeout', '$interval'];

    function customDateRange(dateRangeService, $timeout, $interval) {
        var directive;

        directive = {
            restrict: 'AE',
            scope: {
                'selectedRange': '=',
                'publicationDateRange': '='
            },
            compile: compileFuction
            //controller: dateRangeCntl,
            //controllerAs: 'vModel'
            //bindToController : true
        };

        return directive;

        ///////////////////////////////////////

        //compile is called during application initialization. AngularJS calls it once when html page is loaded.
        function compileFuction(element, attributes) {

            //linkFunction is linked with each element with scope to get the element specific data.
            var linkFunction = linkFunction;

            return linkFunction;

            ////////////////////////

            function linkFunction(scope, element, attributes) {
                var publicationDateRange = {};
                var _this = angular.element(element);
                if (scope.publicationDateRange) {
                    publicationDateRange = scope.publicationDateRange;
                    initializePlugin(publicationDateRange);
                } else {
                    scope.$watch('vModel.publicationDateRange', function (newVal, oldVal) {
                        if (typeof newVal !== 'undefined' && newVal) {
                            angular.copy(newVal, publicationDateRange);
                            initializePlugin(publicationDateRange);
                        }
                    }, true);
                }

                /////////////////

                function initializePlugin(publicationRange) {
                    var jobStart = publicationRange.jobStartDate,
                        jobEnd = publicationRange.jobEndDate;

                    _this.daterangepicker({
                        initialText: 'Selecteer periode',
                        presetRanges: [{
                            text: 'Afgelopen 7 dagen', //Last 7 days
                            dateStart: function () {
                                return moment().subtract(7, 'days');
                            },
                            dateEnd: function () {
                                return moment();
                            }
                        }, {
                            text: 'Deze week', //This week, Monday up to present day of the week.
                            dateStart: function () {
                                return moment().startOf('week').add(1, 'days');
                            },
                            dateEnd: function () {
                                return moment();
                            }
                        }, {
                            text: 'Vorige week', //Previous week. So Monday untill Sunday of the previous week
                            dateStart: function () {
                                return moment().subtract(1, 'weeks').startOf('week');
                            },
                            dateEnd: function () {
                                return moment().subtract(1, 'weeks').endOf('week');
                            }
                        }, {
                            text: 'Afgelopen 30 dagen', //Take the last 30 days. Should be the same as the standard view
                            dateStart: function () {
                                return moment().subtract(29, 'days');
                            },
                            dateEnd: function () {
                                return moment();
                            }
                        }, {
                            text: 'Vorige maand',
                            dateStart: function () {
                                return moment().subtract(1, 'months').startOf('month');
                            },
                            dateEnd: function () {
                                return moment().subtract(1, 'months').endOf('month');
                            }
                        }, {
                            text: 'Sinds 1e publicatie',
                            dateStart: function () {
                                return moment(jobStart, "MMDDYYYY");
                            },
                            dateEnd: function () {
                                if (jobEnd > moment()) {
                                    return moment();
                                }
                                return moment(jobEnd, "MMDDYYYY");
                            }
                        }],
                        applyButtonText: "Toepassen",
                        clearButtonText: attributes.clearText,
                        cancelButtonText: "Annuleer",
                        applyOnMenuSelect: false,
                        dateFormat: 'M d, yy',
                        datepickerOptions: {
                            monthNames: ['Januari', 'Februari', 'Maart', 'April', 'Mei', 'Juni', 'Juli', 'Augustus', 'September', 'Oktober', 'November', 'December'],
                            monthNamesShort: [ "Jan", "Feb", "Mrt", "Apr", "Mei", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec" ],
                            dayNamesMin: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"]
                        },
                        onChange: onChangeFunction,
                        onOpen: onOpenFUnction,
                        onClose: removeAllHighlightedDates
                    })

                    // set initial date if exists
                    $timeout(function () {
                        if (attributes.initDateRange > 0) {
                            if (attributes.initStartDate && attributes.initStartDate > 0) {
                                var startDate = moment().subtract(attributes.initStartDate, 'days').toDate();
                                var endDate = moment().subtract(attributes.initStartDate - attributes.initDateRange, 'days').toDate();
                            } else {
                                var startDate = moment().subtract(attributes.initDateRange, 'days').toDate();
                                var endDate = moment().toDate();
                            }
                            element.daterangepicker("setRange", {
                                start: startDate,
                                end: endDate
                            });
                            _this.daterangepicker({
                                //initialText: 'Selecteer periode',
                                presetRanges: [{
                                    text: 'Afgelopen 7 dagen', //Last 7 days
                                    dateStart: function () {
                                        return moment().subtract(7, 'days');
                                    },
                                    dateEnd: function () {
                                        return moment();
                                    }
                                }, {
                                    text: 'Deze week', //This week, Monday up to present day of the week.
                                    dateStart: function () {
                                        return moment().startOf('week').add(1, 'days');
                                    },
                                    dateEnd: function () {
                                        return moment();
                                    }
                                }, {
                                    text: 'Vorige week', //Previous week. So Monday untill Sunday of the previous week
                                    dateStart: function () {
                                        return moment().subtract(1, 'weeks').startOf('week')
                                    },
                                    dateEnd: function () {
                                        return moment().subtract(1, 'weeks').endOf('week')
                                    }
                                }, {
                                    text: 'Afgelopen 30 dagen', //Take the last 30 days. Should be the same as the standard view
                                    dateStart: function () {
                                        return moment().subtract(29, 'days');
                                    },
                                    dateEnd: function () {
                                        return moment();
                                    }
                                }, {
                                    text: 'Vorige maand',
                                    dateStart: function () {
                                        return moment().subtract(1, 'months').startOf('month');
                                    },
                                    dateEnd: function () {
                                        return moment().subtract(1, 'months').endOf('month');
                                    }
                                }]
                            });
                            updateTranslation();
                        }
                        else if (typeof jobStart !== 'undefined' && typeof jobEnd !== 'undefined') {
                            var startDate = moment(jobStart, "MMDDYYYY").startOf('day').toDate();
                            var endDate = moment(jobEnd, "MMDDYYYY").startOf('day').toDate();
                            if (jobEnd > moment()) {
                                endDate = moment().startOf('day').toDate();
                            }
                            _this.daterangepicker("setRange", { start: startDate, end: endDate });
                        }
                    }, 1000, false);
                }
                var reRunItForInfiniteNumberOfTimes;
                function onChangeFunction() {
                    scope.$apply(function () {
                        var range = _this.daterangepicker("getRange");
                        scope.selectedRange = range;
                        updateTranslation();
                        if (_this.hasClass('daterangepicker1')) {
                            window.sessionStorage.setItem("date1Start", range.start);
                            window.sessionStorage.setItem("date1End", range.end);
                        } else if (_this.hasClass('daterangepicker2')) {
                            window.sessionStorage.setItem("date2Start", range.start);
                            window.sessionStorage.setItem("date2End", range.end);
                        }
                    });
                }

                function onOpenFUnction() {
                    removeAllHighlightedDates();
                    if (_this.hasClass('daterangepicker1')) {
                        if ($("#compareisonCheckbox").is(":checked")) {
                            updateDateRangePicker('daterangepicker2', window.sessionStorage.getItem("date2Start"), window.sessionStorage.getItem("date2End"));
                        }
                    } else if (_this.hasClass('daterangepicker2')) {
                        if ($("#compareisonCheckbox").is(":checked")) {
                            updateDateRangePicker('daterangepicker1', window.sessionStorage.getItem("date1Start"), window.sessionStorage.getItem("date1End"));
                        }
                    }
                }

                function removeAllHighlightedDates() {
                    $('.comiseo-daterangepicker').find('.ui-datepicker-calendar td').each(function () {
                        $(this).find('a').removeAttr('style');
                    });
                    $interval.cancel(reRunItForInfiniteNumberOfTimes);
                }

                function updateTranslation() {
                    var textToUpdate = _this.siblings("button").find(".ui-button-text").text();
                    _this.siblings("button").find(".ui-button-text").text(textToUpdate.replace(/May/g, "Mei").replace(/Mar/g, "Mrt").replace(/Oct/g, "Okt"));
                }

                Date.prototype.addDays = function (days) {
                    var dat = new Date(this.valueOf())
                    dat.setDate(dat.getDate() + days);
                    return dat;
                }

                function getDates(startDate, stopDate) {
                    var dateArray = new Array();
                    var currentDate = new Date(startDate);
                    while (currentDate <= new Date(stopDate)) {
                        dateArray.push(new Date(currentDate))
                        currentDate = currentDate.addDays(1);
                    }
                    return dateArray;
                }

                function updateDateRangePicker(currentEle, start, end) {
                    $('.comiseo-daterangepicker').first().addClass('secondary-picker');

                    var dateArray = getDates(start, end);
                    reRunItForInfiniteNumberOfTimes = $interval(function () {
                        angular.forEach(dateArray, function (val, key) {
                            highlightDate(currentEle, val.getDate(), val.getMonth(), val.getFullYear());
                        })
                    }, 1000);
                }

                function highlightDate(currentEle, d, m, y) {
                    if (currentEle == "daterangepicker1") {
                        var registeredEle = $('.comiseo-daterangepicker').last();
                        var color = 'rgba(23, 21, 128, 1)';
                    } else if (currentEle == "daterangepicker2") {
                        var registeredEle = $('.comiseo-daterangepicker').first();
                        var color = 'rgba(255, 100, 18, 1)';
                    }

                    
                    registeredEle.find('.ui-datepicker-calendar td').each(function () {
                        if ($(this).data('year') === y && $(this).data('month') === m && parseInt($(this).find('a').text()) === d) {
                            $(this).find('a').css({ 'background-color': color, 'color': '#fff' });
                        }
                    });
                    
                }
            }
        }

        //dateRangeCntl.$inject = ['dateRangeService'];

        function dateRangeCntl() {
            //var vm = this;
            //vm.publicationDateRange = {};

            // this call is incorrect
            //activate();

            ///////////////////////////////////

            //function activate() {//Service call for since first publication
            //    dateRangeService.getSincePublication()
            //        .then(successGetPublication, errorGetPublication);
            //}

            //function successGetPublication(data) {
            //    angular.copy(data, vm.publicationDateRange);
            //}

            //function errorGetPublication(data) {
            //    //Catch error here
            //    console.log(data);
            //}
        }
    }
})();
