(function(){
	'use strict';
	angular.module('loader.module', []);
})();

