(function(){
	'use script';
	angular.module('loader.module')
		.service('loaderService', loaderService);

	function loaderService(){
	    this.isLoader = false;
	    this.isOverlayLoader = false;
	    this.toggle = toggle;
	    this.toggleOverlayLoader = toggleOverlayLoader;
		this.loaderState = loaderState; 

		//To toggle loader
		function toggle(state){
			this.isLoader = state;
		}

		function toggleOverlayLoader(state) {
		    this.isOverlayLoader = state;
		}

		//Returns state of the loader
		function loaderState(){
			return this.isLoader;
		}
	}
})();