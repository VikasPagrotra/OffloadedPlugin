(function(){
	'use strict';
	angular.module('richTextEditor.module', ['ngWig']);
})();
