(function(){
	'use strict';
  angular.module('richTextEditor.module', ['ngWig'])
        .config(['ngWigToolbarProvider', function (ngWigToolbarProvider) {
          ngWigToolbarProvider.setButtons(['formats', 'list1', 'list2', 'bold', 'italic', 'link']);
          ngWigToolbarProvider.addStandardButton('underline', 'Underline', 'underline', 'fa-underline');
        }]);

})();
