(function(){
	'use strict';
	angular.module('uiAutocomplete.module', []);
})();
