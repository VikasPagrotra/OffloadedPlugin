(function(){
	'use strict';
    angular.module('uiAutocomplete.module')
		.service('uiAutocompleteService', uiAutocompleteService);

    uiAutocompleteService.$inject = ['$http', '$q'];

    function uiAutocompleteService($http, $q) {
		var service;

	}
})();
