(function () {
    'use strict';
    angular.module('uiAutocomplete.module')
        .directive('autoComplete', autoComplete);

    autoComplete.$inject = ['$timeout'];

    function autoComplete($timeout) {
        var directive = {};

        directive.restrict = 'AE'; /* restrict this directive to elements */

        directive.require = '?ngModel';

        directive.scope = {
            uiItems: '=uiItems',
            callbackFunction: '&callbackFunction',
            manyselect: "@manyselect",
        };

        directive.compile = compile;

        return directive;

        function compile(element, attributes) {

            var linkFunction = function linkFunction($scope, element, atttributes, ngModel) {

                if (!ngModel) return;
                $scope.$watch('uiItems', function () {
                    if (!$scope.uiItems) return;

                    if (attributes.manyselect == "true") {
                        element.autocomplete({
                            source: function (request, response) {
                                response($.ui.autocomplete.filter(
                                  $scope.uiItems, request.term.split((',')).pop()))
                            },
                            minLength: 0,
                            select: function (event, ui) {
                                $timeout(function () {                               
                                    var oldModel = '';
                                    if (ngModel && ngModel.$viewValue != undefined && ngModel.$viewValue != '') {
                                        var viewValue = ngModel.$viewValue.split(',');
                                        for (var i = 0; i < viewValue.length - 1; i++) {
                                            if (i < viewValue.length - 2) {
                                                oldModel += viewValue[i] + ',';
                                            }
                                            else {
                                                oldModel += viewValue[i];
                                            }
                                        }                                        
                                    }

                                    var terms = element.val().split(',');
                                    terms.pop();
                                    terms.push(ui.item.value);
                                    terms.push("");
                                    var newModel = '';
                                    if (oldModel != '') {
                                        newModel = oldModel + ',' + terms.join(",");
                                    }
                                    else {
                                        newModel = terms.join(",");
                                    }
                                    ngModel.$setViewValue(newModel);
                                    ngModel.$render();
                                    $scope.callbackFunction();

                                }, 0);
                            }
                        }).bind('focus', function () {
                            $(this).autocomplete("search");
                            $('.ui-menu-item:first-child .ui-corner-all').addClass('ui-state-focus');
                        });
                    }
                    else {
                        element.autocomplete({
                            source: function (request, response) {
                                var results = $.ui.autocomplete.filter($scope.uiItems, request.term);

                                response(results.slice(0, 10));
                            },
                            minLength: 0,
                            delay: 50,
                            select: function () {
                                $timeout(function () {
                                    //element.trigger('input');
                                    ngModel.$setViewValue(element.val());
                                    //$scope.callbackFunction();

                                }, 0);
                            }
                        }).bind('focus', function () {
                            $(this).autocomplete("search");
                            $('.ui-menu-item:first-child .ui-corner-all').addClass('ui-state-focus');
                        });
                    }
                });
            };

            return linkFunction;
        }
    }
})();