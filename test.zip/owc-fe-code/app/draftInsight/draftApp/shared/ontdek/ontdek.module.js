(function(){
	'use strict';
	angular.module('ontdek.module', []);
})();