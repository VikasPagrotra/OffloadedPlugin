(function () {
  'use strict';
  angular.module('ontdek.module')
    .service("ontdekService", ontdekService);

  ontdekService.$inject = ['$http', 'enumApp', 'keywordPlannerService', '$timeout', 'loaderService', '$q'];

  function ontdekService($http, enumApp, keywordPlannerService, $timeout, loaderService, $q) {
      var self = this;
      self.fetchDiscoveredKeywords = fetchDiscoveredKeywords;

    this.model = [];
    $http.get(enumApp.url.draftUrl + 'vacature/discoverkeywords/vacature')
      .then(function (rslt) {
        self.model = rslt.data;
      });

      
    function fetchDiscoveredKeywords(q) {
        var deferred = $q.defer();

        $http({
            url: enumApp.url.draftUrl + 'vacature/discoverkeywords/' + q + '/',
            method: "GET"
        })
        .success(function (data) {
            deferred.resolve(data);
        })
        .error(function () {
            deferred.reject("Failed to get discovered Keyowrds");
        });

        return deferred.promise;
    }

    this.nodes = {};

    this.force = {};
    this.svg = {};
    this.nodeClass = 'networkNode';
    this.linkClass = 'networkLink';
    this.textClass = 'networkText';

    this.init = init;

    this.update = update;

    this.tick = tick;

    //////////////////////////////////

    function init(ele) {
      var self = this, width, height, link;

      self.chart = document.getElementById(ele);
      width = self.chart.clientWidth;
      height = 500;

      // Compute the distinct nodes from the links.
      self.model.forEach(function (link) {
        link.source = self.nodes[link.source] || (self.nodes[link.source] = { name: link.source });
        link.target = self.nodes[link.target] || (self.nodes[link.target] = { name: link.target });
      });

      self.force = d3.layout.force()
        .nodes(d3.values(self.nodes))
        .links(self.model)
        .size([width, height])
        .linkDistance(function (d) { return 300 * (0.75 - d.score); })
        .charge(-300)
        .on("tick", tick)
        .start();

      self.svg = d3.select(self.chart).append("svg")
        .attr("width", width)
        .attr("height", height);

      self.link = self.svg.selectAll("." + self.linkClass)
        .data(self.force.links())
        .enter().append("line")
        .attr("class", self.linkClass);

      self.node = self.svg.selectAll("." + self.nodeClass)
        .data(self.force.nodes())
        .enter().append("g")
        .attr("class", self.nodeClass)
        .on("mouseover", mouseover)
        .on("mouseout", mouseout)
        .on("click", clickCallback)
        .call(self.force.drag);

      self.node.append("circle")
        .attr("r", 8);

      self.node.append("text")
        .attr("class", self.textClass)
        .attr("x", 12)
        .attr("dy", ".35em")
        .text(function (d) { return d.name; });
    }

    function update(q) {
        loaderService.toggleOverlayLoader(true);
      var url = enumApp.url.draftUrl + 'vacature/discoverkeywords/' + q + '/';
      $http.get(url)
        .then(function (rslt) {
            loaderService.toggleOverlayLoader(false);
            if (rslt.data === null) {
                angular.element(document.getElementById('networkKeywords')).css('display', 'none');
                angular.element(document.getElementById('suggesties')).css('display', 'block');
                return false;
            } else {
                angular.element(document.getElementById('networkKeywords')).css('display', 'block');
                angular.element(document.getElementById('suggesties')).css('display', 'none');
            }
          self.model = rslt.data;

          // Compute the distinct nodes from the links.
          self.nodes = {};
          self.model.forEach(function (link) {
            link.source = self.nodes[link.source] || (self.nodes[link.source] = { name: link.source });
            link.target = self.nodes[link.target] || (self.nodes[link.target] = { name: link.target });
          });

          self.force.nodes(d3.values(self.nodes)).links(self.model);

          self.link.remove();
          self.link = self.svg.selectAll("." + self.linkClass);
          self.link = self.link.data(self.force.links());
          self.link.enter().append("line").attr("class", self.linkClass);

          self.node.remove();
          self.node = self.svg.selectAll("." + self.nodeClass);
          self.node = self.node.data(self.force.nodes());

          self.node.enter().append("g")
            .attr("class", self.nodeClass)
            .on("mouseover", mouseover)
            .on("mouseout", mouseout)
            .on("click", clickCallback)
            .call(self.force.drag);

          self.node.append("circle").attr("r", 8);

          self.node.append("text")
            .attr("class", self.textClass)
            .attr("x", 12)
            .attr("dy", ".35em")
            .text(function (d) { return d.name; });

          self.force.start();
        });
    }

    function tick() {
      self.link
        .attr("x1", function (d) { return d.source.x; })
        .attr("y1", function (d) { return d.source.y; })
        .attr("x2", function (d) { return d.target.x; })
        .attr("y2", function (d) { return d.target.y; });

      self.node
        .attr("transform", function (d) { return "translate(" + d.x + "," + d.y + ")"; });
    }

    function mouseover() {
      d3.select(this).select("circle").transition()
        .duration(750)
        .attr("r", 16);
    }

    function mouseout() {
      d3.select(this).select("circle").transition()
        .duration(750)
        .attr("r", 8);
    }

    function clickCallback() {
      var text = d3.select(this).select("text").text();
      $timeout(function () {
        keywordPlannerService.planBucket['discoverKeywords'].data.push(text);
      });
    }
  }
})();