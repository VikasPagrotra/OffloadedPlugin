(function(){
	'use strict';
	angular.module('keywordPlanner.module')
		.directive('toggleBucket', toggleBucket);

	toggleBucket.$inject = ['$timeout'];

	function toggleBucket($timeout){
		var directive;

		directive = {
			restrict : 'AE',
			scope : {

			},
			compile : compileFunction,
			replace : true
		};

		return directive;

		/////////////////////////////

		//Compile is called only once during application initialization. Angular js call it once when html page is loaded.
		function compileFunction(element, attributes){
			//linkFunction is linked to each element with scope to get the element specific data
			var linkFunction = linkFunction;

			return linkFunction;

			/////////////////////////////////////////////

			function linkFunction(scope, element, attributes){
				element.on('click', function(){

				    if (angular.isDefined(attributes.toggleBucketClose)) {
				        angular.element(document.getElementById(attributes.toggleBucketClose)).addClass('hidden');
				    }
					if(attributes.toggleNext === "true"){
						angular.element(this).next().toggleClass('hidden');
					}else if(attributes.toggleCheck == "keywords"){
						angular.element('#'+attributes.toggleBucket).removeClass('hidden');
						angular.element('.comp-overlay').addClass('extend');
					}else{
						angular.element('#'+attributes.toggleBucket).toggleClass('hidden');
						if (!angular.isDefined(attributes.toggleBucketClose)) {
						    extendeTheSection();
						}
					}
					$timeout(function () {
					    if ($("textarea").hasClass('textarea-resizable')) {
					        $("textarea").resizable({
					            handles: "se"
					        });
					        $("textarea").resizable("destroy");
					        $("textarea").css('width', '100%');
					        var widthOfparent = $('.resizable-textarea').width();
					        $("textarea").resizable({
					            handles: "se",
					            maxWidth: widthOfparent + 30,
					            minWidth: widthOfparent + 30,
					            resize: function (event, ui) {
					                ui.originalElement.closest('div').find('.ui-icon-gripsmall-diagonal-se').css('right', -(widthOfparent - 16) + 'px');
					            }
					        });
					        $("textarea").css('width', '100%');
					        $('textarea').closest('.ui-wrapper').css('max-width', (widthOfparent + 30) + 'px');
					    }
					}, 500)
				});

			}

			function extendeTheSection(){
				$timeout(function(){
				    angular.element('.comp-overlay').toggleClass('extend');
				});
			}

		}
	}
})();
