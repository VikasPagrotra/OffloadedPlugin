(function(){
	'use strict';

	angular.module('keywordPlanner.module', []);
})();