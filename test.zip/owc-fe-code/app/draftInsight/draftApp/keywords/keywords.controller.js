(function(){
	'use strict';
	angular.module('keywordPlanner.module')
		.controller('keywordPlannerCntl', keywordPlannerCntl);

	keywordPlannerCntl.$inject = ['$scope', 'keywordPlannerService', 'loaderService', 'ontdekService', 'draftAppService', '$rootScope', '$timeout', '$state'];

	function keywordPlannerCntl($scope, keywordPlannerService, loaderService, ontdekService, draftAppService, $rootScope, $timeout, $state){
		var vm = this;

		var fmsId = $state.params.fmsId;
		if (fmsId) {
			draftAppService.getVacature(fmsId,true,"Keywords");
		}
		$scope.$on('vacatureFetched', function (event, vacature) {
		    vm.vacature = vacature;
			angular.forEach(vm.dummytable, function (item) {
				angular.forEach(vm.vacature.keywords.funcKeywords, function (dbItem) {
					if(item.keyword == dbItem.keyword){
						item.addToPlan = true;
					}
				});
			});
		}, true);

		vm.activeTab = 'functies';

		vm.dummytable = keywordPlannerService.dummytable;
		$scope.$on('keywordsFetched', function (event, data) {
			vm.dummytable = data;
		}, true);

		vm.planBucket = keywordPlannerService.planBucket;
		vm.dummyRecruitmentTable = keywordPlannerService.dummyRecruitmentTable;
		vm.dummyTitle = keywordPlannerService.dummyTitle;
		vm.dummyFullPartTime = keywordPlannerService.dummyFullPartTime;
		vm.dummyContractduur = keywordPlannerService.dummyContractduur;
		vm.contactDuur = keywordPlannerService.contactDuur;

		vm.changeActiveTab = changeActiveTab;

		vm.fullPartTime = fullPartTime;

		vm.returnPartial = returnPartial;

		vm.loadChart = loadChart;

		vm.openPopup = openPopup;

		vm.addThisToPlan = function(index, data, label, obj){
			var arr = [], keyToDelete = [];
			if(label === 'fullPartTime'){
				arr = keywordPlannerService.planBucket[label].data;
				data.addToPlan = !data.addToPlan;
				keywordPlannerService.planBucket[label].data.push(data);
				angular.forEach(arr, function(value, key){
					if(value.addToPlan === false){
						keyToDelete.push(key);
					}
				});
				angular.forEach(keyToDelete, function(value, key){
					keywordPlannerService.planBucket[label].data.splice(value, 1);
				});
			}else{
				data.addToPlan = true;
				keywordPlannerService.planBucket[label].data.push(data);
				obj.splice(index, 1);
			}
			console.log(keywordPlannerService.planBucket);
		}

		vm.removeThisToPlan = function(index, data, label, obj){
			data.addToPlan = false;
			obj.push(data);
			vm.planBucket[label].data.splice(index, 1);
		}

		vm.addTextFieldToPlan = function(label, obj){
			vm.planBucket[label].data = [];
			vm.planBucket[label].data = angular.copy(obj);
			var newItemNo = obj.length+1;
			obj.push({'id':label+newItemNo});
		}

		vm.removeDiscoverFromPlan = function(index, data, label, obj){
			vm.planBucket[label].data.splice(index, 1);

			for (var i = 0; i < obj.length; i++) {
				if(data.id == obj[i].id)
					obj.splice(i, 1);
			};
		}

		activate();

		//////////////////////////////////////////////

		function activate(){
			//this is for change tabs as this controller loads
			$rootScope.$broadcast('changeActiveTab', {str: 'mijnPublicaties.keywords'});
			draftAppService.initPopover('.btn-popup');

		    //get user infor for chat and notification 
			draftAppService.getUserSession().then(function (data) {
			    data.Avatar += "?v=" + Date.now();
			    vm.userSession = data;
			});
		}

		function removeThisField(obj, indexToDelete){
			obj.splice(indexToDelete, 1);
		}

		function changeActiveTab(str){
			vm.activeTab = str;
			//changeActiveTabUrl(vm.activeTab);
		}

		function fullPartTime(label){
			keywordPlannerService.planBucket["fullPartTime"][label] = !keywordPlannerService.planBucket["fullPartTime"][label];
		}

		function returnPartial(view){
			return './draftApp/shared/partial/_' + view + '.html';
		}

		function loadChart(){
			$timeout(function(){
				ontdekService.init('networkKeywords');
			});
		}

		function openPopup(view, screen){
			$rootScope.$broadcast('openPopupSection', {'view':view, 'screen': screen});
		}
	}
})();
