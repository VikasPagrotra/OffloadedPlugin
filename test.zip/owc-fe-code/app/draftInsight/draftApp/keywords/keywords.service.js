(function () {
    'use strict';

    angular.module('keywordPlanner.module')
		.service('keywordPlannerService', keywordPlannerService);

    keywordPlannerService.$inject = ['$http', '$q', '$rootScope', 'enumApp'];

    function keywordPlannerService($http, $q, $rootScope, enumApp) {
        var service,
            dummytable = [],
            dummyRecruitmentTable = [],
            fullPartTimeKeywords = [],
            contractDurationKeywords = [],
            dummyTitle = [
                {
                    id: "title1",
                    "title": ""
                }
            ],
            dummyFullPartTime = [
                {
                    "label": "Fulltime",
                    "addToPlan": false,
                    "desc": "Meer dan 38 uur per week",
                    "icon": ["icon-clock-fulltime"]
                },
                {
                    "label": "Parttime",
                    "addToPlan": false,
                    "desc": "Minder dan 38 uur per week",
                    "icon": ["icon-clock-partime"]
                }, {
                    "label": "Parttime & fulltime",
                    "addToPlan": false,
                    "desc": "Vacature voor beide geschikt",
                    "icon": ["icon-clock-partime", "icon-clock-fulltime"]
                }
            ],
            dummyContractduur = [
                {
                    "label": "Onbepaalde tijd",
                    "addToPlan": false,
                    "desc": "Meer dan 38 uur per week",
                    "icon": ["icon-rotation-ellipsis1"]
                },
                {
                    "label": "Bepaalde tijd",
                    "addToPlan": false,
                    "desc": "Minder dan 38 uur per week",
                    "icon": ["icon-calculator1"]
                }
            ],
            planBucket = {
                "keywordPlanner": {
                    "data": []
                },
                "recruitmentArea": {
                    "data": []
                },
                "title": {
                    "data": []
                },
                "contractDuur": {
                    "data": []
                },
                "discoverKeywords": {
                    "data": []
                },
                "fullPartTime": {
                    "data": []
                },
                "fullPartTimeKeywords": {
                    "data": []
                },
                "contractDurationKeywords": {
                    "data": []
                }
            };

        service = {
            dummytable: dummytable,
            dummyRecruitmentTable: dummyRecruitmentTable,
            dummyTitle: dummyTitle,
            planBucket: planBucket,
            dummyFullPartTime: dummyFullPartTime,
            addNewUseProperty: addNewUseProperty,
            dummyContractduur: dummyContractduur,
            fetchLocations: fetchLocations,
            fetchFunctionKeywords: fetchFunctionKeywords,
            isAlarmedStudentKeywordsUsed: isAlarmedStudentKeywordsUsed

        };

        $http.get(enumApp.url.draftUrl + 'vacature/fmsCities')
			.then(function (rslt) {
			    $rootScope.$broadcast('fmsLocationsFetched', rslt.data);
			});

        $http.get(enumApp.url.draftUrl + 'vacature/fullPartTime')
				.then(function (rslt) {
				    $rootScope.$broadcast('fullPartTimeKeywordsFetched', rslt.data);
				    service.fullPartTimeKeywords = fullPartTimeKeywords = rslt.data;
				});
        
        $http.get(enumApp.url.draftUrl + 'vacature/contractDurations')
               .then(function (rslt) {
                   $rootScope.$broadcast('contractDurationKeywordsFetched', rslt.data);
                   service.contractDurationKeywords = contractDurationKeywords = rslt.data;
               });

        $http.get(enumApp.url.draftUrl + 'vacature/SearchKeysList')
			.then(function (rslt) {
			    $rootScope.$broadcast('searchFunctionKeysFetched', rslt.data);
			});

        function fetchFunctionKeywords(searchKeys) {
            var deferred = $q.defer();
            $http({
                url: enumApp.url.draftUrl + 'vacature/keywords',
                method: "POST",
                data: searchKeys
            })
			.success(function (data) {
			    deferred.resolve(data);
			})
			.error(function () {
			    deferred.reject("Failed to get functionKeywords");
			});

            return deferred.promise;
        }

        /////////////////////////

        function addNewUseProperty(obj) {
            angular.forEach(obj, function (value, key) {
                value.use = Math.floor(Math.random() * 100);
            });
            return obj;
        }

        function fetchLocations(fmsCity) {
            var deferred = $q.defer();

            $http({
                url: enumApp.url.draftUrl + 'vacature/locations/' + fmsCity,
                method: "GET",
            })
			.success(function (data) {
				deferred.resolve(data);
			})
			.error(function () {
				deferred.reject("Failed to get locations");
			});

            return deferred.promise;
        }

        function isAlarmedStudentKeywordsUsed(fullPartTimeKeywords) {
            var result = false;
            //var arr = keywordPlannerService.planBucket['fullPartTimeKeywords'].data;
            angular.forEach(fullPartTimeKeywords, function (value, key) {
                if (value.keyword == 'Studentenwerk' || value.keyword == 'Studentenjob') {
                    result = true;
                    return result;
                }
            });
            return result;
        }

        return service;
    }
})();
