(function () {
    'use strict';
    angular.module('new.module').controller('newCtlr', newCtlr);

    newCtlr.$inject = ['$rootScope', '$http', '$interval', '$scope', '$state', '$timeout', 'draftAppService', 'loaderService', 'enumApp', '$q'];

    function newCtlr($rootScope, $http, $interval, $scope, $state, $timeout, draftAppService, loaderService, enumApp, $q) {
        var vm = this;
        vm.kenmerken = 'Inhound';
        // set netherland as default coutnry
        vm.publicatieData = { tags: {}, jobCountry: 'Nederland' };
        vm.save = save;
        vm.getCurrentUserBranches = getCurrentUserBranches;
        vm.checkValidVacature = checkValidVacature;
        vm.branches = [];
        vm.validationObj = {};

        draftAppService.getUserSession().then(function (data) {
            vm.userSession = data;
            loaderService.toggle(false);
        });
        // get tags
        draftAppService.getTagsSets()
            .then(function (data) {
                vm.tags = data;
            });

        var cancelResourceInterval = $interval(function () {
            if (typeof ($scope.appResources.LblJobTitle) != "undefined") {
                vm.checkValidVacature();
                draftAppService.initPopover('.btn-popup');
                $interval.cancel(cancelResourceInterval);
            }
        }, 500);

        vm.getCurrentUserBranches();

        // load cities
        $http.get(enumApp.url.draftUrl + 'vacature/fmsCities')
            .then(function (rslt) {
                $rootScope.$broadcast('fmsLocationsFetched', rslt.data);
            });
        $rootScope.$on('fmsLocationsFetched', function (event, data) {
            vm.fmsLocations = data;
        }, true);

        function save() {
            // prevent saving data if there are required fields not filled yet
            vm.checkValidVacature();
            if (!vm.validationObj.isValidPub) {
                return false;
            }

            $http({
                url: enumApp.url.draftUrl + 'vacature/new',
                method: "POST",
                data: vm.publicatieData
            })
            .success(function (data) {
                // redirect to that fms
                $state.go('mijnPublicaties.vacature', { fmsId: data.fmsId });
            })
            .error(function (data, status) {
                alert('error: ' + status + ' | ' + data);
            });
        };

        function getCurrentUserBranches() {
            var deferred = $q.defer();
            if (vm.branches.length) {
                deferred.resolve(vm.branches);
                return deferred.promise;
            }

            $http({
                url: enumApp.url.draftUrl + '/vacture/userBranches',
                method: "GET"
            })
            .success(function (data) {
                vm.branches = data;
                deferred.resolve(data);
            })
            .error(function () {
                deferred.reject("Failed to get all user's branches");
            });

            return deferred.promise;
        }

        function checkValidVacature() {
            vm.validationObj.isValidPub = true;
            vm.validationObj.message = null;
            var isValidPub = true;
            var oneValueRequiredFor = "";
            var requiredValues = "";

            if (vm.publicatieData.publicatieTitle == null || vm.publicatieData.publicatieTitle == '') {
                requiredValues += " <li>" + $scope.appResources.LblJobTitle + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.publicatieOrganisatie == null || vm.publicatieData.publicatieOrganisatie == '') {
                requiredValues += " <li>" + $scope.appResources.LblOrganizationDescription + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.publicatieFunctie == null || vm.publicatieData.publicatieFunctie == '') {
                requiredValues += " <li>" + $scope.appResources.LblJobDescription + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.publicatieOns == null || vm.publicatieData.publicatieOns == '') {
                requiredValues += " <li>" + $scope.appResources.LblOurOffer + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.weAsk == null || vm.publicatieData.weAsk == '') {
                requiredValues += " <li>" + $scope.appResources.LblWeAsk + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.jobCountry == null || vm.publicatieData.jobCountry.length < 1) {
                oneValueRequiredFor += " <li>" + $scope.appResources.LblJobCountry + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.jobCity == null || vm.publicatieData.jobCity == '') {
                requiredValues += " <li>" + $scope.appResources.LblJobLocation + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.jobZipCode == null || vm.publicatieData.jobZipCode == '') {
                requiredValues += " <li>" + $scope.appResources.LblJobZipCode + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.tags.jobBusiness == null || vm.publicatieData.tags.jobBusiness.length < 1) {
                oneValueRequiredFor += " <li>" + $scope.appResources.LblBranch + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.hoursPerWeek == null || vm.publicatieData.hoursPerWeek == '') {
                requiredValues += " <li>" + $scope.appResources.LblNumberOfHours + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.salaryPerMonth == null || vm.publicatieData.salaryPerMonth == '') {
                requiredValues += " <li>" + $scope.appResources.LblSalaryPerMonth + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.tags.jobLdcFunction == null || vm.publicatieData.tags.jobLdcFunction.length < 1) {
                oneValueRequiredFor += " <li>" + $scope.appResources.LblFunction + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.tags.jobFulltime == null || vm.publicatieData.tags.jobFulltime.length < 1) {
                oneValueRequiredFor += " <li>" + $scope.appResources.LblFullTime_PartTime + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.tags.jobVakgebied == null || vm.publicatieData.tags.jobVakgebied.length < 1) {
                oneValueRequiredFor += " <li>" + $scope.appResources.LblFieldOfStudy + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.vacancyLanguage == null || vm.publicatieData.vacancyLanguage == '') {
                requiredValues += " <li>" + $scope.appResources.LblVacancyLanguage + "</li>";
                isValidPub = false;
            }
            if (vm.publicatieData.tags.jobFunctionLevel == null || vm.publicatieData.tags.jobFunctionLevel.length < 1) {
                oneValueRequiredFor += " <li>" + $scope.appResources.LblEducationLevel + "</li>";
                isValidPub = false;
            }

            if (oneValueRequiredFor != "" || requiredValues != "") {
                vm.validationObj.isValidPub = isValidPub;
                if (oneValueRequiredFor != "") {
                    oneValueRequiredFor = oneValueRequiredFor.substr(1);
                    oneValueRequiredFor += " vereist minstens 1 waarde";
                }
                if (requiredValues != "") {
                    requiredValues = requiredValues.substr(1);
                    requiredValues += " Is benodigd";
                }
                if (oneValueRequiredFor != "" || requiredValues != "") {
                    vm.validationObj.message = "<ul class='padding left--2x'>" + oneValueRequiredFor + requiredValues + "</ul>";
                } else {
                    vm.validationObj.message = oneValueRequiredFor + requiredValues;
                }
            }
        }
    }
})();
