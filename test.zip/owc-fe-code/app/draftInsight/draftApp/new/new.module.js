(function () {
    'use strict';
    angular.module('new.module', []);
})();
