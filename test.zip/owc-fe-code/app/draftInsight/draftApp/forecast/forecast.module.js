(function(){
	'use strict';
	angular.module('forecast.module', []);
})();