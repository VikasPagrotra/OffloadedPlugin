(function () {
    'use strict';
    angular.module('forecast.module')
		.controller('forecastCntl', forecastCntl);

    forecastCntl.$inject = ['forecastService', 'forecastModel', 'draftAppService', '$rootScope', '$timeout', '$scope', '$state', '$interval', 'loaderService', '$filter'];

    function forecastCntl(forecastService, forecastModel, draftAppService, $rootScope, $timeout, $scope, $state, $interval, loaderService, $filter) {
        var vm = this, SimpleGraph, registerKeyboardHandler, graph;
        vm.delivery = {};
        vm.margin = {};
        vm.returnPartial = returnPartial;
        vm.openPopup = openPopup;
        vm.loadForecast = loadForecast;
        vm.activeForecastModelData = [];
        vm.settings = {};
        vm.hideProgressBarDiv = false;
        vm.setForecastPeriod = setForecastPeriod;
        vm.updateTotalForecast = updateTotalForecast;
        vm.Math = window.Math;
        vm.getCommulativeForecastValue = getCommulativeForecastValue;
        vm.checkForNumberValidity = checkForNumberValidity;
        activate();

        var fmsId = $state.params.fmsId;
        if (fmsId) {
            vm.isMLDataSuccess = false;
            draftAppService.getVacature(fmsId, true, "Forecast");
            draftAppService.refreshMl(fmsId).then(
                refreshMlSuccess, refreshMlFailed);
        }

        function refreshMlSuccess(data) {
            // todo: hide loader
            if (data) {
                vm.isMLDataSuccess = true;
                loaderService.toggleOverlayLoader(false);
            }
        }

        function refreshMlFailed(data) {
            // todo: do something else
        }

        $scope.$on('vacatureFetched', function (event, vacature) {
            if (!vm.isMLDataSuccess) {
                // todo: show loader to block the forecast area
                loaderService.toggleOverlayLoader(true);
            }

            vm.vacature = vacature;
            vm.configForecast = {
                "applicants": vm.vacature.forecast.applicants,
                "propose": vm.vacature.forecast.candidatesPropose
            };

            vm.publicatieData = angular.copy(vm.vacature.publicatieInhoud.publications).concat(angular.copy(vm.vacature.publicatieInhoud.drafts));
            forecastService.publicatieData = vm.publicatieData;

            // update totals
            angular.forEach(vm.publicatieData, function (item) {
                vm.updateTotalForecast(item);
            });
            vm.publicatieDataBackup = angular.copy(vm.publicatieData);
        }, true);


        $interval(function () {
            if (vm.publicatieData == undefined) return;

            if (!angular.equals(vm.publicatieData, vm.publicatieDataBackup)
                || vm.configForecast.applicants != vm.vacature.forecast.applicants
                || vm.configForecast.propose != vm.vacature.forecast.candidatesPropose) {

                angular.forEach(vm.publicatieData, function (item) {
                    vm.updateTotalForecast(item);
                });

                vm.publicatieDataBackup = angular.copy(vm.publicatieData);
                vm.configForecast = {
                    "applicants": vm.vacature.forecast.applicants,
                    "propose": vm.vacature.forecast.candidatesPropose
                };
            }
        }, 1000);

        /////////////////////////

        function activate() {
            var ele = document.getElementById('benchmarkChart');

            vm.progreeBarDummyData = forecastModel.progreeBarDummyData;
            forecastService.addWidthsToPopover();
            draftAppService.initPopover('.btn-popup');

            //this is for change tabs as this controller loads
            $rootScope.$broadcast('changeActiveTab', { str: 'mijnPublicaties.forecast' });
            draftAppService.getSettings().then(resolveSettings);

        }

        function resolveSettings(data) {
            vm.settings.companyName = data.CompanyName;
            vm.settings.logoUrl = data.LogoUrl;
        }

        function returnPartial(view) {
            return './draftApp/shared/partial/_' + view + '.html';
        }

        function openPopup(view, data, index) {
            // todo: this will be needed if we need to show data according to selected week
            //data.weekNo = vm.weekNo;
            $rootScope.$broadcast('openPopup', { view: view, data: data, index: index });
        }

        function loadForecast() {
            //Instantiate d3 chart
            $timeout(function () {
                forecastService.drawBenchmarkD3();
            });
        }

        function setForecastPeriod(period, weekNo) {
            vm.forecastPeriod = period;
            vm.weekNo = weekNo;
        }

        function updateTotalForecast(item) {
            // don't continue if no forecasts
            if (item.currentForecasts == null) return;
            var totalForeCast = 0;
            for (var i = 1; i < 10; i++) {
                totalForeCast = item.currentForecasts[i].y;
                item.currentForecasts[i].y = Math.round(totalForeCast);
                vm.configForecast = {
                    "applicants": vm.vacature.forecast.applicants,
                    "propose": vm.vacature.forecast.candidatesPropose
                };
                // propose count
                var proposeCount = item.currentForecasts[i].y / vm.configForecast.applicants * vm.configForecast.propose;
                item.currentForecasts[i].proposeCount = Math.round(proposeCount);

                // hire count
                var hireNo = item.currentForecasts[i].proposeCount / vm.configForecast.propose;
                item.currentForecasts[i].hireCount = hireNo < 1 ? Math.round(hireNo * 10) / 10 : Math.round(hireNo);
            }
        }

        $timeout(function () {
            vm.hideProgressBarDiv = true;
        }, 2000);

        function getCommulativeForecastValue(forecastData, weekNo) {
            var sum = 0;
            if (forecastData) {
                for (var i = 0; i <= weekNo; i++) {
                    sum += forecastData[i].y;
                }
            }
            return sum;
        }

        function checkForNumberValidity(value) {
            return value === null || isNaN(value) ? "#" : $filter('number')(value, 0);
        }

    }
})();
