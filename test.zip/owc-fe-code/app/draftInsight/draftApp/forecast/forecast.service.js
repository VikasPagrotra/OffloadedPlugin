(function () {
    'use strict';
    angular.module('forecast.module')
		.service('forecastService', forecastService);

    forecastService.$inject = ['forecastModel', '$timeout', '$interval', '$q', '$http', 'enumApp'];

    function forecastService(forecastModel, $timeout, $interval, $q, $http, enumApp) {
        var vm = this, service,
			createBenchmarkD3,
			drawBenchmarkD3,
			liveData = [
		        15, 8, 18, 17, 20, 0, 0, 0, 0, 0
			],
		    customDomainI = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
		    chartData = forecastModel.BenchMarkChartData.chartData.arrData,
		    legendData = forecastModel.BenchMarkChartData.legends,
		    legendColor = forecastModel.BenchMarkLegendColor,
				bestaandKlant = forecastModel.bestaandKlant,
				aantalconcurrenetn = forecastModel.aantalconcurrenetn,
				vacatureprioreit = forecastModel.vacatureprioreit;

        vm.bestaandKlant = bestaandKlant;

        vm.aantalconcurrenetn = aantalconcurrenetn;

        vm.vacatureprioreit = vacatureprioreit;
        vm.publicatieData = [];

        vm.chart = null;
        vm.circle = null;
        vm.fmsId = null;
        vm.saveUserForecast = saveUserForecast;

        $interval(function () {
            if (vm.userForecast == undefined || vm.chart == null || vm.chart.points == null || vm.chart.points.length <= 0) return;

            if (!angular.equals(vm.userForecast, vm.chart.points)) {
                vm.userForecast = angular.copy(vm.chart.points);
                //post to api these changes
                vm.saveUserForecast(vm.userForecast).then(changePublicationForeCast);
            }
        }, 2000);

        function changePublicationForeCast(data) {
            if (!data) return;

            var pubObj = {};
            var elementPos = vm.publicatieData.map(function (x) {
                return x.publicatieCircle;
            }).indexOf(vm.circle);
            pubObj = vm.publicatieData[elementPos];
            pubObj.currentForecasts = angular.copy(vm.userForecast);
        }

        function saveUserForecast(userForecast) {
            var deferred = $q.defer();

            $http({
                url: enumApp.url.draftUrl + 'forecast/' + vm.fmsId + '/' + vm.circle,
                method: "POST",
                data: userForecast
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function () {
                deferred.reject("Failed to save user Forecast");
            });

            return deferred.promise;
        }

        vm.chartOptions = {
            options: {
                'title': '',
                'titleTextStyle': {
                    'fontSize': 20
                },
                'hAxis': {
                    'title': '',
                    'textStyle': {
                        'fontSize': 10
                    }
                },
                'vAxis': {
                    'title': '',
                    'textStyle': {
                        'fontSize': 10
                    }
                },
                'stroke-width': 2,
                'width': '1000',
                'height': '500',
                'pointSize': 4,
                'series': {
                    0: {
                        'lineWidth': 0,
                        'pointShape': 'triangle',
                        'pointSize': 6
                    },
                    2: {
                        'lineWidth': 0,
                        'pointShape': 'square',
                        'pointSize': 6
                    },
                    3: {
                        'lineWidth': 2,
                        'pointSize': 0
                    }
                }
            },
            arrData: []
        }

        this.createBenchmarkD3 = function createBenchmarkD3(elemid, options) {
            var self = this, circleWithoutDrag;

            this.chart = document.getElementById(elemid);
            this.cx = this.chart.clientWidth - 100;
            this.cxLegend = this.chart.clientWidth - 600;
            this.cy = this.chart.clientHeight;
            this.options = options || {};
            this.options.xmax = options.xmax || 18;
            this.options.xmin = options.xmin || 0;
            this.options.ymax = options.ymax || 10;
            this.options.ymin = options.ymin || 0;
            this.options.default = options.i || 3;

            this.padding = {
                "top": this.options.title ? 40 : 20,
                "right": 30,
                "bottom": this.options.xlabel ? 60 : 10,
                "left": this.options.ylabel ? 70 : 45
            };

            this.size = {
                "width": this.cx,
                "height": this.cy - this.padding.top - this.padding.bottom
            };

            // x-scale
            this.x = d3.scale.linear()
			  .domain([this.options.xmin, this.options.xmax])
                .range([0, (this.size.width - 50)]);

            // drag x-axis logic
            this.downx = Math.NaN;

            // y-scale (inverted domain)
            this.y = d3.scale.linear()
			.domain([this.options.ymax, this.options.ymin])
			.nice()
			.range([0, this.size.height])
			.nice();

            // drag y-axis logic
            this.downy = Math.NaN;

            this.dragged = this.selected = null;

            //Line for draggable line
            this.line = d3.svg.line()
			  .x(function (d, i) { return this.x(this.points[i].x); })
			  .y(function (d, i) { return this.y(this.points[i].y); });

            //Line for Circle
            this.circleLine = d3.svg.line()
			.x(function (d, i) { return this.x(this.circles[i].x); })
			.y(function (d, i) { return this.y(this.circles[i].y); });

            var xrange = (this.options.xmax - this.options.xmin),
			  yrange2 = (this.options.ymax - this.options.ymin) / 2,
			  yrange4 = yrange2 / 2,
			  datacount = chartData.length;

            this.points = d3.range(datacount).map(function (i) {
                return { x: i, y: chartData[i][4] };
            }, self);

            this.circles = d3.range(datacount).map(function (i) {
                return { x: i, y: chartData[i][2] };
            }, self);

            this.square = d3.range(datacount).map(function (i) {
                return { x: i, y: chartData[i][3] };
            }, self);

            this.triangle = d3.range(datacount).map(function (i) {
                return { x: i, y: chartData[i][1] };
            }, self);

            this.vis = d3.select(this.chart).append("svg")
                .attr("width", this.cx)
                .attr("height", this.cy)
                .attr("class", "chartSVG");
            this.showLegends = this.vis.append("g")
                .attr("class", "chartLegends")
                .attr("transform", "translate(0,-20)");
            this.showchart = this.vis.append("g")
                .attr("transform", "translate(" + this.padding.left + "," + (this.padding.top + 20) + ")");

            this.plot = this.showchart.append("rect")
			.attr("class", "draftRect")
                .attr("width", (this.size.width - 50))
			.attr("height", this.size.height)
			.attr("pointer-events", "all")
			.on("mousedown.drag", self.plot_drag())
    		.on("touchstart.drag", self.plot_drag());

            self.plot.call(d3.behavior.zoom().y(self.y)
				.on("zoom", function () {
				    self.redraw()();
				}))
				.on("dblclick.zoom", null)
				.on("wheel.zoom", function () {
				    return false;
				});

            this.svg = this.showchart.append("svg")
			.attr("top", 0)
			.attr("left", 0)
			.attr("width", this.size.width)
			.attr("height", this.size.height)
                .attr("viewBox", "-5 0 " + (this.size.width + 10) + " " + this.size.height)
			.attr("class", "chartDraggable");

            //Drag a draggable line on point
            this.svg.append("path")
			  .attr("class", "draggableLine")
			  .attr("d", this.line(this.points));

            // add Chart Title
            if (this.options.title) {
                this.showchart.append("text")
                    .attr("class", "axis-draft")
                    .text(this.options.title)
                    .attr("x", this.size.width / 2)
                    .attr("dy", "-0.8em")
                    .style("text-anchor", "middle");
            }

            // Add the x-axis label
            if (this.options.xlabel) {
                this.showchart.append("text")
                    .attr("class", "axis-title")
                    .text(this.options.xlabel)
                    .attr("x", this.size.width / 2)
                    .attr("y", this.size.height)
                    .attr("dy", "2.4em")
                    .style("text-anchor", "middle");
            }

            // add y-axis label
            if (this.options.ylabel) {
                this.showchart.append("g").append("text")
                    .attr("class", "axis-title")
                    .text(this.options.ylabel)
                    .style("text-anchor", "middle")
                    .attr("transform", "translate(" + -40 + " " + this.size.height / 2 + ") rotate(-90)");
            }

            //Add legend
            var legend = self.showLegends.append("g")
			  .attr("class", "legendDraft")
			  //.attr("x", this.cx + 200)
			  //.attr("y", 0)
			  .attr("height", 100)
			  .attr("width", 100);

            legend.selectAll("g")
				.data(legendData, function (d, i) {
				    return d;
				})
				.enter()
				.append("g")
				.each(function (d, i) {
				    var padding = 18;
                    var legendRowIndex = 1;
                    var yDist = 0;
                    var xDist = 0;
				    if (i === 0)
				        return false;

                    if (i % 2 == 0) {
                        xDist += 300;
                    }
                    else {
                        xDist = 0;
                    }

                    if ((i == legendRowIndex) || (i == (legendRowIndex + 1))) {
                        yDist = legendRowIndex;
                    }
                    else {
                        legendRowIndex++;
                        yDist = legendRowIndex;
                    }

				    var g = d3.select(this);

				    if (i === 1) {
				        //Create legend for triangle
				        g.append("path")
					      .attr("class", "trianglePoint")
					      .attr("d", d3.svg.symbol().type("triangle-up").size(4))
                            .attr("transform", function (d) { return "translate(" + (self.cxLegend + padding + xDist) + "," + (i * 25 + 2) + ")"; })
					      .style("fill", legendColor[i - 1]);
				    } else if (i === 2) {
				        //Create legend for circle
				        g.append("circle")
                            .attr("cx", self.cxLegend + padding + xDist)
                            .attr("cy", yDist * 25 + 2)
							.attr("r", 3)
							.attr("class", "circleDraft")
							.style("stroke", legendColor[i - 1]);

				        g.append("line")
                            .attr("x1", self.cxLegend + 28 + xDist)
                            .attr("x2", self.cxLegend + 7 + xDist)
							.attr("stroke-width", 2)
							.attr("stroke", "#dc3912")
                            .attr("transform", function (d) { return "translate(" + 0 + "," + (yDist * 25 + 2) + ")"; })
				    } else if (i === 3) {
				        //Create legend for square
				        g.append("rect")
                            .attr("x", self.cxLegend + padding + xDist)
                            .attr("y", yDist * 25)
							.attr("width", 3)
							.attr("height", 3)
							.attr("class", "squarePoint")
							.style("stroke", legendColor[i - 1]);
				    } else if (i === 4) {
				        //Create legend for draggable line
				        g.append("line")
                            .attr("x1", self.cxLegend + 28 + xDist)
                            .attr("x2", self.cxLegend + 7 + xDist)
							.attr("stroke-width", 2)
							.attr("stroke", legendColor[i - 1])
                            .attr("transform", function (d) { return "translate(" + 0 + "," + (yDist * 25 + 2) + ")"; })
				    }

				    g.append("text")
                        .attr("x", self.cxLegend + 35 + xDist)
                        .attr("y", yDist * 25 + 6)
						.attr("width", 50)
						.attr("height", 30)
						.style("fill", i !== 4 ? "#171580" : "#000")
                        .style("text-decoration", i !== 4 ? "underline" : "none")
						.style("cursor", i !== 4 ? "pointer" : "default")
						.attr("class", "legendText")
						.text(d.title)
                        .on("click", self.shiftDraggable(i));
				});

            //Create button
            this.buttonGroup = self.showchart.append("g")
				.attr("class", "buttonGroup")
				//.attr("x", this.cx + 50)
				//.attr("y", this.cy - 100)
				.attr("height", 100)
				.attr("width", 100);

            this.buttonGroup.append("text")
				.attr('font-family', 'FontAwesome')
			    .attr("x", this.cx - 25)
				.attr("y", this.cy - 175)
				.attr("width", 50)
				.attr("class", "moveUp")
			    .text(function (d) { return '\uf151' })
			    .on("click", self.movePointUp());

            this.buttonGroup.append("text")
				.attr('font-family', 'FontAwesome')
			    .attr("x", this.cx - 25)
				.attr("y", this.cy - 125)
				.attr("width", 50)
				.attr("class", "moveDown")
			    .text(function (d) { return '\uf150' })
			    .on("click", self.movePointDown());

            d3.select(this.chart)
                .on("mousemove.drag", self.mousemove())
                .on("touchmove.drag", self.mousemove())
                .on("mouseup.drag", self.mouseup())
                .on("touchend.drag", self.mouseup());
                //.call(self.shiftDraggable(2));

            vm.chart = this; // add chart to model

            this.redraw()();
        };

        this.createBenchmarkD3.prototype.plot_drag = function plot_drag() {
            var self = this;
            return function () {
                registerKeyboardHandler(self.keydown());
                d3.select('body').style("cursor", "move");
                if (d3.event.altKey) {
                    var p = d3.svg.mouse(self.showchart.node());
                    var newpoint = {};
                    newpoint.x = self.x.invert(Math.max(0, Math.min(self.size.width, p[0])));
                    newpoint.y = self.y.invert(Math.max(0, Math.min(self.size.height, p[1])));
                    self.points.push(newpoint);
                    self.points.sort(function (a, b) {
                        if (a.x < b.x) { return -1 };
                        if (a.x > b.x) { return 1 };
                        return 0;
                    });
                    self.selected = newpoint;
                    self.update();
                    d3.event.preventDefault();
                    d3.event.stopPropagation();
                }
            }
        };

        this.createBenchmarkD3.prototype.update = function update() {
            var self = this;
            var lines = this.showchart.select("path").attr("d", this.line(this.points));

            var circle, circleWithoutDrag, squarePoint, trianglePoint;

            //Delete line if exists
            if (self.svg.selectAll(".circleLine")) {
                self.svg.selectAll(".circleLine").remove();
            }
            //Draw circle line
            self.svg.append("path")
				  .attr("class", "circleLine")
				  .attr("d", self.circleLine(self.circles));


            this.svg.selectAll(".circleDraggbleGroup").data(this.points, function (d) { return d }).exit().remove();

            circle = this.showchart.select("svg").append("g").attr("class", "circleDraggbleGroup")
                .selectAll("circle")
                .data(this.points, function (d) { return d; });

            circle.enter().append("circle")
                .attr("cx", function (d) { return self.x(d.x); })
                .attr("cy", function (d) { return self.y(d.y); })
                .attr("r", 5.0)
                .attr("class", "draggableCircle")
                .style("stroke", legendColor[0])
                .style("cursor", "ns-resize")
                .on("mousedown.drag", self.datapoint_drag())
                .on("touchstart.drag", self.datapoint_drag());


            // Remove if it is already exist and Circle point on svg
            this.svg.selectAll(".circleGroup").data(this.circles, function (d) { return d }).exit().remove();

            circleWithoutDrag = this.svg.append("g").attr("class", "circleGroup")
              .selectAll("cirlce")
              .data(this.circles, function (d) { return d });

            circleWithoutDrag.enter()
                .append("circle")
                .attr("cx", function (d) { return self.x(d.x); })
                .attr("cy", function (d) { return self.y(d.y); })
                .attr("r", 3.0)
                .attr("class", "lineCircle")
                .style("stroke", "#4682b4");


            //remove if it already exisit and Square Point on svg
            this.svg.selectAll(".squareGroup").data(this.square, function (d) { return d }).exit().remove();

            squarePoint = this.svg.append("g").attr("class", "squareGroup")
              .selectAll("rect")
              .data(this.square, function (d) { return d });

            squarePoint.enter()
                .append("rect")
                .attr("x", function (d) { return self.x(d.x); })
                .attr("y", function (d) { return self.y(d.y); })
                .attr("width", 3)
                .attr("height", 3)
                .attr("class", "squarePoint")
                .style("fill", "#ff9900");

            squarePoint.exit().remove();


            //Remove if it already exist and Triangle Point on svg
            this.svg.selectAll(".trianlgeGroup").data(this.triangle, function (d) { return d }).exit().remove();

            trianglePoint = this.svg.append("g").attr("class", "trianlgeGroup")
              .selectAll(".trianglePoint")
              .data(this.triangle, function (d) { return d });

            trianglePoint.enter()
                .append("path")
                .attr("class", "trianglePoint")
                .attr("d", d3.svg.symbol().type("triangle-up").size(4))
                .attr("transform", function (d) { return "translate(" + self.x(d.x) + "," + self.y(d.y) + ")"; })

            trianglePoint.exit().remove();

            if (d3.event && d3.event.keyCode) {
                d3.event.preventDefault();
                d3.event.stopPropagation();
            }
        };

        this.createBenchmarkD3.prototype.datapoint_drag = function datapoint_drag() {
            var self = this;
            return function (d) {
                registerKeyboardHandler(self.keydown());
                document.onselectstart = function () { return false; };
                self.selected = self.dragged = d;               
                self.update();
            }
        };

        this.createBenchmarkD3.prototype.mousemove = function mousemove() {
            var self = this;
            return function () {
                var p = d3.mouse(self.showchart[0][0]),
                    t = d3.event.changedTouches;

                if (self.dragged) {
                    self.dragged.y = self.y.invert(Math.max(0, Math.min(self.size.height, p[1])));
                    self.update();
                };
                if (!isNaN(self.downx)) {
                    d3.select('body').style("cursor", "ew-resize");
                    var rupx = self.x.invert(p[0]),
                        xaxis1 = self.x.domain()[0],
                        xaxis2 = self.x.domain()[1],
                        xextent = xaxis2 - xaxis1;
                    if (rupx != 0) {
                        var changex, new_domain;
                        changex = self.downx / rupx;
                        new_domain = [xaxis1, xaxis1 + (xextent * changex)];
                        self.x.domain(new_domain);
                        self.redraw()();
                    }
                    d3.event.preventDefault();
                    d3.event.stopPropagation();
                };
                if (!isNaN(self.downy)) {
                    d3.select('body').style("cursor", "ns-resize");
                    var rupy = self.y.invert(p[1]),
                        yaxis1 = self.y.domain()[1],
                        yaxis2 = self.y.domain()[0],
                        yextent = yaxis2 - yaxis1;
                    if (rupy != 0) {
                        var changey, new_domain;
                        changey = self.downy / rupy;
                        new_domain = [yaxis1 + (yextent * changey), yaxis1];
                        self.y.domain(new_domain);
                        self.redraw()();
                    }
                    d3.event.preventDefault();
                    d3.event.stopPropagation();
                }
            }
        };

        this.createBenchmarkD3.prototype.mouseup = function mouseup() {
            var self = this;
            return function () {
                document.onselectstart = function () { return true; };
                d3.select('body').style("cursor", "auto");
                d3.select('body').style("cursor", "auto");
                if (!isNaN(self.downx)) {
                    self.redraw()();
                    self.downx = Math.NaN;
                    d3.event.preventDefault();
                    d3.event.stopPropagation();
                };
                if (!isNaN(self.downy)) {
                    self.redraw()();
                    self.downy = Math.NaN;
                    d3.event.preventDefault();
                    d3.event.stopPropagation();
                }                                
                if (self.dragged) {                    
                    self.dragged = null;
                }
            }
        };

        this.createBenchmarkD3.prototype.keydown = function keydown() {
            var self = this;
            return function () {
                if (!self.selected) return;
                switch (d3.event.keyCode) {
                    case 8: // backspace
                    case 46: { // delete
                        var i = self.points.indexOf(self.selected);
                        self.points.splice(i, 1);
                        self.selected = self.points.length ? self.points[i > 0 ? i - 1 : 0] : null;
                        self.update();
                        break;
                    }
                }
            }
        };

        this.createBenchmarkD3.prototype.redraw = function redraw() {
            var self = this,
                  //weeks = ["2d", "w1", "w2", "w3", "w4", "w5", "w6", "w7", "w8", "w9"
                  //    , "w10","w11", "w12", "w13", "w14", "w15", "w16", "w17", "w18", "w19"
                  //];

            weeks = ["2d", "w1", "w2", "w3", "w4", "w5", "w6", "w7", "w8", "w9"];

            return function () {
                var tx = function (d) {
                    return "translate(" + self.x(d) + ",0)";
                },
                ty = function (d) {
                    return "translate(0," + self.y(d) + ")";
                },
                stroke = function (d) {
                    return d ? "#ccc" : "#666";
                },
                fx = self.x.tickFormat(function (d, i) {
                    return weeks[i]
                }),
                fy = self.y.tickFormat(10);

                // Regenerate x-ticks…
                var gx = self.showchart.selectAll("g.x")
                    .data(self.x.ticks(10), String)
                    .attr("transform", tx);

                //gx.select("text").text(fx);

                var gxe = gx.enter().insert("g", "a")
                    .attr("class", "x")
                    .attr("transform", tx);

                gxe.append("line")
                    //.attr("stroke", stroke)
                    .attr("y1", 0)
                    .attr("y2", self.size.height);

                gxe.append("text")
                    .attr("class", "axis-ticks")
                    .attr("y", self.size.height)
                    .attr("dy", "1em")
                    .attr("text-anchor", "middle")
                    .text(function (d, i) { return weeks[i] });
                //.on("mouseover", function(d) { d3.select(this).style("font-weight", "bold");})
                //.on("mouseout",  function(d) { d3.select(this).style("font-weight", "bold");})
                //.on("mousedown.drag",  self.xaxis_drag())
                //.on("touchstart.drag", self.xaxis_drag());

                gx.exit().remove();

                // Regenerate y-ticks…
                var gy = self.showchart.selectAll("g.y")
                    .data(self.y.ticks(5), String)
                    .attr("transform", ty);

                gy.select("text")
                    .text(fy);

                var gye = gy.enter().insert("g", "a")
                    .attr("class", "y")
                    .attr("transform", ty)
                    .attr("background-fill", "#FFEEB6");

                gye.append("line")
                    .attr("stroke", '#afafaf')
                    .attr("stroke-width", "0.5")
                    .attr("x1", 0)
                    .attr("x2", (self.size.width - 50));

                gye.append("text")
                    .attr("class", "axis-ticks")
                    .attr("x", -3)
                    .attr("dy", ".35em")
                    .attr("text-anchor", "end")
                    .text(fy);
                //.on("mouseover", function(d) { d3.select(this).style("font-weight", "bold");})
                //.on("mouseout",  function(d) { d3.select(this).style("font-weight", "bold");})

                gy.exit().remove();

                self.update();
            }
        };

        this.createBenchmarkD3.prototype.xaxis_drag = function xaxis_drag() {
            return;
        };

        this.createBenchmarkD3.prototype.yaxis_drag = function yaxis_drag(d) {
            return;
        };

        this.createBenchmarkD3.prototype.movePointUp = function movePointUp() {
            var self = this, yMax = 20;
            return function () {

                self.points = d3.range(self.points.length).map(function (i) {
                    return {
                        x: (self.points[i].x),
                        y: (Math.round(self.points[i].y) + 1)
                    }
                }, self);

                self.update();

                d3.event.preventDefault();
                d3.event.stopPropagation();
            }
        };

        this.createBenchmarkD3.prototype.movePointDown = function movePointDown() {
            var self = this, yMin = 0;
            return function () {

                self.points = d3.range(self.points.length).map(function (i) {
                    return {
                        x: (self.points[i].x),
                        y: (self.points[i].y > yMin ? Math.round(self.points[i].y) - 1 : Math.round(self.points[i].y))
                    }
                }, self);

                self.update();

                d3.event.preventDefault();
                d3.event.stopPropagation();
            }
        };

        this.createBenchmarkD3.prototype.shiftDraggable = function shiftDraggable(i) {
            var self = this;


            return function () {

                var arr = [];

                if (i === 4) {
                    return false;
                } else if (i === 1) {
                    //Triangle Point Row
                    arr = self.triangle;
                } else if (i === 2) {
                    //Line Row
                    arr = self.circles;
                } else if (i === 3) {
                    //Square point Row
                    arr = self.square;
                }

                //Update the draggable points
                self.points = d3.range(arr.length).map(function (i) {
                    return {
                        x: (arr[i].x),
                        y: (arr[i].y)
                    }
                }, self);

                $timeout(function () {
                    self.update();

                    //d3.event.preventDefault();
                    //d3.event.stopPropagation();
                }, 100);
            };
        };

        this.createBenchmark = function createBenchmark(ele) {
            var legends = {};
            var data, chart;

            legends = this.prepareChartOptions(forecastModel.BenchMarkChartData);

            data = new google.visualization.DataTable();
            legends.forEach(function (value) {
                data.addColumn(value.dataType, value.title);
            });
            data.addRows(vm.chartOptions.arrData);
            chart = new google.visualization.LineChart(ele); // Table
            chart.draw(data, vm.chartOptions.options);
        };

        this.prepareChartOptions = function prepareChartOptions(data) {
            if (typeof data === 'undefined')
                return false;

            vm.chartOptions.options.title = data.chartTitle;
            vm.chartOptions.options.vAxis.title = data.hAxisTitle;
            vm.chartOptions.options.hAxis.title = data.vAxisTitle;
            vm.chartOptions.arrData = data.chartData.arrData;
            return data.legends;
        };

        function registerKeyboardHandler(callback) {
            var callback = callback;
            d3.select(window).on("keydown", callback);
        };

        this.drawBenchmarkD3 = function drawBenchmarkD3(fmsId, circle) {
            // these to stor the current active circle and FMSId
            vm.circle = circle;
            vm.fmsId = fmsId;
            var deferred = $q.defer();

            $http({
                url: enumApp.url.draftUrl + 'forecast/' + fmsId + '/' + circle,
                method: "GET"
            })
			.success(function (data) {
			    deferred.resolve(data);
			    var xMax, graph,
				yMax;
			    chartData = data.forecastData;
			    vm.userForecast = data.userForecasts;
			    //xMax = forecastModel.BenchMarkChartData.chartData.arrData.length;

			    graph = new vm.createBenchmarkD3("d3BenchmarkChart", {
			        "xmax": data.forecastData.length - 1, "xmin": 0, //Should be length of array
			        "ymax": data.maxValue, "ymin": 0, //Should get calculated from json data
			        "title": " ",
			        "xlabel": "Weken",
			        "ylabel": "Aantal sollicitanten",
			        "default": "3"
			    });
			})
			.error(function () {
			    deferred.reject("Failed to get forecast data");
			});
        }

        this.addWidthsToPopover = function addWidthsToPopover() {
            $timeout(function () {
                angular.element('.progress-bar')
				.css("width",
					 function () {
					     return $(this).attr("aria-valuenow") + "%";
					 }
				 )
            });
        }

    }
})();
