(function(){
	'use strict';

	angular.module('publiceren.module', []);
})();