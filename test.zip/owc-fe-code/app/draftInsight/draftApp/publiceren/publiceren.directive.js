// (function(){
// 	'use strict';

// 	angular.module('publicatieInhoud.module')
// 		.controller('publicatieInhoudCntl', publicatieInhoudCntl);

// 	publicatieInhoudCntl.$inject = [];

// 	function publicatieInhoudCntl(){

// 	} 
// })();
