(function () {
    'use strict';

    angular.module('publiceren.module')
		.controller('publicerenCntl', publicerenCntl);

    publicerenCntl.$inject = ['$timeout', '$rootScope', 'publicerenService', 'publicatieInhoudService', 'draftAppService', '$state', '$scope', '$interval'];

    function publicerenCntl($timeout, $rootScope, publicerenService, publicatieInhoudService, draftAppService, $state, $scope, $interval) {
        var vm = this;

        activate();

        vm.openPopup = openPopup;
        vm.openPopupSection = openPopupSection;
        vm.removeConceptenPublicaties = removeConceptenPublicaties;
        vm.duplicateConceptenPublicaties = duplicateConceptenPublicaties;
        vm.offlinePublication = offlinePublication;
        vm.checkValidConcept = checkValidConcept;
        vm.getPublicatieStatusText = getPublicatieStatusText;
        vm.moment = moment;
        vm.formatDateFormat = formatDateFormat;
        vm.date = new moment();
        vm.noOfDays = noOfDays;

        var fmsId = $state.params.fmsId;
        if (fmsId) {
            draftAppService.getVacature(fmsId, true, "Publiceren");
        }
        $scope.$on('vacatureFetched', function (event, vacature) {
            vm.vacature = vacature;
            vm.publicatieInhoundDataPs = vm.vacature.publicatieInhoud.publications;
            vm.publicatieInhoundDataCs = vm.vacature.publicatieInhoud.drafts;
        }, true);

        /////////////////////

        function activate() {
            draftAppService.initPopover('.btn-popup');
            $timeout(function () {
                $('.dropdown-toggle').dropdown();
            });
            //this is for change tabs as this controller loads
            $rootScope.$broadcast('changeActiveTab', { str: 'mijnPublicaties.publiceren' });
        }

        function openPopup(str, data, index, screen) {
            $rootScope.$broadcast('callFunction', { str: str, data: data, index: index, screen: screen });
        }

        function openPopupSection(view, screen, data) {
            $rootScope.$broadcast('openPopupSection', { 'view': view, 'screen': screen, 'data': data });
        }

        function removeConceptenPublicaties(str, data, index) {
            if (str === 'Publicates') {
                vm.publicatieInhoundDataPs.splice(index, 1);
            } else if (str === 'Concept') {
                vm.publicatieInhoundDataCs.splice(index, 1);
            }
        }

        function duplicateConceptenPublicaties(str, data, obj) {
            var conceptsLength = vm.publicatieInhoundDataCs.length;
            var publicatesConcept = data;
            var publicatieData = angular.copy(obj);
            publicatieData.isOffline = null;
            if (conceptsLength > 0)
                publicatesConcept = publicatesConcept.replace('1', '') + (parseInt(vm.publicatieInhoundDataCs[conceptsLength - 1].publicatieCircle.replace('C', '')) + 1);

            publicatieData.publicatieCircle = publicatesConcept;
            publicatieData.advices = null;
            publicatieData.startDate = null;
            publicatieData.endDate = null;
            publicatieData.vandaag = null;
            publicatieData.afsluiting = null;
            publicatieData.firstPublishDate = null;
            publicatieData.publishDate = null;
            publicatieData.igbErrorMessage = null;
            publicatieData.publicatieViews = 0;
            publicatieData.publicatieSollicitaties = 0;
            publicatieData.updateDate = moment.tz(new Date(), "Europe/Amsterdam").format('DD-MM-YYYY [om] HH:mm');
            publicatieData.noOfDays = 0;
            publicatieData.closeType = 'FmsClosed';
            publicatieData.publicatieStatusText = "concept";
            publicatieData.channels = null;
            publicatieData.publicationUrl = null;
            vm.vacature.publicatieInhoud.drafts.push(publicatieData);
        }

        function offlinePublication(publicatie) {
            publicatie.isOffline = true;
            publicatie.advices = null;
            publicatie.publicatieStatusText = "offline";
        }

        function getPublicatieStatusText(publicatie) {
            var isDefinded = angular.isDefined(vm.vacature);
            if (!isDefinded) return;

            var publicatieStatusText = '';

            var isVacatureOffline = vm.vacature.isOffline;
            var isOffline = publicatie.isOffline;
            var startDate = moment(publicatie.vandaag, 'DD/MM/YYYY hh:mm');
            var endDate = moment(publicatie.afsluiting, 'DD/MM/YYYY hh:mm');
            var currentTime = moment.tz(new Date(), "Europe/Amsterdam");

            if (!isVacatureOffline && startDate <= currentTime && endDate >= currentTime && !isOffline) {
                var validateObj = checkValidConcept(publicatie);
                if (validateObj.isValidPub && publicatie.publishDate != null) {
                    publicatieStatusText = "Live!";
                } else {
                    publicatieStatusText = "in afwachting";
                }
            }

            else if (isVacatureOffline || isOffline || (startDate < currentTime && endDate < currentTime)) {
                publicatieStatusText = "offline";
            }

            else if (startDate > currentTime && endDate > currentTime) {
                publicatieStatusText = "gepland";
            }

            return publicatieStatusText;
        }

        function checkValidConcept(publicatie) {
            return publicatieInhoudService.checkValidConcept(publicatie, vm.vacature);
        }

        function formatDateFormat(date, isDate) {
            var formatedDate = isDate ? date : moment(date, 'DD/MM/YYYY HH:mm');
            return moment.tz(formatedDate, "Europe/Amsterdam").format('DD-MM-YYYY [om] HH:mm');
        }

        function noOfDays(date, type, format) {
            switch (type) {
                case 'C':
                    format = 'DD-MM-YYYY [om] HH:mm';
                    if (!date) {
                        date = moment.tz(new Date(), "Europe/Amsterdam").format('DD-MM-YYYY');
                    }
                    break;

                    // 2017-03-22T16:04:42.623
                case 'P':
                    format = format || 'YYYY-MM-DD[T]HH:mm:ss';
                    break;

                default:
            }

            var currentTime = moment.tz(new Date(), "Europe/Amsterdam").format('DD-MM-YYYY');
            var secondDate = moment(date, format).format('DD-MM-YYYY');
            var days = moment(currentTime, 'DD-MM-YYYY').diff(moment(secondDate, 'DD-MM-YYYY'), 'days');
            return days;
        }
    }
})();
