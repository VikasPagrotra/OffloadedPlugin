(function(){
	'use strict';

	angular.module('publiceren.module')
		.service('publicerenService', publicerenService);

	publicerenService.$inject = ['$http', '$q', 'enumApp'];

	function publicerenService($http, $q, enumApp) {
	    var service,
	        analyzerUrl = enumApp.url.analyzerUrl;

		service = {
			getUrlActueelVerkeerData: getUrlActueelVerkeerData,
			dateParser : dateParser,
			getJobViews : getJobViews,
			resolveMapData : resolveMapData
		}

		return service;
 
		////////////////////////////////////////////////////

		function getUrlActueelVerkeerData(url, isFlag, start, end){
			var deffered = $q.defer(),
				jobId = _getJobId(url);

			if(!isFlag){
				jobId = "?JobId=" + jobId + "&lastndays=15";
			}else{
				jobId = "?JobId=" + jobId + "&startdate=" + start + "&enddate=" + end;
			}

			$http({
			    url: enumApp.url.draftUrl + 'JobViewAndApplication' + jobId,
				method: "GET"
			})
			.success(function(data){
				deffered.resolve(data);
			})
			.error(function(){
				//deffered.reject("Failed to get Analyzed data");
				var data = {"chartLegends": [{"title": "Date","dataType": "date"},{"title": "JobViews","dataType": "number"},{"title": "JobApplications","dataType": "number"}],"chartData": {"arrData": [["20160121",11,2],["20160127",5,0],["20160125",10,1],["20160117",2,1],["20160122",3,0],["20160123",1,0],["20160128",4,0],["20160120",1,0],["20160126",2,1],["20160130",2,0]]},"tableColumns": [{"title": "Source","dataType": "string"},{"title": "JobViews","dataType": "number"},{"title": "JobApplications","dataType": "number"},{"title": "Entry","dataType": "number"},{"title": "BounceRate","dataType": "string"},{"title": "TimeOnPage","dataType": "string"}],"tableData": {"arrData": [["",41,5,9,"20.37%","00:05:09"],["(direct) / (none)",3,1,1,"0%","00:01:06"],["dub129.mail.live.com / referral",1,0,0,"0%","00:01:13"],["facebook.com / social",1,0,0,"0%","00:00:00"],["google / organic",19,0,0,"0%","00:00:42"],["indeed.nl / referral",7,2,2,"50%","00:00:46"],["job-alarm / email",4,0,3,"33.33%","00:00:05"],["jobbsquare / referral",1,1,0,"0%","00:00:17"],["olympia-jobapplicationprediction-test.azurewebsites.net / referral",2,0,2,"100%","00:00:00"],["uitzendbureau.nl / referral",2,1,1,"0%","00:00:59"],["werk.nl / referral",1,0,0,"0%","00:00:00"]]}};
				deffered.resolve(data);
			});

			return deffered.promise;
		}

		function dateParser(dateTimeToParse, format){
			if(typeof dateTimeToParse === 'undefined')
				return false;

			var parsed = moment(dateTimeToParse).format("DDMMYYYY");
			return parsed;
		}

		function _getJobId(url) {
		    if (url == undefined) return null;

			var jobId = "";
			if(url.toLowerCase().indexOf("v-") != -1){
				jobId = url.substring(url.toLowerCase().indexOf("v-"), url.length);
				jobId = jobId.substring(2, jobId.indexOf("/"));
			}
			return jobId;
		}

		function getJobViews(url, startDate, endDate) {
			var jobId = _getJobId(url);
			var deferred = $q.defer();

			$http({
				url: analyzerUrl + 'GetJobViews',
				method: "GET",
				params: {
					jobId: jobId,
					startDate: startDate,
					endDate: endDate
				}
			})
					.success(function (data) {
						deferred.resolve(data);
					})
					.error(function () {
						deferred.reject("Failed to get Analyzed data");
					});

			return deferred.promise;
		}

		function resolveMapData(data){
				// the location for netherlands
				var myLatLng = {lat: 52.144564, lng: 5.698177};
				var markers = [];

				var map = new google.maps.Map(document.getElementById('divMap'), {
						zoom: 7,
						center:  myLatLng
				});

				for (var i = 0; i < data.length; i++) {
						var item = data[i];
						for (var j=0; j < item.count ; j++){
								var marker = new google.maps.Marker({
										position: item.location,
										title : "Job views: "+ item.count
								});
								markers.push(marker);
						}
				}

				var mcOptions = { gridSize: 30, maxZoom: 10, styles: [{
						url: '../assets/images/conv40.png',
						height: 36,
						width: 40,
						anchor: [6, 0],
						textColor: '#ffffff',
						textSize: 13
				}]};

				var markerCluster = new MarkerClusterer(map, markers, mcOptions);
		}

	}
})();
