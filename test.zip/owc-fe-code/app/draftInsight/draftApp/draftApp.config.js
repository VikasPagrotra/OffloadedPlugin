(function(){
	'use strict';

	angular.module('olympia-draftApp')
		.config(configManager);

	configManager.$inject = ['$stateProvider', '$urlRouterProvider', '$locationProvider'];

	function configManager($stateProvider, $urlRouterProvider, $locationProvider) {
		$stateProvider
			.state('mijnPublicaties', {
			    'url': '/mijnPublicaties/:fmsId',
			    'templateUrl': 'draftApp/mijnPublicaties/mijnPublicaties.html'
			})
            .state('mijnPublicaties.FMS', {
                'url': '/vacatures',
                templateUrl: 'draftApp/FMS/fms.html',
                controller: 'fmsCntl',
                controllerAs: 'vModel',
                data: { name: 'overzicht' }
            })
            .state('mijnPublicaties.vacature', {
				'url' : '/vacature',
				templateUrl: 'draftApp/FMSvacature/vacature.html',
				controller: 'fmsVacatureCntl',
   			    controllerAs: 'vModel',
				data: {name:'FMSvacature'}
			})
			.state('mijnPublicaties.opdracht', {
				'url' : '/opdracht',
				templateUrl: 'draftApp/opdracht/opdracht.html',
    			controller: 'opdrachtCntl',
    			controllerAs: 'vModel',
				data: {name: 'opdracht'}
			})
			.state('mijnPublicaties.keywords', {
				'url' : '/keywords',
				templateUrl: 'draftApp/keywords/keywords.html',
    			controller: 'keywordPlannerCntl',
    			controllerAs: 'vModel',
				data: {name: 'keywords'}
			})
			.state('mijnPublicaties.publicatieInhoud', {
				url: '/publicatieInhoud',
				templateUrl : 'draftApp/publicatieInhoud/publicatieInhoud.html',
				controller : 'publicatieInhoudCntl',
				controllerAs: 'vModel',
				data: {name: 'concepten'}
			})
			.state('mijnPublicaties.forecast', {
				url: '/forecast',
				templateUrl : 'draftApp/forecast/forecast.html',
				controller : 'forecastCntl',
				controllerAs: 'vModel',
				data: {name: 'forecast'}
			})
			.state('mijnPublicaties.instroom', {
				url: '/instroom',
				templateUrl : 'draftApp/instroom/instroom.html',
				controller : 'instroomCntl',
				controllerAs: 'vModel',
				data: {name: 'instroom management'}
			})
			.state('mijnPublicaties.publiceren', {
				url: '/publiceren',
				templateUrl : 'draftApp/publiceren/publiceren.html',
				controller : 'publicerenCntl',
				controllerAs: 'vModel',
				data: {name: 'publiceren'}
			})
            .state('mijnPublicaties.conceptsPreview', {
                url: '/concepts/:previewId-Concept-preview',
                templateUrl: 'draftApp/conceptsPreview/conceptsPreview.html',
                controller: 'conceptsPreviewCntl',
                controllerAs: 'vModel',
                data: { name: 'Concepts Preview' }
            })
			.state('vestigings', {
			    url: '/vestigings',
			    templateUrl: 'draftApp/vestigings/vestigings.html'
			})
            .state('vestigings.vestigingsOverzicht', {
                url: '/vestigingsOverzicht',
                templateUrl: 'draftApp/vestigingsOverzicht/vestigingsOverzicht.html',
                controller: 'vestigingsOverzichtCntl',
                controllerAs: 'vModel',
                data: { name: 'vestigings Overzicht' }
            })
            .state('vestigings.vindbaarheidOverzicht', {
                url: '/vindbaarheidOverzicht',
                templateUrl: 'draftApp/zichtbaarheidOverzicht/zichtbaarheidOverzicht.html',
                controller: 'zichtbaarheidOverzichtCntl',
                controllerAs: 'vModel',
                data: { name: 'Vindbaarheid overzicht' }
            })
		    .state('vestigings.conversieOverzicht', {
		        url: '/conversieOverzicht',
		        templateUrl: 'draftApp/conversieOverzicht/conversieOverzicht.html',
		        controller: 'conversieOverzichtCtrl',
		        controllerAs: 'vModel',
		        data: { name: 'Conversie Overzicht' }
		    })
            .state('userProfile', {
                url: '/userProfile',
                templateUrl: 'draftApp/users/profile.html',
                controller: 'userCtlr',
                controllerAs: 'vModel',
                data: { name: 'User profile' }
            })
	        .state('new', {
	            url: '/new',
	            templateUrl: 'draftApp/new/new.html',
	            controller: 'newCtlr',
	            controllerAs: 'vModel'
	        })
            .state('editVacature', {
	            url: '/edit/:fmsId',
	            templateUrl: 'draftApp/editVacature/edit.html',
	            controller: 'editCtlr',
	            controllerAs: 'vModel'
	        })
            .state('aanbodAnalyse', {
                url: '/aanbodAnalyse',
                templateUrl: 'draftApp/aanbodAnalyse/aanbodAnalyse.html',
                controller: 'aanbodAnalyseCntl',
                controllerAs: 'vModel',
                data: { name: 'Aanbod analyse' }
            });

		$urlRouterProvider.otherwise('/mijnPublicaties//vacatures');

		//$locationProvider.html5Mode({
		//    enabled: true
		//});
	}
})();
