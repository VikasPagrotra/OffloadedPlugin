(function () {
    'use strict';
    angular.module('instroom.module')
		.service('instroomService', instroomService);

    instroomService.$inject = ['instroomModel', '$http', '$q', 'enumApp', 'zichtbaarheidOverzichtService', '$interval', 'loaderService', '$timeout'];

    function instroomService(instroomModel, $http, $q, enumApp, zichtbaarheidOverzichtService, $interval, loaderService, $timeout) {

        //var apiUrl = 'http://olympia-jobapplicationprediction-api-test.azurewebsites.net/api/';

        this.suggestedQuestionToSave = [];
        this.questions = [];
        this.sendEmail = sendEmail;
        this.question = {
            'id': 200,
            "phrase": "",
            "answer1": null,
            "answer2": null,
            "correctAnswerNo": 1,
            "isDeleted": false
        };

        this.questions.push(angular.copy(this.question));

        this.suggestedQuestion = [
	        {
	            'id': 1,
	            'phrase': 'Woon je minder dan 20 kilometer van de arbeidsplaats?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 2,
	            'phrase': 'Heb je minimaal 2 jaar ervaring in een soortgelijke functie?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 3,
	            'phrase': 'Ben je fulltime beschikbaar?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 4,
	            'phrase': 'Ben je bereid in ploegendienst te werken?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 5,
	            'phrase': 'Ben je in het bezit van een geldig heftruckcertificaat?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 6,
	            'phrase': 'Beschik je over een afgeronde HBO opleiding?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 7,
	            'phrase': 'Beschik je over een afgeronde MBO opleiding?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 8,
	            'phrase': 'Kun je in het bezit komen van een VOG (Verklaring omtrent gedrag)?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 9,
	            'phrase': 'Heb je ervaring in het werken met Microsoft Office?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 10,
	            'phrase': 'Heb je ervaring in het werken met SAP?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 11,
                'phrase': 'Beheers je de Nederlandse taal in woord?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
                'id': 12,
                'phrase': 'Beheers je de Nederlandse taal in woord en geschrift?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 13,
	            'phrase': 'Beheers je de Engelse taal?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 14,
	            'phrase': 'Ben je in bezit van een rijbewijs B?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 15,
	            'phrase': 'Beschik je over eigen vervoer?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 16,
	            'phrase': 'Ben je in bezit van een geldig VCA certificaat?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 17,
	            'phrase': 'Ben je in bezit van een VAPRO diploma?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 18,
	            'phrase': 'Heb je ervaring in een commerciële functie?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 19,
	            'phrase': 'Ben je minimaal 24 uur per week beschikbaar?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        },
	        {
	            'id': 20,
	            'phrase': 'Ben je flexibel inzetbaar?',
	            "answer1": null,
	            "answer2": null,
	            'correctAnswerNo': 1,
	            'isDeleted': true
	        }
        ];

        this.campaign = {
            'startPeriode': '',
            'endPeriode': '',
            'spoedgeval': false,
            'toelichting': '',
            'vactures': [{ id: 'vactures1' }],
            'budgetten': [
                { 'check': false, 'name': 'Google CPC campange', 'startCost': 100, 'maxCost': 200 },
                { 'check': false, 'name': 'Indeed CPC campange', 'startCost': 100, 'maxCost': 200 },
                { 'check': false, 'name': 'Vacatures.nl CPC campange', 'startCost': 100, 'maxCost': 200 }
            ],
            'synoniemen': '',
            'locaties': [{ id: 'locaties1' }],
            'locatiesBeschrijving': ''
        }

        this.categoriesAssesment = ["Persoonlijkheid", "Vaardigheden", "Motivatie", "Interesses", "Cultuur", "Taal ", "Techniek", "Kantoor", "Marketing", "Sales", "Callcenter"]

        this.recommendations = [
			{
			    "id": 1111,
			    "image": "../assets/images/british-flag.jpg",
			    "title": "Engels",
			    "desc": "Basis Engelse vaardigheden"
			},
			{
			    "id": 1112,
			    "image": "../assets/images/excel.png",
			    "title": "Excel",
			    "desc": "Gevorderde Excel vaardigheden"
			},
			{
			    "id": 1113,
			    "image": "../assets/images/office-worker.png",
			    "title": "Kantoor",
			    "desc": "Junior kantoor vaardigheden"
			}
        ];

        this.kantoors = [
			{
			    "id": 1121,
			    "image": "../assets/images/outlook.png",
			    "title": "Outlook",
			    "desc": "Basis outlook"
			},
			{
			    "id": 1122,
			    "image": "../assets/images/excel.png",
			    "title": "Excel",
			    "desc": "Basis Excel"
			},
			{
			    "id": 1123,
			    "image": "../assets/images/telephone.png",
			    "title": "Telefoon",
			    "desc": "Telefoon etiquette"
			},
			{
			    "id": 1124,
			    "image": "../assets/images/powerpoint.png",
			    "title": "PowerPoint",
			    "desc": "Gevorderden PowerPoint"
			},
			{
			    "id": 1125,
			    "image": "../assets/images/clock-fulltime.png",
			    "title": "Time",
			    "desc": "Time management"
			},
			{
			    "id": 1126,
			    "image": "../assets/images/stack-of-books.png",
			    "title": "Boekhouden",
			    "desc": "Basis boekhouding"
			}
        ];

        this.languages = [
			{
			    "id": 1131,
			    "image": "../assets/images/france.png",
			    "title": "Frans",
			    "desc": "Basis Frans"
			},
			{
			    "id": 1132,
			    "image": "../assets/images/dutch.png",
			    "title": "Duits",
			    "desc": "Zakelijk Duits"
			},
			{
			    "id": 1133,
			    "image": "../assets/images/italy.png",
			    "title": "Italiaans",
			    "desc": "Basis Italiaans"
			},
			{
			    "id": 1134,
			    "image": "../assets/images/spanish.png",
			    "title": "Spaans",
			    "desc": "Gevorderden Spaans"
			},
			{
			    "id": 1135,
			    "image": "../assets/images/america.png",
			    "title": "Amerikaans",
			    "desc": "Amerikaanse etiquette"
			},
			{
			    "id": 1136,
			    "image": "../assets/images/portugal.png",
			    "title": "Portugees",
			    "desc": "Basis portugees"
			}
        ];

        this.assessmentBucket = {
            "kantoors": [],
            "languages": [],
            "recommendations": []
        };

        this.removeNode = removeNode;

        this.addQuestion = addQuestion;
        this.generateUniqueId = generateUniqueId;
        this.addItemInBucket = addItemInBucket;
        this.LoadSavedItemInBucket = LoadSavedItemInBucket;
        this.removeItemFromAssessment = removeItemFromAssessment;

        this.projectId = 4;
        this.isChanged = true;
        this.resultPage = '1';

        this.getRankingResults = getRankingResults;
        this.getRankingCategories = zichtbaarheidOverzichtService.getRankingCategories;
        this.getRankingSubCategories = zichtbaarheidOverzichtService.getRankingSubCategories;
        this.GetRankingCities = zichtbaarheidOverzichtService.GetRankingCities;
        this.GetRankingVersions = zichtbaarheidOverzichtService.GetRankingVersions;
        this.onProjectIdChange = onProjectIdChange;

        ////////////////////////////

        //kanalenmix functions
        function onProjectIdChange(funcKeywords, fmsCity) {
            instroomModel.projectId = 4;
            instroomModel.isChanged = true;
            instroomModel.resultPage = '1';
            if (instroomModel.isChanged && !isNaN(instroomModel.projectId)) {
                // empty dropdowns
                instroomModel.rankingCategories = {};
                instroomModel.rankingSubCategories = {};
                instroomModel.rankingCites = {};
                instroomModel.rankingVersions = [];

                this.getRankingCategories(instroomModel.projectId).then(resolveRankingCategories, errorRankingCategories);
                this.getRankingSubCategories(instroomModel.projectId, '0').then(resolveRankingSubCategories, errorRankingSubCategories);
                this.GetRankingCities(instroomModel.projectId).then(resolveRankingCities, errorRankingCities);
                this.GetRankingVersions(instroomModel.projectId).then(resolveRankingVersions, errorRankingVersions);

                // reset DropDown binded Values to initialization values
                this.category = {};
                this.subCategory = {};
                this.city = '';
                this.version = '';
                instroomModel.resultPage = '1';
                instroomModel.isChanged = false;
                getRankingResultsAccordingToVacatureData(funcKeywords, fmsCity);
            }
        }

        function resolveRankingCategories(data) {
            if (data) {
                instroomModel.rankingCategories = data;
            }
        }

        function errorRankingCategories(error) {
            console.log(error);
        }

        function resolveRankingSubCategories(data) {
            if (data) {
                instroomModel.rankingSubCategories = data;
            }
        }

        function errorRankingSubCategories(error) {
            console.log(error);
        }

        function resolveRankingCities(data) {
            if (data) {
                instroomModel.rankingCites = data;
            }
        }

        function errorRankingCities(error) {
            console.log(error);
        }

        function resolveRankingVersions(data) {
            if (data) {
                instroomModel.rankingVersions = data;
            }
        }

        function errorRankingVersions(error) {
            console.log(error);
        }

        function getRankingResultsAccordingToVacatureData(funcKeywords, fmsCity) {
            var tempVacatureKeywords = angular.copy(funcKeywords);
            var categories = [];
            var cities = [];
            var vacatureCity = angular.copy(fmsCity);
            var highestVersion = '';
            var tempKeyword = ''; // used to get distinct keywords
            var rankingResultsInterval = $interval(function () {
                // if all data loaded
                if (instroomModel.rankingCategories.length > 0 && instroomModel.rankingCites.length > 0 && instroomModel.rankingVersions.length > 0) {
                    angular.forEach(tempVacatureKeywords, function (keyword, key) {
                        if (keyword.keyword != tempKeyword) {
                            angular.forEach(instroomModel.rankingCategories, function (category, key) {
                                if (category.categoryValue.toLowerCase() == keyword.keyword.toLowerCase()) {
                                    categories.push(category);
                                }
                            })
                            tempKeyword = keyword.keyword;
                        }
                    })
                    // get highest version
                    var highestPart1 = 0;
                    var highestPart2 = 0;
                    angular.forEach(instroomModel.rankingVersions, function (version, key) {
                        var trimedVersion = version.trim();
                        var versionParts = trimedVersion.split('-');
                        if (versionParts[1] > highestPart2 || (versionParts[1] == highestPart2 && versionParts[0] > highestPart1)) {
                            highestVersion = version;
                            highestPart1 = versionParts[0];
                            highestPart2 = versionParts[1]
                        }
                    })

                    // cities
                    angular.forEach(instroomModel.rankingCites, function (city, key) {
                        if (vacatureCity != null && vacatureCity.length > 0 && city.cityValue.toLowerCase() == vacatureCity.toLowerCase()) {
                            cities.push(city);
                        }
                    })
                    getRankingResults(categories, highestVersion, [], cities, instroomModel.projectId, instroomModel.resultPage)
                    $interval.cancel(rankingResultsInterval);
                }
            }, 1000);
        }

        function getRankingResults(categories, version, subCategories, cities, projectId, resultPage) {
            zichtbaarheidOverzichtService.getRankingResults(categories, version, subCategories, cities, projectId, resultPage).then(resolveRankingResults, errorRankingResults)
        }

        function resolveRankingResults(data) {
            if (data) {
                instroomModel.rankingResults = data;
                // preparing Chart Data
                var chartData = [];
                var headers = ['Domain', 'SeoPpc', 'Seo', 'Ppc', 'Potential'];
                chartData.push(headers);
                var chartRecords = 25;

                instroomModel.rankingResults = createDataForSpecificDoamins(instroomModel.rankingResults);

                if (instroomModel.rankingResults.length == 0) {
                    loaderService.toggleOverlayLoader(false);
                    return;
                }

                if (chartRecords > instroomModel.rankingResults.length)
                    chartRecords = instroomModel.rankingResults.length;

                for (var i = 0; i < chartRecords; i++) {
                    var obj = [instroomModel.rankingResults[i]['domain'], instroomModel.rankingResults[i]['seoPpc'], instroomModel.rankingResults[i]['seo']
                    , instroomModel.rankingResults[i]['ppc'], instroomModel.rankingResults[i]['potential']];
                    chartData.push(obj);
                }
                // draw chart if myChart element added to page to avoid undefined exception
                var googleChartInterval = $interval(function () {
                    if (document.getElementById('myChart') != null) {
                        zichtbaarheidOverzichtService.drawChart(chartData);
                        $interval.cancel(googleChartInterval);
                        loaderService.toggleOverlayLoader(false);
                    }
                }, 1000);
            }
        }

        function errorRankingResults(error) {
            console.log(error);
        }

        function createDataForSpecificDoamins(rankingresults) {
            var listOfDomains = ["12jobs.nl", "Adzuna.nl", "AlkmaarVacaturebank.nl", "AmersfoortVacaturebank.nl", "AmsterdamVacaturebank.nl", "ApeldoornVacaturebank.nl", "ArnhemVacaturebank.nl", "AssenVacaturebank.nl", "BredaVacaturebank.nl", "DenBoschVacaturebank.nl", "DenHaagVacaturebank.nl", "Digid.werk.nl", "EindhovenVacaturebank.nl", "GroningenVacaturebank.nl", "Indeed.nl", "Jobbird.com", "Jobbsquare.nl", "Jobrapido.com", "Joof.nl", "LeeuwardenVacaturebank.nl", "LelystadVacaturebank.nl", "MaastrichtVacaturebank.nl", "Monsterboard.nl", "NationaleVacaturebank.nl", "Njobs.nl", "Roc.nl", "RotterdamVacaturebank.nl", "Trovit.nl", "Twiglers.nl", "BanenMatch.nl", "Uitzendbureau.nl", "UtrechtVacaturebank.nl", "UWV.nl", "Werk.nl", "Vacant.nl", "Vacaturekrant.nl", "Vacatures.nl", "Werkzoeken.nl", "ZwolleVacaturebank.nl"],
                newrankingresults = [];
            angular.forEach(rankingresults, function (item) {
                angular.forEach(listOfDomains, function (i) {
                    if (item.domain == i.toLowerCase()) {
                        newrankingresults.push(item);
                    }
                });
            });

            return newrankingresults;
        }

        function addItemInBucket(data, bucketName, assessmentNumbers) {
            if (data.addActive == true) {
                this.assessmentBucket[bucketName].push(data);
                assessmentNumbers.push(data.id);
            } else {
                var obj = this.assessmentBucket[bucketName];
                var elementPos = obj.map(function (x) {
                    return x.title;
                }).indexOf(data.title);
                this.assessmentBucket[bucketName].splice(elementPos, 1);
                var idIndex = assessmentNumbers.indexOf(data.id);
                assessmentNumbers.splice(idIndex, 1)
            }
        }

        function LoadSavedItemInBucket(assessmentNumbers) {
            var current = this;
            current.assessmentBucket['recommendations'] = []; // to prevent add duplicate
            current.assessmentBucket['kantoors'] = []; // to prevent add duplicate
            current.assessmentBucket['languages'] = []; // to prevent add duplicate
            angular.forEach(assessmentNumbers, function (assessmentId, key) {
                var suggestedAssessments = [];
                var categoryName = '';
                var categoryNum = assessmentId.toString().substr(0, 3);
                switch (categoryNum) {
                    case '111':
                        suggestedAssessments = current.recommendations;
                        categoryName = 'recommendations';
                        break;

                    case '112':
                        suggestedAssessments = current.kantoors;
                        categoryName = 'kantoors';
                        break;

                    case '113':
                        suggestedAssessments = current.languages;
                        categoryName = 'languages';
                        break;
                }

                var assessment = findAssessmentAndIndex(suggestedAssessments, assessmentId);
                current.assessmentBucket[categoryName].push(assessment);
                suggestedAssessments[assessment.index].addActive = true;
            });
        }

        function findAssessmentAndIndex(assessmentsArray, assessmentId) {
            var result = {};
            angular.forEach(assessmentsArray, function (assessment, key) {
                if (assessment.id == assessmentId) {
                    result = assessmentsArray[key];
                    result.index = key;
                }
            })
            return result;
        }

        function removeItemFromAssessment(data, bucketName, assessmentNumbers) {
            data.addActive = false;
            var obj = this.assessmentBucket[bucketName];
            var elementPos = obj.map(function (x) {
                return x.title;
            }).indexOf(data.title);
            this.assessmentBucket[bucketName].splice(elementPos, 1);
            var idIndex = assessmentNumbers.indexOf(data.id);
            assessmentNumbers.splice(idIndex, 1)
        }

        function removeNode(arrObj, obj) {
            var strToCompare = obj.phrase,
                nodeToDelete;
                angular.forEach(arrObj, function (value, key) {
                    var strToCompareWith = value.phrase;
                    if (strToCompare === strToCompareWith) {
                        nodeToDelete = key;
                    }
                });

            arrObj.splice(nodeToDelete, 1);
        }

        function addQuestion(arrObj, obj) {
            arrObj.push(obj);
        }

        function sendEmail(sendMailObj, fmsId) {
            var deferred = $q.defer();
            $http({
                url: enumApp.url.draftUrl + 'sendCampaignRequesEmail/' + fmsId,
                method: "POST",
                data: sendMailObj
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function () {
                deferred.reject("Failed to Send mail");
            });

            return deferred.promise;
        }

        function generateUniqueId(obj, id) {
            var maxId = Math.max.apply(Math, obj.map(function (o) { return o.id; }));
            if (maxId < id)
                maxId = id;

            return maxId + 1;
        }
    }

    function drawChart(chartData) {
        if (chartData != undefined) {
            // Define the chart to be drawn.
            var data = google.visualization.arrayToDataTable(chartData);
            var options = {
                width: 900,
                height: 400,
                legend: { position: 'top', maxLines: 3 },
                colors: ['#000000', '#171580', 'gray', '#ff4400'],
                bar: { groupWidth: '40%' },
                isStacked: true,
                animation: {
                    duration: 1500,
                    easing: 'linear',
                    startup: true
                }
            };

            // Instantiate and draw the chart.
            var chart = new google.visualization.ColumnChart(document.getElementById('myChart'));
            chart.draw(data, options);
        }
    }
})();
