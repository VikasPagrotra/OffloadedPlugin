(function () {
    'use strict';
    angular.module('instroom.module')
        .directive('multiple', autoComplete);

    autoComplete.$inject = ['$timeout', '$compile', '$rootScope', '$window'];

    function autoComplete($timeout, $compile, $rootScope, $window) {
        var directive = {};

        directive.restrict = 'AE'; /* restrict this directive to elements */

        directive.scope = {
            'ngModel': '=',
            'manyselect': "@manyselect",
            'sortable': "@sortable",
            'minInputChar': "@minInputChar",
            'startwatcher': "@startwatcher"
        }

        directive.require = '?ngModel', // get a hold of NgModelController

        directive.compile = compile;

        return directive;

        function compile(element, attributes) {

            var linkFunction = function linkFunction($scope, element, attributes, ngModel) {

                (function ($) {
                    $.fn.extend({
                        select2_sortable: function () {
                            var select = $(this);
                            var mininputchar = attributes.mininputchar ? attributes.mininputchar : 0;

                            $(select).select2({
                                placeholder: "Maak een selectie",
                                width: '100%',
                                minimumInputLength: mininputchar,
                                createTag: function (params) {
                                    return undefined;
                                },
                                "language": {
                                    "noResults": function () {
                                        return "Geen resultaten gevonden";
                                    }
                                },
                                escapeMarkup: function (markup) {
                                    return markup;
                                }
                            }).on("select2:close", function () {
                                $window.focus();
                            });
                            if (attributes.sortable == "true") {
                                var ul = $(select).next('.select2-container').first('ul.select2-selection__rendered');
                                
                                ul.sortable({
                                    placeholder: 'ui-state-highlight',
                                    forcePlaceholderSize: true,
                                    items: 'li:not(.select2-search__field)',
                                    tolerance: 'pointer',
                                    stop: function () {
                                        $($(ul).find('.select2-selection__choice').get().reverse()).each(function () {
                                            var id = $(this).data('data').id;
                                            var option = select.find('option[value="' + id + '"]')[0];
                                            $(select).prepend(option);
                                        });

                                        var myVal = [];
                                        var newModel = [];
                                        $('li.select2-selection__choice').each(function (index) {
                                            var item = $(this).attr('title');
                                            myVal.push(item);
                                        });
                                        if (ngModel) {
                                            angular.forEach(myVal, function (item) {
                                                angular.forEach(ngModel.$viewValue, function(it) {
                                                    if (it.description == item) {
                                                        newModel.push({
                                                            "id": it.id,
                                                            "description": it.description
                                                        });
                                                    }
                                                });
                                            });
                                            $timeout(function () {
                                                ngModel.$setViewValue(newModel);
                                                ngModel.$render();
                                            });
                                        }
                                    },
                                    create: function (event, ui) {
                                        $timeout(function () {
                                            if (ngModel && ngModel.$viewValue) {
                                                var index = ngModel.$viewValue.length - 1;
                                                $($(ul).find('.select2-selection__choice').get().reverse()).each(function () {
                                                    var id = ngModel.$viewValue[index].id;
                                                    var option = select.find('option[value="' + id + '"]')[0];
                                                    $(select).prepend(option);
                                                    index--;
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        }
                    });
                }(jQuery));

                angular.element(element).select2_sortable({
                    placeholder: "Maak een selectie",
                    width: "100%"
                });

                var startWatcher = attributes.startwatcher == "false" ? attributes.startwatcher : true;

                if (startWatcher) {
                    $scope.$watch('ngModel', function (newValue, oldValue) {
                        if (oldValue !== null && (typeof oldValue != 'undefined' && typeof newValue != 'undefined') && attributes.manyselect == "true") {
                            if (oldValue.length > newValue.length) {
                                //delete
                                angular.element(element).select2_sortable({
                                    placeholder: "Maak een selectie",
                                    width: "100%"
                                });
                            } else {
                                //add
                                $timeout(function () {
                                    angular.element(element).select2_sortable({
                                        placeholder: "Maak een selectie",
                                        width: "100%"
                                    });
                                });
                            }
                        }

                    });
                }
            };

            return linkFunction;
        }
    }

})();
