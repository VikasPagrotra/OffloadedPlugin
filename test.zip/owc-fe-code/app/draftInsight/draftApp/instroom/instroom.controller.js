(function () {
    'use strict';
    angular.module('instroom.module')
		.controller('instroomCntl', instroomCntl);

    instroomCntl.$inject = ['instroomService', 'draftAppService', '$rootScope', 'instroomModel', '$interval', '$scope', '$state', 'zichtbaarheidOverzichtService', 'loaderService', 'coreService'];

    function instroomCntl(instroomService, draftAppService, $rootScope, instroomModel, $interval, $scope, $state, zichtbaarheidOverzichtService, loaderService, coreService) {
        var vm = this;
        vm.settings = instroomModel.settings;

        if (typeof (vm.settings) == "undefined") {
            draftAppService.getSettings().then(function (data) {
                vm.settings = {
                    companyName: data.CompanyName,
                    logoUrl: data.LogoUrl,
                    // instroom active features
                    activeInstroomFeatures: data.ActiveInstroomFeatures
                }
                instroomModel.settings = vm.settings;
            });
        }

        var fmsId = $state.params.fmsId;
        if (fmsId) {
            draftAppService.getVacature(fmsId, true, "Instroom");
        }

        //get user infor for chat and notification 
        draftAppService.getUserSession().then(function (data) {
            data.Avatar += "?v=" + Date.now();
            vm.userSession = data;
        });

        vm.chatEnabled = false;
        vm.notificationEnabled = false;
        vm.enabledModalName = instroomModel.enabledModalName;

        var count = 0;
        $scope.$on('vacatureFetched', function (event, vacature) {
            vm.vacature = vacature;

            vm.questionOption = 0;

            //User selected questions
            if (vm.vacature.instroom.preQuestions.questions == null || vm.vacature.instroom.preQuestions.questions.length == 0) {
                vm.vacature.instroom.preQuestions.questions = _.union(instroomService.questions, vm.vacature.instroom.preQuestions.questions);
            }
            vm.questionsTotal = vm.vacature.instroom.preQuestions.questions.length;

            instroomService.LoadSavedItemInBucket(vm.vacature.assessmentNumbers);

            // add custom template to instroom.chat if exists
            if (instroomModel.chatTemplate["custom"] !== null && vm.vacature.instroom.chat.template == "custom") {
                var customChatTemplate = {
                    "custom": {
                        "type": "custom",
                        "text": vm.vacature.instroom.chat.text
                    }
                };
                angular.extend(instroomModel.chatTemplate, customChatTemplate);
                vm.instroomChat = instroomModel.chatTemplate;
            }

            // get the selected template acording to the template stored in vacature object
            vm.selectedChatTemplate = angular.copy(vm.instroomChat[vm.vacature.instroom.chat.template]);
            vm.chatTemplateBackup = angular.copy(vm.selectedChatTemplate);

            // add custom template to instroom.notification if exists
            if (instroomModel.notificationTemplate["custom"] !== null && vm.vacature.instroom.notification.template == "custom") {
                var customNotifcationTemplate = {
                    "custom": {
                        "type": "custom",
                        "text": vm.vacature.instroom.notification.text
                    }
                };
                angular.extend(instroomModel.notificationTemplate, customNotifcationTemplate);
                vm.instroomNotification = instroomModel.notificationTemplate;
            }

            // get the selected template acording to the template stored in vacature object
            vm.selectedNotificationTemplate = angular.copy(vm.instroomNotification[vm.vacature.instroom.notification.template]);
            vm.notificationTemplateBackup = angular.copy(vm.selectedNotificationTemplate);
            count++;

            removeAlreadyAddedQuestionsOnInitilization();

            vm.chatEnabled = vm.vacature.instroom.chat.enabled;
            vm.notificationEnabled = vm.vacature.instroom.notification.enabled;
        }, true);

        vm.alert = {};

        vm.questionsTotal = 0;
        vm.returnPartial = returnPartial;

        vm.openPopup = openPopup;

        vm.addOneEmpytBox = addOneEmpytBox;

        activate();

        vm.deleteNode = deleteNode;

        vm.addQuestion = addQuestion;

        //vm.addSuggestQuestion = addSuggestQuestion;

        vm.instroomBedankpagina = instroomModel.emailTemplate;

        vm.addItemInBucket = addItemInBucket;
        vm.removeItemFromAssessment = removeItemFromAssessment;
        vm.assessmentBucket = instroomService.assessmentBucket;

        vm.changeChatTemplateContents = changeChatTemplateContents;
        vm.changeNotificationTemplateContents = changeNotificationTemplateContents;

        vm.instroomChat = instroomModel.chatTemplate;
        vm.instroomNotification = instroomModel.notificationTemplate;

        vm.sendEmail = sendEmail;

        //chat and notification
        vm.chatNotificationChange = chatNotificationChange;
        vm.submitChatNotificationChanges = submitChatNotificationChanges;

        $interval(function () {
            // chat
            if (!angular.equals(vm.selectedChatTemplate, vm.chatTemplateBackup)) {
                // before save change type to custom if user change any
                changeChatTemplateContents(false);
            }

            // notification
            if (!angular.equals(vm.selectedNotificationTemplate, vm.notificationTemplateBackup)) {
                // before save change type to custom if user change any
                changeNotificationTemplateContents(false);
            }
        }, 1000);
        /////////////////////////

        function activate() {
            draftAppService.initPopover('.btn-popup');

            //Array to save suggested question
            vm.suggestedQuestionToSave = instroomService.suggestedQuestionToSave;

            //List of suggested question
            vm.suggestedQuestion = instroomService.suggestedQuestion;

            //Campaign form data
            vm.campaign = instroomService.campaign;

            //categories data
            vm.categoriesAssesment = instroomService.categoriesAssesment;

            vm.recommendations = instroomService.recommendations;

            vm.kantoors = instroomService.kantoors;

            vm.languages = instroomService.languages;

            vm.vacatureChannels = draftAppService.vacatureChannels;

            //this is for change tabs as this controller loads
            $rootScope.$broadcast('changeActiveTab', { str: 'mijnPublicaties.instroom' });

        }

        //vm.onProjectIdChange();

        function getRankingResults(categories, version, subCategories, cities, projectId, resultPage) {
            zichtbaarheidOverzichtService.getRankingResults(categories, version, subCategories, cities, projectId, resultPage).then(resolveRankingResults, errorRankingResults)
        }

        function returnPartial(view) {
            if (typeof view === 'undefined' || view === '') {
                return;
            }
            return './draftApp/shared/partial/_' + view + '.html';
        }

        function openPopup(view, screen) {
            $rootScope.$broadcast('openPopupSection', { 'view': view, 'screen': screen });
        }

        function deleteNode(index, data, obj) {
            if (obj.length !== 1) {
                var foundElement = getFilterByValue(vm.suggestedQuestion, data.id);
                if (foundElement.length) {
                    foundElement[0].isDeleted = true;
                }
                obj.splice(index, 1);
                vm.questionsTotal -= 1;
            }
        }

        function removeAlreadyAddedQuestionsOnInitilization() {
            angular.forEach(vm.vacature.instroom.preQuestions.questions, function (value, key) {
                var foundElement = getFilterByValue(vm.suggestedQuestion, value.id);
                if (foundElement.length)
                    foundElement[0].isDeleted = false;
            })
        }

        function getFilterByValue(data, id) {
            return data.filter(
              function (data) {
                  return data.id == id
              }
            );
        }

        function addQuestion(obj) {
            if (vm.questionsTotal < 5) {
                obj.isDeleted = false;
                instroomService.addQuestion(vm.vacature.instroom.preQuestions.questions, angular.copy(obj));
                vm.questionsTotal += 1;
            } else {
                coreService.showalertMessage('vragen-alert');
            }
        }

        function addOneEmpytBox(obj) {
            if (vm.questionsTotal < 5) {
                var newQuestion = angular.copy(instroomService.question);
                newQuestion.id = instroomService.generateUniqueId(vm.vacature.instroom.preQuestions.questions, newQuestion.id);
                obj.push(newQuestion);
                vm.questionsTotal += 1;
            } else {
                coreService.showalertMessage('vragen-alert');
            }
        }

        function addItemInBucket(data, bucketName) {
            instroomService.addItemInBucket(data, bucketName, vm.vacature.assessmentNumbers);
        }

        function removeItemFromAssessment(data, bucketName) {
            instroomService.removeItemFromAssessment(data, bucketName, vm.vacature.assessmentNumbers);
        }

        function changeChatTemplateContents(selectionChanged) {
            if (!selectionChanged) {
                // selectionChanged = false means the user not changed the selection but change in content itself
                // change type to custom if not equal original content
                if (!angular.equals(vm.selectedChatTemplate, vm.instroomChat[vm.selectedChatTemplate.type])) {
                    vm.selectedChatTemplate.type = "custom";
                }
            }
            else {
                vm.selectedChatTemplate = angular.copy(vm.instroomChat[vm.selectedChatTemplate.type]);
            }

            // copy backup again
            vm.chatTemplateBackup = angular.copy(vm.selectedChatTemplate);

            vm.vacature.instroom.chat.template = vm.selectedChatTemplate.type;
            vm.vacature.instroom.chat.Text = vm.selectedChatTemplate.text;
        }

        function changeNotificationTemplateContents(selectionChanged) {
            if (!selectionChanged) {
                // selectionChanged = false means the user not changed the selection but change in content itself
                // change type to custom if not equal original content
                if (!angular.equals(vm.selectedNotificationTemplate, vm.instroomNotification[vm.selectedNotificationTemplate.type])) {
                    vm.selectedNotificationTemplate.type = "custom";
                }
            }
            else {
                vm.selectedNotificationTemplate = angular.copy(vm.instroomNotification[vm.selectedNotificationTemplate.type]);
            }

            // copy backup again
            vm.notificationTemplateBackup = angular.copy(vm.selectedNotificationTemplate);

            vm.vacature.instroom.notification.template = vm.selectedNotificationTemplate.type;
            vm.vacature.instroom.notification.Text = vm.selectedNotificationTemplate.text;
        }

        function sendEmail(valid) {
            $('#overlay').animate({ scrollTop: 0 }, 600);
            if (!valid) {
                $("#overlay-loader").removeClass('hidden');
                instroomService.sendEmail(vm.vacature.instroom.additionalPaidChannels, vm.vacature.fmsId).then(resolveEmailSendStatus);
            } else {
                vm.buttonStatus = false;
            }

        }

        function resolveEmailSendStatus(data) {
            vm.emailStatus = data;
            $("#overlay-loader").addClass('hidden');
            if (data) {
                vm.vacature.instroom.additionalPaidChannels.lastRequestDate = moment.tz(new Date(), "Europe/Amsterdam").format('DD-MM-YYYY');
            }
            $rootScope.$broadcast('removeTogglePopup', { data: 'remove-additionele' });
        }

        function chatNotificationChange(view) {
            vm.enabledModalName = instroomModel.enabledModalName = view;
            if (view == 'chat' && !vm.vacature.instroom.chat.enabled && vm.vacature.instroom.notification.enabled) {
                angular.element(document.getElementById("chatNotificationModal")).modal("show");
            } else if (view == 'notification' && vm.vacature.instroom.chat.enabled && !vm.vacature.instroom.notification.enabled) {
                angular.element(document.getElementById("chatNotificationModal")).modal("show");
            } else {
                vm.vacature.instroom.chat.enabled = vm.chatEnabled;
                vm.vacature.instroom.notification.enabled = vm.notificationEnabled;
            }
        }

        function submitChatNotificationChanges(status) {
            if (status == true) {
                if (instroomModel.enabledModalName == 'chat') {
                    vm.vacature.instroom.chat.enabled = true;
                    vm.vacature.instroom.notification.enabled = false;
                } else if (instroomModel.enabledModalName == 'notification') {
                    vm.vacature.instroom.chat.enabled = false;
                    vm.vacature.instroom.notification.enabled = true;
                }
            } else {
                vm.chatEnabled = vm.vacature.instroom.chat.enabled;
                vm.notificationEnabled = vm.vacature.instroom.notification.enabled;
            }
        }
    }
})();
