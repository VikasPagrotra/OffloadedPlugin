(function () {
    'use strict';
    angular.module('instroom.module')
		.service('instroomModel', instroomModel);

    instroomModel.$inject = ['$sce'];

    function instroomModel($sce) {
        this.suggestedQuestion = [
			'Woon je minder dan 20 kilometer van de arbeidsplaats?',
			'Heb je minimaal 2 jaar ervaring in een soortgelijke functie?',
			'Ben je bereid om ook in de avonden en in het weekend te werken?',
			'Kun je in het bezit komen van een VOG (Verklaring omtrent het Gedrag)?',
			'Ben je fulltime beschikbaar?',
			'Heb jij een afgeronde HLO-opleiding richting Analytische Chemie?',
			'Ben je bereid om in vakantieperiodes extra te werken?',
			'Heb je ervaring in de logistieke branche?',
			'Ben jij een echte aanpakker?'
        ];

        this.predefinedQuestions = [];
        this.allowedThankYouPlaceholders = ['m.FirstName', 'm.JobTitle', 'm.RecruiterEmail', 'm.Email', 'm.OfficePhone', 'm.OfficeName'];
        this.allowedConfirmationPlaceholders = ['m.FirstName', 'm.JobTitle', 'm.RecruiterEmail', 'm.OfficePhone', 'm.OfficeName', 'm.Email', 'r.FullName'];

        this.emailTemplate = {
            "standardTemplate": {
                "type": "standardTemplate",
                "pageTitle": "Bedankt voor je sollicitatie bij Olympia Uitzendbureau",
                "pageBody": "<p>Bedankt {m.FirstName},<br>voor je sollicitatie op de vacature ''{m.JobTitle}''. Wij hebben een bevestigingsmail gestuurd met daarin de door ons ontvangen gegevens.</p><p>Heb je nog vragen naar aanleiding van je sollicitatie dan kan je contact opnemen met {r.FullName} in Olympia Uitzendbureau {m.OfficeName} via {m.OfficePhone}.</p>",
                "pageRows": 7,
                "emailRows": 10,
                "emailTitle": "Je sollicitatie is verzonden",
                "emailBody": "Beste {m.FirstName},<br><br><p>Je hebt gesolliciteerd op de vacature <br>{m.JobTitle}.</p><p>We hebben je sollicitatie correct ontvangen en nemen hem in behandeling. Je krijgt zo snel mogelijk een reactie van ons.</p>"
            },
            "specifiekeResponseDatum": {
                "type": "specifiekeResponseDatum",
                "pageTitle": "",
                "pageBody": "",
                "pageRows": 3,
                "emailRows": 3,
                "emailTitle": "",
                "emailBody": ""
            },
            "OCCTemplate": {
                "type": "OCCTemplate",
                "pageTitle": "",
                "pageBody": "",
                "pageRows": 3,
                "emailRows": 15,
                "emailTitle": "Je sollicitatie is verzonden",
                "emailBody": "Beste {m.FirstName},<br><br><p>Je hebt gesolliciteerd op de vacature <br>{m.JobTitle}.</p><p>We hebben je sollicitatie correct ontvangen en nemen hem in behandeling. Je krijgt zo snel mogelijk een reactie van ons.</p>"
            }
        };

        this.chatTemplate = {
            "standardTemplate": {
                "type": "standardTemplate",
                "text": ""
            },
            "specifiekeResponseDatum": {
                "type": "specifiekeResponseDatum",
                "text": ""
            },
            "OCCTemplate": {
                "type": "OCCTemplate",
                "text": ""
            }
        };

        this.notificationTemplate = {
            "standardTemplate": {
                "type": "standardTemplate",
                "text": ""
            },
            "specifiekeResponseDatum": {
                "type": "specifiekeResponseDatum",
                "text": ""
            },
            "OCCTemplate": {
                "type": "OCCTemplate",
                "text": ""
            }
        };

        //kanalenmx chart variables and function definitos
        this.rankingResults = [];
        this.rankingCategories = {};
        this.rankingSubCategories = {};
        this.rankingCites = {};
        this.rankingVersions = [];

        this.projectId = 4;
        this.isChanged = true;
        this.resultPage = '1';

        this.enabledModalName = "";
    }
})();
