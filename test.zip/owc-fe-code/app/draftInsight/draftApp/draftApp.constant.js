(function () {
    'use strict',
	angular.module('olympia-draftApp')
	.constant('enumApp', {
	    'isProductionEnvir': true,
	    'isTestDevEnvir': false,
	    'mapsEnabled': true,
	    'url': {
	        //'analyzerUrl' : 'http://localhost:54290/api/',
	        //'analyzerUrl': 'https://olympia-jobapplicationprediction-api-test.azurewebsites.net/api/',
	        //'analyzerUrl' : 'https://olympia-jobapplicationprediction-api-staging.azurewebsites.net/api/',
	        'analyzerUrl' : 'https://olympia-jobapplicationprediction-api-rel.azurewebsites.net/api/',
	        'draftUrl': '/api/',
	        'actueelVerkeerUrl': 'http://olympia-googleapi-test.azurewebsites.net/JobViewAndApplication',
	        //'wpAuthentication' : 'http://olympia-wervingscockpit-staging.ignite.online/wp-token.php'
	        'wpAuthentication': 'http://olympia-wervingscockpit.ignite.online/wp-token.php'
	    },
	    'randomMessage': []
	});

})();
