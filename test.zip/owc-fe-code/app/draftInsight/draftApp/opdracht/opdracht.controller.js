(function () {
    'use strict';
    angular.module('opdracht.module')
		.controller('opdrachtCntl', opdrachtCntl);

    opdrachtCntl.$inject = ['opdrachtService', 'draftAppService', '$rootScope', '$timeout', '$scope', '$state'];

    function opdrachtCntl(opdrachtService, draftAppService, $rootScope, $timeout, $scope, $state) {
        var vm = this, SimpleGraph, registerKeyboardHandler, graph;

        vm.delivery = {};
        vm.margin = {};

        vm.returnPartial = returnPartial;

        vm.openPopup = openPopup;

        vm.loadForecast = loadForecast;

        var fmsId = $state.params.fmsId;
        if (fmsId) {
            draftAppService.getVacature(fmsId, true, "Opdracht");
        }
        $scope.$on('vacatureFetched', function (event, vacature) {
            vm.vacature = vacature;
            angular.forEach(vm.dummytable, function (item) {
                angular.forEach(vm.vacature.keywords.funcKeywords, function (dbItem) {
                    if (item.keyword == dbItem.keyword) {
                        item.addToPlan = true;
                    }
                });
            });
        }, true);

        activate();

        /////////////////////////

        function activate() {
            var ele = document.getElementById('benchmarkChart');

            //this is for change tabs as this controller loads
            $rootScope.$broadcast('changeActiveTab', { str: 'mijnPublicaties.opdracht' });

            draftAppService.initPopover('.btn-popup');
        }

        function returnPartial(view) {
            return './draftApp/shared/partial/_' + view + '.html';
        }

        function openPopup(view, screen) {
            $rootScope.$broadcast('openPopupSection', { 'view': view, 'screen': screen });
        }

        function loadForecast() {
            var ele = document.getElementById('benchmarkChart');
            //Instantiate d3 chart
            $timeout(function () {
                forecastService.drawBenchmarkD3();
            });
        }

    }
})();
