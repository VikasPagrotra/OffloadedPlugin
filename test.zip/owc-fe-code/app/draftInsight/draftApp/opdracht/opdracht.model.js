(function(){
	'use strict';
	angular.module('opdracht.module')
		.service('opdrachtModel', opdrachtModel);

	opdrachtModel.$inject = [];

	function opdrachtModel(){
		this.BenchMarkChartData = {
		    "chartHeader": "Olympia houdt op dit moment 23519 vacatures bij, waarvan er 287 vacatures vergelijkbaar zijn met jouw vacature.Op basis van deze  287 vergelijkbare vacatures hebben wij volgende sollicitatie voorspellingsanalyse gemaakt.",
		    "chartTitle": "",
		    "vAxisTitle": "Weken",
		    "hAxisTitle": "Aantal sollicitanten",
		    "legends": [
		        {
		            "title": "Weken",
		            "dataType": "string"
		        },
		        {
		            "title": "Maximale verwachting",
		            "dataType": "number"
		        },
		        {
		            "title": "Gemiddelde verwachting",
		            "dataType": "number"
		        },
		        {
		            "title": "Minimale verwachting",
		            "dataType": "number"
		        },
		        {
		            "title": "Forecasts",//"Actuele aantal sollicitaties",
		            "dataType": "number"
		        }
		    ],
		    "chartData": {
		        "arrData": [
		            [
		                "w1",
		                17.13,
		                15.52,
		                13.9,
		                15
		            ],
		            [
		                "w2",
		                10.22,
		                9.13,
		                8.04,
		                8
		            ],
		            [
		                "w3",
		                9.77,
		                8.72,
		                7.67,
		                18
		            ],
		            [
		                "w4",
		                9.55,
		                8.49,
		                7.44,
		                17
		            ],
		            [
		                "w5",
		                8.06,
		                7.22,
		                6.39,
		                20
		            ],
		            [
		                "w6",
		                8.63,
		                7.58,
		                6.54,
		                0
		            ],
		            [
		                "w7",
		                6.39,
		                5.66,
		                4.92,
		                0
		            ],
		            [
		                "w8",
		                6.04,
		                5.43,
		                4.83,
		                0
		            ],
		            [
		                "w9",
		                6.03,
		                5.29,
		                4.55,
		                0
		            ],
		            [
		                "w10",
		                7.28,
		                6.54,
		                5.8,
		                0
		            ],
		            [
		                "w11",
		                6.24,
		                5.43,
		                4.63,
		                0
		            ],
		            [
		                "w12",
		                5.5,
		                4.71,
		                3.91,
		                0
		            ],
		            [
		                "w13",
		                6.22,
		                5.73,
		                5.25,
		                0
		            ],
		            [
		                "w14",
		                6.56,
		                6.08,
		                5.59,
		                0
		            ],
		            [
		                "w15",
		                9.15,
		                8.52,
		                7.89,
		                0
		            ],
		            [
		                "w16",
		                10.55,
		                9.88,
		                9.22,
		                0
		            ],
		            [
		                "w17",
		                9.08,
		                8.26,
		                7.44,
		                0
		            ],
		            [
		                "w18",
		                7.07,
		                5.41,
		                3.75,
		                0
		            ],
		            [
		                "w19",
		                7.82,
		                6.59,
		                5.36,
		                0
		            ]
		        ]
		    },
		    "weeksNeeded": [
		        [
		            "w1",
		            15.52
		        ],
		        [
		            "w2",
		            24.65
		        ],
		        [
		            "w3",
		            33.37
		        ],
		        [
		            "w4",
		            41.86
		        ],
		        [
		            "w5",
		            49.08
		        ],
		        [
		            "w6",
		            56.66
		        ],
		        [
		            "w7",
		            62.32
		        ],
		        [
		            "w8",
		            67.75
		        ],
		        [
		            "w9",
		            73.04
		        ],
		        [
		            "w10",
		            79.58
		        ],
		        [
		            "w11",
		            85.01
		        ],
		        [
		            "w12",
		            89.72
		        ],
		        [
		            "w13",
		            95.45
		        ],
		        [
		            "w14",
		            101.53
		        ],
		        [
		            "w15",
		            110.05
		        ],
		        [
		            "w16",
		            119.93
		        ],
		        [
		            "w17",
		            128.19
		        ],
		        [
		            "w18",
		            133.6
		        ],
		        [
		            "w19",
		            140.19
		        ]
		    ]
		},
		this.BenchMarkLegendColor =
		["#3366cc", "#4682b4", "#ff9900", "#9966cc"],
		this.bestaandKlantList = [
			{
			    "label": "Bestaande klant",
				"addToPlan" : false,
				"desc": "lorem ipsum dolor sit amet",
				"image": "../assets/images/bestaandeklant1.png",
				"icon": "icon-partnership-cooperation"
			},
			{
				"label" : "Prospect",
				"addToPlan" : false,
				"desc": "lorem ipsum dolor sit amet",
				"image": "../assets/images/prospect.png",
				"icon": "icon-goal-target"
			}
		],
		this.aantalconcurrenetnList = [
			{
				"label" : "Exclusief",
				"addToPlan" : false,
				"desc": "lorem ipsum dolor sit amet",
				"image": "../assets/images/bestaandeklant1.png",
				"icon": "icon-personal-features"
			},
			{
				"label" : "Niet exclusief",
				"addToPlan" : false,
				"desc": "lorem ipsum dolor sit amet",
				"image": "../assets/images/prospect.png",
				"icon": "icon-team-skills"
			},
			{
				"label" : "Onbekend",
				"addToPlan" : false,
				"desc": "lorem ipsum dolor sit amet",
				"image": "../assets/images/prospect.png",
				"icon": "icon-question-mark"
			}
		],
		this.vacatureprioreitList = [
			{
				"label" : "Laag",
				"addToPlan" : false,
				"desc": "lorem ipsum dolor sit amet",
				"image": "../assets/images/laag.png",
				"icon": "icon-prior-trivial1",
				"iconColor": "excellent",
			},
			{
				"label" : "Gemiddeld",
				"addToPlan" : false,
				"desc": "lorem ipsum dolor sit amet",
				"image": "../assets/images/gemiddeld.png",
				"icon": "icon-prior-normal1",
				"iconColor": "warning"
			},
			{
				"label" : "Hoog",
				"addToPlan" : false,
				"desc": "lorem ipsum dolor sit amet",
				"image": "../assets/images/hoog.png",
				"icon": "icon-prior-major1",
				"iconColor": "danger"
			}
		];
		this.planBucket = {
		        "bestaandeklant": {
					"data": []
				},
				"aantalconcurrenetn": {
					"data": []
				},
				"vacatureprioreit": {
					"data": []
				}
		}
	}
})();
