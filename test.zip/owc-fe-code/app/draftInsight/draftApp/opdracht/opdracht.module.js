(function(){
	'use strict';
	angular.module('opdracht.module', []);
})();
