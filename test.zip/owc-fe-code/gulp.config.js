/* jshint node: true, -W024, -W069 */

'use strict';

module.exports = function() {
    var client = 'app';
    var root = './';
    var sassCache = './.sass-cache/';
    var temp = './app/.tmp/';
    var wiredep = require('wiredep');
    var assets = client + '/assets';
    var bowerFiles = wiredep({devDependencies: true})['js'];
    var draftRoot = root + client + '/draftInsight/';
    var draftApp = draftRoot + 'draftApp';
    var tempDraft = './app/draftInsight/draftApp/tmp/';


    var config = {
        /**
         * File paths
         */
        // all javascript that we want to vet
        allAppJs: [
            client + '/**/*.module.js',
            client + '/**/*.config.js',
            client + '/**/*.run.js',
            client + '/**/*.service.js',
            client + '/**/*.model.js',
            client + '/**/*.controller.js',
            client + '/**/*.directive.js',
            client + '/**/*.constant.js',
            '!' + client + '/draftInsight/draftApp/**/*.js',
            '!' + client + '/OWC-prototype/draftApp/**/*.js'
        ],
        allDraftAppJs : [
            draftApp + '/**/*.module.js',
            draftApp + '/**/*.config.js',
            draftApp + '/**/*.run.js',
            draftApp + '/**/*.service.js',
            draftApp + '/**/*.model.js',
            draftApp + '/**/*.controller.js',
            draftApp + '/**/*.directive.js',
            draftApp + '/**/*.constant.js',
            draftApp + '/**/*.filter.js'
        ],
        allLibjs : [
            assets + '/libs/jquery.min.js',
            assets + '/libs/bootstrap.min.js',
            assets + '/libs/angular.min.js',
            //assets + '/libs/angular-route.min.js',
            assets + '/libs/angular-ui-router.min.js',
            //assets + '/libs/angular-animate.min.js',
            assets + '/libs/angular-sanitize.min.js',
            assets + '/libs/lodash.underscore.min.js',
            //assets + '/libs/ui-bootstrap.min.js',
            //assets + '/libs/ui-bootstrap.tpls.min.js',
            assets + '/libs/jqcloud.js',
            assets + '/libs/angular-jqcloud.js',
            assets + '/libs/jQuery.verticalCarousel.js',
            assets + '/libs/underscore-min.js',
            assets + '/libs/jquery-ui.js',
            assets + '/libs/moment.min.js',
            assets + '/libs/moment-timezone-with-data.js',
            assets + '/libs/bootstrap-datetimepicker.min.js',
            assets + '/libs/angulartics.min.js',
            assets + '/libs/angulartics-gtm.js',
            assets + '/libs/angular-cookies.min.js',
            assets + '/libs/jquery.comiseo.daterangepicker.js',
            assets + '/libs/markerclusterer.js',
            assets + '/libs/bootstrap-slider.js',
            assets + '/libs/slider.js',
            assets + '/libs/d3.min.js'
        ],
        allDraftLibjs: [
            assets + '/libs/jquery.min.js',
            assets + '/libs/bootstrap.min.js',
            assets + '/libs/bootstrap3-typeahead.js',
            assets + '/libs/bootstrap-tagsinput.js',
            assets + '/libs/angular.min.js',
            //assets + '/libs/angular-route.min.js',
            assets + '/libs/angular-ui-router.min.js',
            //assets + '/libs/angular-animate.min.js',
            assets + '/libs/angular-sanitize.min.js',
            assets + '/libs/lodash.underscore.min.js',
            //assets + '/libs/ui-bootstrap.min.js',
            //assets + '/libs/ui-bootstrap.tpls.min.js',
            //assets + '/libs/jqcloud.js',
            //assets + '/libs/angular-jqcloud.js',
            //assets + '/libs/jQuery.verticalCarousel.js',
            assets + '/libs/underscore-min.js',
            assets + '/libs/jquery-ui.js',
            assets + '/libs/moment.min.js',
            assets + '/libs/moment-timezone-with-data.js',
            assets + '/libs/bootstrap-datetimepicker.min.js',
            assets + '/libs/angulartics.min.js',
            assets + '/libs/angulartics-gtm.js',
            assets + '/libs/angular-cookies.min.js',
            assets + '/libs/jquery.comiseo.daterangepicker.js',
            assets + '/libs/markerclusterer.js',
            assets + '/libs/bootstrap-slider.js',
            assets + '/libs/slider.js',
            assets + '/libs/d3.min.js',
            assets + '/libs/ng-wig.js',
            assets + '/libs/select2.full.min.js',
            assets + '/libs/d3.v2.min.js',
            assets + '/libs/jquery.fileupload.js',
            assets + '/libs/jquery.fileupload-ui.js',
            assets + '/libs/jquery.iframe-transport.js',
            assets + '/libs/JCrop.js',
            assets + '/libs/JCropAdditional.js'
        ],
        allLibCss : [
            assets + '/libs/*.css'
        ],
        build: './build/',
        client: client,
        css: temp + 'app.css',
        fonts: './bower_components/bootstrap/dist/fonts/**/*.*',
        html: client + '**/*.html',
        htmltemplates: client + '**/*.html',
        images: client + 'images/**/*.*',
        index: client + '**/index.html',
        //index: './jobs/src/**/index.html',
        js: [
            client + 'components/**/*.module.js',
            client + 'components/**/*.js'
        ],
        sass: client + '/**/*.scss',
        sassRoot: client + '/assets/styles/app.scss',
        sassDraft: draftApp + '/assets/styles/**/*.scss',
        sassDraftRoot: draftApp + '/assets/styles/app.scss',
        root: root,
        sassCache: sassCache,
        serverOptions : {
            directoryListing: {
                enable : true,
                path : root
            },
            open : true,
            port : 3000,
            https : false,
        },
        source: 'src/',
        temp: temp,
        tempDraft: tempDraft,

        /**
         * optimized files
         */
        optimized: {
            app: 'app.min.js',
            draftApp: 'draftApp.min.js',
            lib: 'lib.min.js',
            css: 'css.min.css'
        },

        /**
         * plato
         */
        plato: {js: client + '**/*.js'},

        /**
         * browser sync
         */
        browserReloadDelay: 1000,

        /**
         * template cache
         */
        templateCache: {
            file: 'templates.js',
            options: {
                module: 'app.core',
                root: '',
                standAlone: false
            }
        },

        /**
         * Bower and NPM locations
         */
        bower: {
            json: require('./bower.json'),
            directory: './bower_components/',
            ignorePath: '..'
        },
        packages: [
            './package.json',
            './bower.json'
        ],
        /**
         * Node settings
         */
    };

    /**
     * wiredep and bower settings
     */
    config.getWiredepDefaultOptions = function() {
        var options = {
            bowerJson: config.bower.json,
            //directory: config.bower.directory,
            //ignorePath: config.bower.ignorePath
        };
        return options;
    };

    return config;
};
