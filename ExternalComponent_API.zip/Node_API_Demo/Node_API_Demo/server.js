//Initiallising node modules
var http = require('http');
var express = require("express");
var bodyParser = require("body-parser");
var sql = require("mssql");
var arraySort = require('array-sort');
var app = express();

// Body Parser Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
//CORS Middleware
app.use(function (req, res, next) {
    //Enabling CORS 
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT,PATCH");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, contentType,Content-Type, Accept, Authorization");
    next();
});

//Setting up server
var server = app.listen(process.env.PORT || 8080, function () {
    var port = server.address().port;
    console.log("App now running on port", port);
});

//Initiallising connection string
var dbConfig = {
    user: "deviceDB",
    password: "@password1",
    server: "202.164.62.212",
    database: "deviceDB"    
    //options: {
    //    port: 1433,
    //    encrypt: true // Use this if you're on Windows Azure
    //}
};

//Function to connect to database and execute query
var executeQuery = function (res, query, type, criteria) {
    //res.send("saved");
    sql.connect(dbConfig, function (err) {
        if (err) {
            console.log("Error while connecting database :- " + err);
            res.send(err);
        }
        else {
            // create Request object
            var request = new sql.Request();
            // query to the database
            request.query(query, function (err, recordset) {
                if (err) {
                    res.send(err);
                }
                else {
                    if (type == "post") {
                       
                        recordset = "saved";
                       
                        res.send(recordset);
                    }
                    if (type == "patch") {
                        
                        var obj = [];
                        if (criteria != '')
                        {
                            criteria.forEach(function (value) {
                                obj.push(value, arraySort(recordset, value, { reverse: true }));
                            });
                            res.send(obj);
                        }
                        else
                        {
                            res.send(recordset);
                        }
                       
                       
                    }
                    else {
                        //recordset = "saved";
                        console.log(recordset);
                        res.send(recordset);
                    }                  
                }
            });
        }
    });
}

app.get("/api/getDeviceinfo", function (req, res) {
    var query = "select * from [tb_deviceInfo]";
    executeQuery(res, query,"get");
});

//POST API
app.post("/api/insertDeviceInfo", function (req, res) {   
    var query = "INSERT INTO [tb_deviceInfo] (model_id,tester,oem,cpu,ram_gb,date_tested,os_version,display200nits,color_temp,max_brightness,max_brightness_auto,low_brightness,low_brightness_auto,standard_display200nits,standard_color_temp,standard_max_brightness,standard_max_brightness_auto,standard_low_brightness,standard_low_brightness_auto,calman_uploaded,loudspeaker_loudness,headphone_output,noise_level,total_harmonic,frequency_response,rightmark_uploaded,battery_size,gen_battery_size,browsing_test,gaming_battery_test,video_playback_test,battery_full_charge,battery_15_min,battery_30_min,battery_60_min,color_daylight,noise_daylight,camera_sharpness,sharpness_daylight_Center_MTF50,sharpness_daylight_Corner_averageMTF50,color_lowlight,noise_lowlight,camera_sample_uploaded_drive,antutu,hd_onscreen,manhattan_onscreen,vellamo_metal,vellamo_browser,basemark_os_platform,jetstream,sunspider,geekbench_single_core,geekbench_multi_core,[3d_mark_test],[3d_mark_overall_test]) VALUES ('" + req.body['model_id'] + "','" + req.body['tester'] + "','" + req.body['oem'] + "','" + req.body['cpu'] + "','" + req.body['ram_gb'] + "','" + req.body['date_tested'] + "','" + req.body['os_version'] + "','" + req.body['display200nits'] + "','" + req.body['color_temp'] + "','" + req.body['max_brightness'] + "','" + req.body['max_brightness_auto'] + "','" + req.body['low_brightness'] + "','" + req.body['low_brightness_auto'] + "','" + req.body['standard_display200nits'] + "','" + req.body['standard_color_temp'] + "','" + req.body['standard_max_brightness'] + "','" + req.body['standard_max_brightness_auto'] + "','" + req.body['standard_low_brightness'] + "','" + req.body['standard_low_brightness_auto'] + "','" + req.body['calman_uploaded'] + "','" + req.body['loudspeaker_loudness'] + "','" + req.body['headphone_output'] + "','" + req.body['noise_level'] + "','" + req.body['total_harmonic'] + "','" + req.body['frequency_response'] + "','" + req.body['rightmark_uploaded'] + "','" + req.body['battery_size'] + "','" + req.body['gen_battery_size'] + "','" + req.body['browsing_test'] + "','" + req.body['gaming_battery_test'] + "','" + req.body['video_playback_test'] + "','" + req.body['battery_full_charge'] + "','" + req.body['battery_15_min'] + "','" + req.body['battery_30_min'] + "','" + req.body['battery_60_min'] + "','" + req.body['color_daylight'] + "','" + req.body['noise_daylight'] + "','" + req.body['camera_sharpness'] + "','" + req.body['sharpness_daylight_Center_MTF50'] + "','" + req.body['sharpness_daylight_Corner_averageMTF50'] + "','" + req.body['color_lowlight'] + "','" + req.body['noise_lowlight'] + "','" + req.body['camera_sample_uploaded_drive'] + "','" + req.body['antutu'] + "','" + req.body['hd_onscreen'] + "','" + req.body['manhattan_onscreen'] + "','" + req.body['vellamo_metal'] + "','" + req.body['vellamo_browser'] + "','" + req.body['basemark_os_platform'] + "','" + req.body['jetstream'] + "','" + req.body['sunspider'] + "','" + req.body['geekbench_single_core'] + "','" + req.body['geekbench_multi_core'] + "','" + req.body['3d_mark_test'] + "','" + req.body['3d_mark_overall_test'] + "')";
    executeQuery(res, query,"post");
});

////PUT API
//app.put("/api/movie/:id", function (req, res) {
//    var query = "UPDATE [movie] SET MovieName='updating record with api node js' WHERE MovieId=14";
//    executeQuery(res, query);
//});

//// DELETE API
//app.delete("/api/Movie/:id", function (req, res) {
//    var query = "DELETE FROM [Movie] WHERE MovieId=14";
//    executeQuery(res, query);
//});

app.patch("/api/ranking", function (req, res) {   
   
    var query = "";
  //  var ColumnsName = "model_id,tester,oem,cpu,ram_gb,date_tested,os_version,display200nits,color_temp,max_brightness,max_brightness_auto,low_brightness,low_brightness_auto,standard_display200nits,standard_color_temp,standard_max_brightness,standard_max_brightness_auto,standard_low_brightness,standard_low_brightness_auto,calman_uploaded,loudspeaker_loudness,headphone_output,noise_level,total_harmonic,frequency_response,rightmark_uploaded,battery_size,gen_battery_size,browsing_test,gaming_battery_test,video_playback_test,battery_full_charge,battery_15_min,battery_30_min,battery_60_min,color_daylight,noise_daylight,camera_sharpness,sharpness_daylight_Center_MTF50,sharpness_daylight_Corner_averageMTF50,color_lowlight,noise_lowlight,camera_sample_uploaded_drive,antutu,hd_onscreen,manhattan_onscreen,vellamo_metal,vellamo_browser,basemark_os_platform,jetstream,sunspider,geekbench_single_core,geekbench_multi_core,3d_mark_test,3d_mark_overall_test";
    if (req.body['devices'] != "") {

        query=   "select * from [tb_deviceInfo] where Id in (" + req.body['devices'] + ")";
    } else {
        query= "select * from [tb_deviceInfo]";
    }

        executeQuery(res, query, "patch", req.body['criteria'].split(','));
    
   
    //app.each(req.body['Columns'], function (index, value) {
        
    //});
});




