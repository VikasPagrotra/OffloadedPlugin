 // include plug-ins
var gulp = require('gulp');
var concat = require('gulp-concat');
var uglify = require('gulp-uglify');
var cssmin = require('gulp-cssmin');
var del = require('del');
var server = require('gulp-develop-server');

var config = {
    //Include all js files but exclude any min.js files
    src: ['scripts/**/*.js', '!scripts/**/*.min.js'],
    cssconfig: ['css/style.css', 'css/custom-style.css']
}

// run server 
gulp.task('server:start', function () {
    server.listen({ path: 'E:/RKumar_new/Node_API_Demo/Node_API_Demo/server.js' });
});

//delete the output file(s)
gulp.task('clean', function () {
    //del is an async function and not a gulp plugin (just standard nodejs)
    //It returns a promise, so make sure you return that from this task function
    //  so gulp knows when the delete is complete
    return del(['js/all.min.js', 'css/all-css.min.css']);
});

// Combine and minify all files from the app folder
// This tasks depends on the clean task which means gulp will ensure that the 
// Clean task is completed before running the scripts task.
gulp.task('scripts', ['clean'], function () {
    return gulp.src(config.src)
      .pipe(uglify())
      .pipe(concat('all.min.js'))
      .pipe(gulp.dest('js/'));
});

// bundle all css files
gulp.task('bundle:CSS', ['clean'], function () {
    return gulp.src(config.cssconfig)
      .pipe(cssmin())
      .pipe(concat('all-css.min.css'))
      .pipe(gulp.dest('css/'));
});

gulp.task('watch', function () {
    return gulp.watch(config.src, ['scripts']);
});

//Set a default tasks
gulp.task('default', ['server:start', 'bundle:CSS', 'scripts', 'watch'], function () { });

//gulp.task('default', ['server:start', 'watch'], function () { });