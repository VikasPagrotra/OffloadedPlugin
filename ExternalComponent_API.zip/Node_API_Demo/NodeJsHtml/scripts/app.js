
$(document).ready(function () {
    $("#wizard").steps();
    $("#form").steps({
        bodyTag: "fieldset",
        onStepChanging: function (event, currentIndex, newIndex) {
            // Always allow going backward even if the current step contains invalid fields!
            if (currentIndex > newIndex) {
                return true;
            } 
            // Forbid suppressing "Warning" step if the user is to young
            if (newIndex === 3 && Number($("#age").val()) < 18) {
                return false;
            }
            var form = $(this);
            // Clean up if user went backward before
            if (currentIndex < newIndex) {
                // To remove error styles
                $(".body:eq(" + newIndex + ") label.error", form).remove();
                $(".body:eq(" + newIndex + ") .error", form).removeClass("error");
            }
            // Disable validation on fields that are disabled or hidden.
            form.validate().settings.ignore = ":disabled,:hidden";

            // Start validation; Prevent going forward if false
            return form.valid();
        },
        onStepChanged: function (event, currentIndex, priorIndex) {
            // Suppress (skip) "Warning" step if the user is old enough.
            if (currentIndex === 2 && Number($("#age").val()) >= 18) {
                $(this).steps("next");
            }

            // Suppress (skip) "Warning" step if the user is old enough and wants to the previous step.
            if (currentIndex === 2 && priorIndex === 3) {
                $(this).steps("previous");
            }
        },
        onFinishing: function (event, currentIndex) {
            var form = $(this);
            // Disable validation on fields that are disabled.
            // At this point it's recommended to do an overall check (mean ignoring only disabled fields)
            form.validate().settings.ignore = ":disabled";

            // Start validation; Prevent form submission if false
            return form.valid();
        },
        onFinished: function (event, currentIndex) {
            var form = $(this);
            submitform(form.serializeArray())
        },
        onCanceled: function (event) {
            $('#form')[0].reset();
            $("a#form-t-0").click();
        }
    }).validate({
        errorPlacement: function (error, element) {
            element.before(error);
        },
        rules: {
            confirm: {
                equalTo: "#password"
            },
            model_id: {
                model_id_Regex: /^[a-zA-Z0-9_,@ ]*$/
            },
            tester: {
                tester_Regex: /^[a-zA-Z ]*$/
            },
            oem: {
                oem_Regex: /^[a-zA-Z ]*$/
            },
            cpu: {
                cpu_Regex: /^[a-zA-Z0-9]*$/
            },
            ram_gb: {
                ram_gb_Regex: /^[0-9]*$/
            },
            date_tested: {
                date_tested_Regex: '^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}$'  //'^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$'  //       /^[0-3?0-9/0-3?0-9/(?:0-9{2})?[0-9]{2}]*$/
            },
            os_version: {
                os_version_Regex: /^[0-9.]*$/
            },
            display200nits:{
                display200nits_Regex: /((\d+)((\.\d{1,2})?))$/  ///^[0-9.]*$/
            },
            color_temp: {
                color_temp_Regex: /((\d+)((\.\d{1,2})?))$/  // /^[0-9.]*$/
            },
            max_brightness: {
                max_brightness_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            max_brightness_auto: {
                max_brightness_auto_Regex: /((\d+)((\.\d{1,2})?))$/   // /^[0-9.]*$/
            },
            low_brightness: {
                low_brightness_Regex:  /((\d+)((\.\d{1,2})?))$/ //  /^[0-9.]*$/
            },
            low_brightness_auto: {
                low_brightness_auto_Regex: /((\d+)((\.\d{1,2})?))$/  // /^[0-9.]*$/
            },
            standard_display200nits: {
                standard_display200nits_Regex: /((\d+)((\.\d{1,2})?))$/  // /^[0-9.]*$/
            },
            standard_color_temp: {
                standard_color_temp_Regex: /((\d+)((\.\d{1,2})?))$/  // /^[0-9.]*$/
            },
            standard_max_brightness: {
                standard_max_brightness_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            standard_max_brightness_auto: {
                standard_max_brightness_auto_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            standard_low_brightness: {
                standard_low_brightness_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            standard_standard_low_brightness_auto: {
                standard_low_brightness_auto_Regex: /((\d+)((\.\d{1,2})?))$/ //  /^[0-9.]*$/
            },
            loudspeaker_loudness: {
                loudspeaker_loudness_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            headphone_output: {
                headphone_output_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            noise_level: {
                noise_level_Regex: /^[0-9.-]*$/
            },
            total_harmonic: {
                total_harmonic_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            frequency_response: {
                frequency_response_Regex:  /^[-0-9.+,]*$/
            },
            battery_size: {
                battery_size_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            gen_battery_size: {
                gen_battery_size_Regex: /^[a-zA-Z0-9 ]*$/
            },
            browsing_test: {
                browsing_test_Regex: /^[a-zA-Z0-9 ]*$/
            },
            gaming_battery_test:{
                gaming_battery_test_Regex: /^[a-zA-Z0-9 ]*$/
            },
            video_playback_test: {
                video_playback_test_Regex: /^[a-zA-Z0-9 ]*$/
            },
            battery_full_charge: {
                battery_full_charge_Regex: /^[0-9]*$/
            },
            battery_15_min: {
                battery_15_min_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            battery_30_min: {
                battery_30_min_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            battery_60_min: {
                battery_60_min_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            color_daylight: {
                color_daylight_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            noise_daylight: {
                noise_daylight_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            camera_Sharpness: {
                camera_Sharpness_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            sharpness_daylight_Center_MTF50: {
                sharpness_daylight_Center_MTF50_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            sharpness_daylight_Corner_averageMTF50: {
                sharpness_daylight_Corner_averageMTF50_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            color_lowlight: {
                color_lowlight_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            noise_lowlight: {
                noise_lowlight_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            antutu: {
                antutu_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            hd_onscreen: {
                hd_onscreen_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            manhattan_onscreen: {
                manhattan_onscreen_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            vellamo_metal: {
                vellamo_metal_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            vellamo_browser: {
                vellamo_browser_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            basemark_os_platform: {
                basemark_os_platform_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            jetstream: {
                jetstream_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            sunspider: {
                sunspider_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            geekbench_single_core: {
                geekbench_single_core_Regex: /((\d+)((\.\d{1,2})?))$/ // /^[0-9.]*$/
            },
            geekbench_multi_core: {
                geekbench_multi_core_Regex: /((\d+)((\.\d{1,2})?))$/ //  /^[0-9.]*$/
            },
            '3d_mark_test':{
                '3d_mark_test_Regex': /^[a-zA-Z0-9. ]*$/
            },
            '3d_mark_overall_test': {
                '3d_mark_overall_test_Regex': /((\d+)((\.\d{1,2})?))$/  // /^[0-9.]*$/
            }


        },
        messages: {
            model_id: {
                required: "Please "

            }


        },

    });


    $.validator.addMethod("model_id_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) && value!=="") {
            check = true;
        }
        return check;
    }, "Please check your input.");

    $.validator.addMethod("tester_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please check your input.");

    $.validator.addMethod("oem_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please check your input.");

    $.validator.addMethod("cpu_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please check your input.");

    $.validator.addMethod("ram_gb_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer number.");

    $.validator.addMethod("date_tested_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value)|| value=="") {
            check = true;
        }
        return check;
    }, "Please check your input. Format(mm/dd/yyyy eg:01/01/1900)");

    $.validator.addMethod("os_version_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please check your input.");

    $.validator.addMethod("display200nits_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("color_temp_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("max_brightness_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("max_brightness_auto_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");
    $.validator.addMethod("low_brightness_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");
    $.validator.addMethod("low_brightness_auto_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("standard_display200nits_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("standard_color_temp_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("standard_max_brightness_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("standard_max_brightness_auto_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");
    $.validator.addMethod("standard_low_brightness_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");
    $.validator.addMethod("standard_low_brightness_auto_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("loudspeaker_loudness_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("headphone_output_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("noise_level_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please check your input.");

    $.validator.addMethod("total_harmonic_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("frequency_response_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value)) {
            check = true;
        }
        return check;
    }, "Please check your input.");

    $.validator.addMethod("battery_size_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("gen_battery_size_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please check your input.");

    $.validator.addMethod("browsing_test_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please check your input.");

    $.validator.addMethod("gaming_battery_test_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please check your input.");
    $.validator.addMethod("video_playback_test_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please check your input.");

    $.validator.addMethod("battery_full_charge_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer number.");

    $.validator.addMethod("battery_15_min_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("battery_30_min_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("battery_60_min_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("color_daylight_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("noise_daylight_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("camera_Sharpness_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("sharpness_daylight_Center_MTF50_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("sharpness_daylight_Corner_averageMTF50_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("color_lowlight_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("noise_lowlight_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("antutu_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("hd_onscreen_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("manhattan_onscreen_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("vellamo_metal_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("vellamo_browser_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");
    
    $.validator.addMethod("basemark_os_platform_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("jetstream_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("sunspider_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("geekbench_single_core_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("geekbench_multi_core_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

    $.validator.addMethod("3d_mark_test_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please check your input.");

    $.validator.addMethod("3d_mark_overall_test_Regex", function (value, element, regexp) {
        var check = false;
        var patt = new RegExp(regexp);
        if (patt.test(value) || value == "") {
            check = true;
        }
        return check;
    }, "Please enter valid integer or decimal number with 2 decimal places.");

});


function submitform(formdata) {
     var values = {};
    $.each(formdata, function (i, field) {
        values[field.name] = field.value;
    });
    $.ajax({
        //url: 'http://localhost:8080/api/insertDeviceInfo',
        url: 'http://202.164.62.212:8080/api/insertDeviceInfo',
        data: values,
        type: 'POST',
        success: function (data) {
            console.log(data)
            if (data == "saved") {
                $('#form')[0].reset();
                $("a#form-t-0").click();
                swal("Success", "Info saved successfully.", "success");
            }
            else {
                var message = "Exception: " + data.message;
                //var inner_message ="Inner Exception: "+ data.precedingErrors[0].message;
                swal("Error", message, "error");
            }
        },
        error: function (xhr, status, error) {       
            swal("Error", error.message, "success");
        },
    });
}




